# ============================================================
# NIFLHEIM — lords.py
# Lord permission system
# King has all rights. Lords have spawn rights.
# Only the King can .throne / .dethrone.
# ============================================================

import json
import os

# ── King (immutable) ──────────────────────────────────────────
KING_NUMBER  = "2348101845905"
KING_JID     = f"{KING_NUMBER}@s.whatsapp.net"

# ── Lords file (persisted alongside DB) ──────────────────────
_LORDS_PATH  = os.path.join(os.path.dirname(__file__), "lords.json")

_lords: set = set()   # in-memory set of JIDs


def _load():
    global _lords
    try:
        with open(_LORDS_PATH) as f:
            _lords = set(json.load(f))
    except FileNotFoundError:
        _lords = set()
    except Exception as e:
        print(f"[LORDS] Load error: {e}")
        _lords = set()


def _save():
    try:
        with open(_LORDS_PATH, "w") as f:
            json.dump(list(_lords), f)
    except Exception as e:
        print(f"[LORDS] Save error: {e}")


_load()


# ── Public API ────────────────────────────────────────────────

def is_king(sender: str) -> bool:
    return sender == KING_JID or sender.split("@")[0] == KING_NUMBER


def is_lord(sender: str) -> bool:
    """Kings are also lords."""
    if is_king(sender):
        return True
    num = sender.split("@")[0]
    return sender in _lords or f"{num}@s.whatsapp.net" in _lords


def throne(jid: str):
    """Add a lord by JID. Saves to disk."""
    _lords.add(jid)
    _save()


def dethrone(jid: str):
    """Remove a lord by JID. Saves to disk."""
    _lords.discard(jid)
    _save()


def list_lords() -> list[str]:
    return sorted(_lords)


def _jid_from_mention(mention: str) -> str:
    """Normalise @number or number@s.whatsapp.net to full JID."""
    mention = mention.strip().lstrip("@").replace("+", "")
    if "@" not in mention:
        mention = f"{mention}@s.whatsapp.net"
    return mention
