# ============================================================
# NIFLHEIM — router/shop.py
# Oak Town Pokémart flow
# static_state = "oak_mart"
# ============================================================

from data_items import OAK_TOWN_SHOP, shop_display


class ShopMixin:

    def _open_mart(self, sender, player) -> str:
        if getattr(player, "story_stage", "new") not in ("has_starter", "route_1"):
            return "_The mart is closed. Come back once you have a Pokémon._"
        player.static_state = "oak_mart"
        self._save(sender, player)
        return shop_display(OAK_TOWN_SHOP)

    def _handle_shop_flow(self, sender, player, text) -> str | None:
        lower = text.strip().lower()

        if lower in (".exit", "exit", ".leave", "leave", ".cancel", "cancel", ".no"):
            player.static_state = None
            self._save(sender, player)
            return "_You leave the Pokémart._"

        try:
            idx = int(lower.lstrip(".")) - 1
        except ValueError:
            return "_Reply with a number to buy, or 'exit' to leave._"

        if not (0 <= idx < len(OAK_TOWN_SHOP)):
            return f"_Pick a number between 1 and {len(OAK_TOWN_SHOP)}._"

        item  = OAK_TOWN_SHOP[idx]
        name  = item["name"]
        price = item["price"]
        coins = getattr(player, "coins", 0)

        if coins < price:
            return f"_Not enough coins. You have ₽{coins}, {name} costs ₽{price}._"

        player.coins -= price
        player.inventory[name] = player.inventory.get(name, 0) + 1
        self._save(sender, player)

        return (
            f"✅ *{name}* purchased!\n"
            f"₽{price} spent  •  ₽{player.coins} remaining\n\n"
            + shop_display(OAK_TOWN_SHOP)
        )

    # ── Breadcrumbs use ──────────────────────────────────────
    def _use_breadcrumbs(self, sender, player) -> str:
        count = player.inventory.get("Breadcrumbs", 0)
        if count <= 0:
            return "_You don't have any Breadcrumbs._"

        last_town = player.get_flag("last_town")
        if not last_town:
            return "_You haven't visited any other town yet._"

        from map import load_zone
        zone  = load_zone(last_town)
        spawn = zone.get("spawn", (0, 0))

        if count == 1:
            del player.inventory["Breadcrumbs"]
        else:
            player.inventory["Breadcrumbs"] -= 1

        player.zone   = last_town
        player.zone_x = spawn[0]
        player.zone_y = spawn[1]
        self._save(sender, player)

        name = zone.get("name", last_town.replace("_", " ").title())
        return (
            f"🍞 _The breadcrumbs lead you back to {name}..._\n\n"
            + self._render_zone_map(sender, player)
        )


