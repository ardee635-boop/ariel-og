import sys, os, json, threading
from concurrent.futures import ThreadPoolExecutor

sys.path.insert(0, os.path.dirname(__file__))

from router import CommandRouter
from database import Database
from interfaces import _player_fonts, _FONT_MAP
from router.site_actions import handle_swap

_SITE_ACTIONS = {
    "swap": handle_swap,
}

_db     = Database()
_router = CommandRouter(_db)

# Re-register egg hatch timers from stored timestamps
try:
    from egg import restore_timers as _restore_egg_timers
    _restore_egg_timers(_router)
except Exception as _e:
    import sys
    print(f"[EGG] restore_timers failed: {_e}", file=sys.stderr)

_stdout_lock = threading.Lock()

# Thread pool for parallel handle() calls (one thread per message)
_pool = ThreadPoolExecutor(max_workers=8)

# Per-sender locks — ensures messages from the same sender run sequentially
_sender_locks: dict = {}
_sender_locks_mutex = threading.Lock()

def _get_sender_lock(sender: str) -> threading.Lock:
    with _sender_locks_mutex:
        if sender not in _sender_locks:
            _sender_locks[sender] = threading.Lock()
        return _sender_locks[sender]


def _apply_font(text, sender):
    """Apply player's chosen font to ALL text, skipping border chars and markers."""
    if not text:
        return text
    key = _player_fonts.get(sender)
    if not key or key not in _FONT_MAP:
        return text
    fm = _FONT_MAP[key]

    BORDER_START = set('╭╰╮╯┃┣┗━❰❱⌖彡۞𝕬𝕽𝕴𝕰𝕷𝓦𝓮𝓵𝓬𝓸𝔸𝕽𝕴𝔼𝕷')

    result = []
    i = 0
    while i < len(text):
        found_marker = False
        for marker in ('__IMG__', '__HUD__', '__CAP__', '__THUMB__',
                        '__TITLE__', '__SUB__', '__TYPE__'):
            if text[i:i+len(marker)] == marker:
                result.append(marker)
                i += len(marker)
                found_marker = True
                break
        if found_marker:
            continue

        ch = text[i]
        if ch == '\n':
            result.append('\n')
            i += 1
            continue

        end = text.find('\n', i)
        if end == -1:
            end = len(text)
        line = text[i:end]
        stripped = line.strip()

        if stripped and stripped[0] in BORDER_START:
            result.append(line)
        else:
            result.append(line.translate(fm))

        i = end

    return ''.join(result)


def _direct_send(message, group_jid=None, sender=None, tag_all=False, hide_tags=False, allow_dm=False):
    """Write push message to stdout.
    allow_dm=True lets group_jid be an individual's JID instead of a
    whitelisted group — used by Among Us to notify a specific player
    (e.g. room enter/leave, kill resolution, follow reveal) without a
    new message from them triggering it. Off by default everywhere else.
    """
    if sender:
        message = _apply_font(message, sender)
    payload = {
        "response": None,
        "outbox": [{"sender": "__push__", "message": message, "group_jid": group_jid, "tag_all": tag_all, "hide_tags": hide_tags, "allow_dm": allow_dm}],
        "quote_id": None
    }
    with _stdout_lock:
        sys.stdout.write(json.dumps(payload) + "\n")
        sys.stdout.flush()

_router._direct_send = _direct_send

def _precache_zone_pokemon():
    """Pre-fetch and cache all Pokémon in encounter tables so encounters work offline."""
    import threading
    from encounters import ENCOUNTER_TABLES
    from pokeapi import get_full

    def _do():
        all_species = set()
        for zone_data in ENCOUNTER_TABLES.values():
            for tile_pool in zone_data.values():
                if isinstance(tile_pool, list):
                    for entry in tile_pool:
                        if isinstance(entry, tuple):
                            all_species.add(entry[0])
        print(f"[PRECACHE] Caching {len(all_species)} species: {sorted(all_species)}", file=sys.stderr, flush=True)
        for species in sorted(all_species):
            try:
                result = get_full(_db, species)
                status = "✓" if result else "✗ FAILED"
                print(f"[PRECACHE] {species}: {status}", file=sys.stderr, flush=True)
            except Exception as e:
                print(f"[PRECACHE] {species}: ERROR {e}", file=sys.stderr, flush=True)
        print("[PRECACHE] Done.", file=sys.stderr, flush=True)

    t = threading.Thread(target=_do, daemon=True)
    t.start()

_precache_zone_pokemon()

from pokeapi import prewarm_arena_pool
prewarm_arena_pool(_db)


def _do_handle(req_id, sender, text, mentioned_jid, group_jid, quoted_text, push_name=None):
    """Run in thread pool — never blocks the stdin loop."""
    import traceback
    print(f"[BRIDGE] [{req_id}] recv: {text}", file=sys.stderr, flush=True)
    _router._last_group_jid = group_jid
    _router._last_push_name = push_name or ""
    with _get_sender_lock(sender):
        try:
            response = _router.handle(sender, text, mentioned_jid=mentioned_jid, quoted_text=quoted_text)
        except Exception as e:
            print(f"[BRIDGE] [{req_id}] CRASH: {e}", file=sys.stderr, flush=True)
            traceback.print_exc(file=sys.stderr)
            response = None

        outbox = []
        for s in list(_router._outbox.keys()):
            msgs = _router.pop_outbox(s)
            for m in msgs:
                outbox.append({
                    "sender":    s,
                    "message":   _apply_font(m, sender),
                    "group_jid": group_jid
                })

        result = {
            "req_id":   req_id,
            "response": response if response else None,
            "outbox":   outbox,
            "quote_id": None
        }
        print(f"[BRIDGE] [{req_id}] done", file=sys.stderr, flush=True)
        with _stdout_lock:
            sys.stdout.write(json.dumps(result) + "\n")
            sys.stdout.flush()


def _do_site_action(req_id, action_type, data):
    """Run in thread pool — handles a site-originated action (e.g. swap).
    Uses the same per-sender lock as WhatsApp commands so a site swap
    and an in-progress WhatsApp command for the same player never race.
    """
    sender = data.get("sender", "unknown")
    print(f"[BRIDGE] [{req_id}] site action: {action_type} ({sender})", file=sys.stderr, flush=True)
    with _get_sender_lock(sender):
        try:
            handler = _SITE_ACTIONS[action_type]
            result  = handler(_router, sender, data.get("payload") or {})
        except Exception as e:
            print(f"[BRIDGE] [{req_id}] site action CRASH: {e}", file=sys.stderr, flush=True)
            import traceback
            traceback.print_exc(file=sys.stderr)
            result = {"error": "Internal error processing action."}

        with _stdout_lock:
            sys.stdout.write(json.dumps({"req_id": req_id, "site_result": result}) + "\n")
            sys.stdout.flush()


if __name__ == "__main__":
    with _stdout_lock:
        sys.stdout.write(json.dumps({"ready": True}) + "\n")
        sys.stdout.flush()

    req_counter = 0
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            data       = json.loads(line)
            req_id     = data.get("req_id", req_counter)
            req_counter += 1

            action_type = data.get("type")
            if action_type in _SITE_ACTIONS:
                # Site-originated action (e.g. party/PC swap) — runs
                # through the same Player model as WhatsApp commands,
                # but bypasses text parsing entirely.
                _pool.submit(_do_site_action, req_id, action_type, data)
                continue

            sender        = data.get("sender", "unknown")
            text          = data.get("text", "")
            mentioned_jid = data.get("mentioned_jid", None)
            group_jid     = data.get("group_jid", None)
            quoted_text   = data.get("quoted_text", None)
            push_name     = data.get("push_name", None)
            # Fire off in thread pool — stdin loop is immediately free
            _pool.submit(_do_handle, req_id, sender, text, mentioned_jid, group_jid, quoted_text, push_name)
        except Exception as e:
            print(f"[BRIDGE] parse error: {e}", file=sys.stderr, flush=True)
