# ============================================================
# NIFLHEIM — fauna.py
# Fauna — wild zone west of Greenwood Town
# Nature / Grass / Bug spawns (mixed & pure)
# 15×10 grid
# ============================================================

ZONE = {
    "id":           "fauna",
    "name":         "Fauna",
    "danger":       "🟡 Moderate",
    "safe":         False,
    "width":        15,
    "height":       10,
    "spawn":        (13, 5),
    "monster_zone": "Fauna",

    "grid": [
        # Row 00 — north treeline, cave at cols 1-2
        ["TT","CC","CC","TT","TT","TT","TT","TT","TT","TT","TT","TT","TT","TT","TT"],
        # Row 01
        ["TT","RR","RR","GG","GG","GG","GG","GG","RR","RR","GG","GG","GG","RR","TT"],
        # Row 02
        ["TT","RR","RR","GG","GG","GG","GG","GG","RR","RR","GG","GG","GG","RR","TT"],
        # Row 03
        ["TT","RR","RR","GG","GG","GG","GG","GG","RR","RR","GG","GG","GG","RR","TT"],
        # Row 04 — east exit → Greenwood Town
        ["TT","RR","RR","RR","RR","RR","RR","RR","RR","RR","RR","RR","RR","RR","EX"],
        # Row 05 — east exit → Greenwood Town
        ["TT","RR","RR","RR","RR","RR","RR","RR","RR","RR","RR","RR","RR","RR","EX"],
        # Row 06
        ["TT","RR","GG","GG","GG","RR","RR","GG","GG","GG","GG","GG","RR","RR","TT"],
        # Row 07
        ["TT","RR","GG","GG","GG","RR","RR","GG","GG","GG","GG","GG","RR","RR","TT"],
        # Row 08
        ["TT","RR","RR","GG","GG","RR","RR","GG","GG","GG","GG","GG","RR","RR","TT"],
        # Row 09 — south treeline
        ["TT","TT","TT","TT","TT","TT","TT","TT","TT","TT","TT","TT","TT","TT","TT"],
    ],

    # ── Tile exits ────────────────────────────────────────────
    "exits": {
        # East → Greenwood Town
        "4,14": {"to_zone": "greenwood_town", "to_exit": "greenwood_west_a"},
        "5,14": {"to_zone": "greenwood_town", "to_exit": "greenwood_west_b"},
    },

    # ── Exit positions (arrival points from other zones) ──────
    "exit_positions": {
        "fauna_east_a": (13, 4),   # arriving from Greenwood west
        "fauna_east_b": (13, 5),
    },

    # ── NPCs ──────────────────────────────────────────────────
    "npcs": {},

    # ── Signs ─────────────────────────────────────────────────
    "signs": {},
}
