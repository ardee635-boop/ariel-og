# ============================================================
# NIFLHEIM — pvp_session.py
# PvP Turn Engine
#
# Uses resolve_turn() from battle.py — identical formula to PvE.
# Only PvP-specific logic here:
#   - Two OwnedPokemon on both sides
#   - Turn alternation between two JIDs
#   - Forced swap prompt after faint
#   - Dual HUD
# ============================================================

import random
from models import OwnedPokemon
from battle import (
    resolve_turn,
    apply_status_tick, _status_prevents_action,
    _init_stages, STATUS_ICONS,
)

RM = "\u200b" * 700  # readmore spacer


def _hp_bar(hp, max_hp, width=10):
    if max_hp <= 0:
        return "░" * width
    filled = int(round((hp / max_hp) * width))
    filled = max(0, min(width, filled))
    pct = int((hp / max_hp) * 100)
    bar = "█" * filled + "░" * (width - filled)
    color = "🟩" if pct > 50 else "🟨" if pct > 20 else "🟥"
    return f"{color} {bar} {hp}/{max_hp}"


class PvPSession:
    """
    Holds state for a single 1v1 PvP battle between two players.

    turn            : "a" or "b" — whose turn it is
    awaiting_swap   : jid of player who must swap after faint, or None
    ended           : True once battle is fully over
    winner_jid      : JID of winner, None if draw
    wager           : int coins wagered (0 = no wager)
    """

    def __init__(self, jid_a, player_a, jid_b, player_b, wager=0, db=None, group_jid=None):
        self.jid_a    = jid_a
        self.jid_b    = jid_b
        self.player_a = player_a
        self.player_b = player_b
        self.wager    = wager
        self.db       = db
        self.group_jid = group_jid

        self.name_a = f"@{player_a.name}"
        self.name_b = f"@{player_b.name}"

        self.pokemon_a = player_a.party[player_a.active_slot]
        self.pokemon_b = player_b.party[player_b.active_slot]

        self.stages_a = _init_stages()
        self.stages_b = _init_stages()

        self._flinched = None   # jid of flinched player this turn

        self.turn          = "a"   # challenger goes first
        self.ended         = False
        self.winner_jid    = None
        self.awaiting_swap = None

    # ── Helpers ───────────────────────────────────────────────

    def active_jid(self):
        return self.jid_a if self.turn == "a" else self.jid_b

    def waiting_jid(self):
        return self.jid_b if self.turn == "a" else self.jid_a

    def _attacker(self):
        if self.turn == "a":
            return self.pokemon_a, self.name_a, self.stages_a
        return self.pokemon_b, self.name_b, self.stages_b

    def _defender(self):
        if self.turn == "a":
            return self.pokemon_b, self.name_b, self.stages_b
        return self.pokemon_a, self.name_a, self.stages_a

    def _swap_turn(self):
        self.turn = "b" if self.turn == "a" else "a"

    def _player_for(self, jid):
        return self.player_a if jid == self.jid_a else self.player_b

    def _pokemon_for(self, jid):
        return self.pokemon_a if jid == self.jid_a else self.pokemon_b

    def _stages_for(self, jid):
        return self.stages_a if jid == self.jid_a else self.stages_b

    def _set_pokemon(self, jid, poke):
        if jid == self.jid_a:
            self.pokemon_a = poke
            self.stages_a  = _init_stages()
        else:
            self.pokemon_b = poke
            self.stages_b  = _init_stages()

    def _name_for(self, jid):
        return self.name_a if jid == self.jid_a else self.name_b

    def _opponent_jid(self, jid):
        return self.jid_b if jid == self.jid_a else self.jid_a

    def _resolve_move(self, poke: OwnedPokemon, raw_input: str):
        """Substring match — same logic as BattleEngine._resolve_skill."""
        import re
        def _norm(t):
            return " ".join(re.sub(r"[^a-zA-Z0-9 ]", " ", t).lower().split())
        norm_input = _norm(raw_input)
        for m in poke.moves:
            nm = _norm(m["name"])
            if nm and nm in norm_input:
                return m
        return None

    # ── Turn resolution ───────────────────────────────────────

    def do_turn(self, sender_jid: str, raw_input: str, db=None):
        """
        Returns one of:
          ("action",  action_msg, hud_msg)
          ("faint",   action_msg, swap_msg)
          ("victory", action_msg, None)
          ("error",   msg,        None)
          ("wait",    None,       None)
        """
        db = db or self.db

        if self.ended:
            return ("wait", None, None)

        if self.awaiting_swap:
            if sender_jid != self.awaiting_swap:
                return ("wait", None, None)
            return ("error", "_Use .swap (no.) to send out your next Pokémon._", None)

        if sender_jid != self.active_jid():
            return ("wait", None, None)

        atk_poke, atk_name, atk_stages = self._attacker()
        def_poke, def_name, def_stages = self._defender()
        def_jid    = self._opponent_jid(sender_jid)
        def_player = self._player_for(def_jid)

        move_obj = self._resolve_move(atk_poke, raw_input)
        if not move_obj:
            return ("error", f"_{atk_poke.nickname} doesn't know that move!_", None)
        if move_obj["pp"] <= 0:
            return ("error", f"_{move_obj['name']} has no PP left!_", None)

        log = []
        self._flinched = None

        # Speed comparison for moved_first (affects flinch eligibility)
        from battle import _stage_mult
        PARA = -2  # paralysis speed penalty
        atk_spd = int(atk_poke.stat("speed") * _stage_mult(
            atk_stages.get("speed", 0) + (PARA if atk_poke.status == "paralysis" else 0)
        ))
        def_spd = int(def_poke.stat("speed") * _stage_mult(
            def_stages.get("speed", 0) + (PARA if def_poke.status == "paralysis" else 0)
        ))
        moved_first = atk_spd >= def_spd

        def _flinch_flag(_):
            self._flinched = def_jid

        result = resolve_turn(
            atk_poke, def_poke, move_obj,
            atk_stages=atk_stages, def_stages=def_stages,
            db=db, log=log,
            moved_first=moved_first,
            flinch_flag=_flinch_flag,
        )

        if result == "status_blocked":
            # Attacker couldn't move — still apply status ticks, swap turn
            apply_status_tick(atk_poke, log)
            apply_status_tick(def_poke, log)
            r = self._check_post_tick(log, atk_poke, def_poke, sender_jid, def_jid, def_player)
            if r: return r
            self._swap_turn()
            return ("action", "\n".join(log), self.battle_hud())

        if result in ("status", "missed"):
            apply_status_tick(atk_poke, log)
            apply_status_tick(def_poke, log)
            r = self._check_post_tick(log, atk_poke, def_poke, sender_jid, def_jid, def_player)
            if r: return r
            self._swap_turn()
            return ("action", "\n".join(log), self.battle_hud())

        if result == "fainted":
            xp_gain = random.randint(20, 50)
            atk_poke.gain_xp(xp_gain)
            log.append(f"*{atk_poke.nickname}* gained *{xp_gain} XP*!")
            return self._handle_def_faint(log, def_poke, def_jid, def_player, sender_jid, atk_poke)

        # "hit" — apply end-of-turn ticks
        apply_status_tick(atk_poke, log)
        apply_status_tick(def_poke, log)
        r = self._check_post_tick(log, atk_poke, def_poke, sender_jid, def_jid, def_player)
        if r: return r

        self._swap_turn()
        return ("action", "\n".join(log), self.battle_hud())

    # ── Post-tick faint checks ────────────────────────────────

    def _check_post_tick(self, log, atk_poke, def_poke, atk_jid, def_jid, def_player):
        """Check if either side fainted from status ticks. Returns result tuple or None."""
        atk_player = self._player_for(atk_jid)

        if def_poke.is_fainted():
            xp_gain = random.randint(20, 50)
            atk_poke.gain_xp(xp_gain)
            log.append(f"*{def_poke.nickname}* fainted from status! 💀")
            log.append(f"*{atk_poke.nickname}* gained *{xp_gain} XP*!")
            return self._handle_def_faint(log, def_poke, def_jid, def_player, atk_jid, atk_poke)

        if atk_poke.is_fainted():
            remaining = [p for p in atk_player.party if not p.is_fainted()]
            log.append(f"*{atk_poke.nickname}* fainted from status! 💀")
            if not remaining:
                self.ended      = True
                self.winner_jid = def_jid
                return ("victory", "\n".join(log), None)
            self.awaiting_swap = atk_jid
            swap_lines = [f"\n{self._name_for(atk_jid)} — send out a Pokémon!"]
            for i, p in enumerate(atk_player.party):
                if not p.is_fainted():
                    swap_lines.append(f".swap {i+1}  ({p.nickname} Lv.{p.level} — {p.hp}/{p.max_hp} HP)")
            swap_lines.append(".giveup")
            return ("faint", "\n".join(log), "\n".join(swap_lines))

        return None

    def _handle_def_faint(self, log, def_poke, def_jid, def_player, atk_jid, atk_poke):
        remaining = [p for p in def_player.party if not p.is_fainted()]
        if not remaining:
            self.ended      = True
            self.winner_jid = atk_jid
            return ("victory", "\n".join(log), None)

        self.awaiting_swap = def_jid
        swap_lines = [f"\n{self._name_for(def_jid)} — send out a Pokémon!"]
        for i, p in enumerate(def_player.party):
            if not p.is_fainted():
                swap_lines.append(f".swap {i+1}  ({p.nickname} Lv.{p.level} — {p.hp}/{p.max_hp} HP)")
        swap_lines.append(".giveup")
        return ("faint", "\n".join(log), "\n".join(swap_lines))

    # ── Swap after faint ──────────────────────────────────────

    def do_swap(self, sender_jid: str, slot: int):
        """Forced swap after faint — swapping player gets the next turn."""
        if self.awaiting_swap != sender_jid:
            return False, "_It's not your time to swap._"

        player = self._player_for(sender_jid)
        idx    = slot - 1

        if idx < 0 or idx >= len(player.party):
            return False, "⚠️ _Invalid slot._"

        poke = player.party[idx]
        if poke.is_fainted():
            return False, f"_{poke.nickname} cannot be summoned right now_"

        self._set_pokemon(sender_jid, poke)
        player.active_slot = idx
        self.awaiting_swap = None
        self._flinched     = None

        # Swapping player gets the turn
        self.turn = "a" if sender_jid == self.jid_a else "b"
        name = self._name_for(sender_jid)

        msg = f"*{name}* sent out *{poke.nickname}*!\n\n" + self.battle_hud()
        return True, msg

    def do_voluntary_swap(self, sender_jid: str, slot: int):
        """Mid-battle voluntary swap — costs the turn."""
        if self.ended or self.awaiting_swap:
            return False, "_Can't swap right now._"
        if sender_jid != self.active_jid():
            return False, "_It's not your turn._"

        player = self._player_for(sender_jid)
        idx    = slot - 1

        if idx < 0 or idx >= len(player.party):
            return False, "⚠️ _Invalid slot._"

        poke = player.party[idx]
        if poke.is_fainted():
            return False, f"_{poke.nickname} cannot be summoned right now_"

        current = self._pokemon_for(sender_jid)
        if poke is current:
            return False, f"_{poke.nickname} is already in battle!_"

        old_name = current.nickname
        self._set_pokemon(sender_jid, poke)
        player.active_slot = idx
        name = self._name_for(sender_jid)

        self._swap_turn()
        self._flinched = None

        next_name = self._name_for(self.active_jid())
        msg = (
            f"{name} withdrew *{old_name}* and sent out *{poke.nickname}*!\n\n"
            f"{next_name}'s turn ⚔️\n\n"
            + self.battle_hud()
        )
        return True, msg

    # ── HUD ───────────────────────────────────────────────────

    def battle_hud(self) -> str:
        pa = self.pokemon_a
        pb = self.pokemon_b

        def _stag(p):
            return f" {STATUS_ICONS.get(p.status, '💢')} {p.status.upper()}" if p.status else ""

        bar_a = _hp_bar(pa.hp, pa.max_hp)
        bar_b = _hp_bar(pb.hp, pb.max_hp)
        whose = self.name_a if self.turn == "a" else self.name_b

        return (
            f"{self.name_a}\n"
            f"{pa.nickname}'s HP:{_stag(pa)}\n"
            f"{bar_a}\n\n"
            f"{self.name_b}\n"
            f"{pb.nickname}'s HP:{_stag(pb)}\n"
            f"{bar_b}\n"
            f"{RM}\n"
            f"⚔️ {whose}'s turn\n"
            f".skills  .heal  .use  .switch [no.]\n"
            f"_State a skill name to attack_"
        )
