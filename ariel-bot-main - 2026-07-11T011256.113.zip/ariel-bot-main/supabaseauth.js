// ============================================================
// supabaseAuth.js
// Replaces useMultiFileAuthState — stores Baileys creds in
// Supabase (postgres) so auth survives Render deploys.
// ============================================================

import pg from 'pg';
const { Client } = pg;

let _client = null;

async function getClient() {
    if (_client) return _client;
    _client = new Client({
        connectionString: process.env.SUPABASE_DB_URL,
        ssl: { rejectUnauthorized: false },
    });
    await _client.connect();
    await _client.query(`
        CREATE TABLE IF NOT EXISTS bot_auth (
            key   TEXT PRIMARY KEY,
            value TEXT NOT NULL
        )
    `);
    return _client;
}

async function readAuth(key) {
    try {
        const db  = await getClient();
        const res = await db.query('SELECT value FROM bot_auth WHERE key = $1', [key]);
        if (!res.rows.length) return null;
        return JSON.parse(res.rows[0].value);
    } catch {
        return null;
    }
}

async function writeAuth(key, value) {
    try {
        const db = await getClient();
        await db.query(
            `INSERT INTO bot_auth (key, value) VALUES ($1, $2)
             ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value`,
            [key, JSON.stringify(value)]
        );
    } catch (e) {
        console.error('[Auth] Write failed:', e.message);
    }
}

async function deleteAuth(key) {
    try {
        const db = await getClient();
        await db.query('DELETE FROM bot_auth WHERE key = $1', [key]);
    } catch {}
}

// ── Drop-in replacement for useMultiFileAuthState ────────────
export async function useSupabaseAuthState() {
    const { initAuthCreds, BufferJSON, proto } = await import('@whiskeysockets/baileys');

    let creds = await readAuth('creds');
    if (!creds) creds = initAuthCreds();

    const keys = {};

    const state = {
        creds,
        keys: {
            get: async (type, ids) => {
                const data = {};
                for (const id of ids) {
                    let value = keys[`${type}-${id}`];
                    if (!value) {
                        value = await readAuth(`key-${type}-${id}`);
                    }
                    if (value) {
                        if (type === 'app-state-sync-key') {
                            value = proto.Message.AppStateSyncKeyData.fromObject(value);
                        }
                        data[id] = value;
                    }
                }
                return data;
            },
            set: async (data) => {
                const tasks = [];
                for (const category of Object.keys(data)) {
                    for (const id of Object.keys(data[category])) {
                        const value = data[category][id];
                        const dbKey = `key-${category}-${id}`;
                        if (value) {
                            keys[`${category}-${id}`] = value;
                            tasks.push(writeAuth(dbKey, value));
                        } else {
                            delete keys[`${category}-${id}`];
                            tasks.push(deleteAuth(dbKey));
                        }
                    }
                }
                await Promise.all(tasks);
            },
        },
    };

    const saveCreds = async () => {
        await writeAuth('creds', state.creds);
    };

    return { state, saveCreds };
}

export async function clearSupabaseAuth() {
    try {
        const db = await getClient();
        await db.query('DELETE FROM bot_auth');
        console.log('[Auth] Supabase auth cleared.');
    } catch (e) {
        console.error('[Auth] Clear failed:', e.message);
    }
}
