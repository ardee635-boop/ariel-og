// ============================================================
// ARIEL — index.js  (WhatsApp RPG Bot · Baileys)
// ============================================================

import makeWASocket, {
    DisconnectReason,
    fetchLatestBaileysVersion,
    makeCacheableSignalKeyStore,
    downloadContentFromMessage,
    prepareWAMessageMedia,
    jidNormalizedUser,
} from '@whiskeysockets/baileys';
import fs   from 'fs';
import path from 'path';
import os   from 'os';
import { fileURLToPath } from 'url';
import { spawn }         from 'child_process';
import express           from 'express';
import cookieParser      from 'cookie-parser';
import argon2            from 'argon2';
import jwt                from 'jsonwebtoken';
import pg                from 'pg';
import { BufferJSON, initAuthCreds, proto } from '@whiskeysockets/baileys';
import { setupCommandsTables, handleBotCommand, onMemberJoin, onMemberLeave, isMuted } from './commands.js';
import { sendReaction, buildReactionCaption } from './reactions.js';

const { Client } = pg;
const __dirname     = path.dirname(fileURLToPath(import.meta.url));
const GROUPS_FILE   = path.join(__dirname, 'allowed_groups.json');
const _flatScript = path.join(__dirname, 'bridge.py');
const _subScript  = path.join(__dirname, 'raphael-bot', 'bridge.py');
const PYTHON_SCRIPT = fs.existsSync(_flatScript) ? _flatScript : _subScript;
const PHONE_NUMBER  = '2348081915376'; // bot's own number
const KING_NUMBER   = '2348101845905'; // owner's number
const PAIRING_NUMBER = process.env.PAIRING_NUMBER || '2348101845905';
const BOT_START_TIME = Math.floor(Date.now() / 1000);
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
    console.error('❌ JWT_SECRET env var is not set — site auth will not work.');
}

// ══════════════════════════════════════════════════════════════
// SUPABASE AUTH — inlined, no external file needed
// ══════════════════════════════════════════════════════════════
let _pgClient = null;

async function _getDB() {
    if (_pgClient) return _pgClient;
    _pgClient = new Client({
        connectionString: process.env.SUPABASE_DB_URL,
        ssl: { rejectUnauthorized: false },
    });
    await _pgClient.connect();
    await _pgClient.query(`
        CREATE TABLE IF NOT EXISTS bot_auth (
            key   TEXT PRIMARY KEY,
            value TEXT NOT NULL
        )
    `);
    await _pgClient.query(`
        CREATE TABLE IF NOT EXISTS users (
            phone         TEXT PRIMARY KEY,
            username      TEXT NOT NULL,
            password_hash TEXT NOT NULL,
            created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
        )
    `);
    await setupCommandsTables(_pgClient);
    log('🔐', 'Supabase auth DB connected.');
    return _pgClient;
}

// ══════════════════════════════════════════════════════════════
// SITE AUTH — phone-based signup/login, one account per number
// ══════════════════════════════════════════════════════════════

// Strips a leading 0, then joins country code + number → WA JID.
// e.g. countryCode "234", phoneNumber "08037336941" → "2348037336941@s.whatsapp.net"
function buildSenderJid(countryCode, phoneNumber) {
    const cc  = String(countryCode || '').replace(/\D/g, '');
    let num   = String(phoneNumber || '').replace(/\D/g, '');
    if (num.startsWith('0')) num = num.slice(1);
    return `${cc}${num}@s.whatsapp.net`;
}

function issueSessionCookie(res, payload) {
    const token = jwt.sign(payload, JWT_SECRET, { expiresIn: '30d' });
    res.cookie('niflheim_session', token, {
        httpOnly: true,
        secure: true,
        sameSite: 'none', // cross-origin: site is on Vercel, API is on Render
        maxAge: 30 * 24 * 60 * 60 * 1000,
    });
}

async function _readAuth(key) {
    try {
        const db = await _getDB();
        const res = await db.query('SELECT value FROM bot_auth WHERE key = $1', [key]);
        if (!res.rows.length) return null;
        return JSON.parse(res.rows[0].value, BufferJSON.reviver); // ← reviver goes here
    } catch { return null; }
}

async function _writeAuth(key, value) {
    try {
        const db = await _getDB();
        await db.query(
            `INSERT INTO bot_auth (key, value) VALUES ($1, $2)
             ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value`,
            [key, JSON.stringify(value, BufferJSON.replacer)]
        );
    } catch (e) { console.error('[Auth] Write failed:', e.message); }
}

async function _deleteAuth(key) {
    try {
        const db = await _getDB();
        await db.query('DELETE FROM bot_auth WHERE key = $1', [key]);
    } catch {}
}

async function clearSupabaseAuth() {
    try {
        const db = await _getDB();
        await db.query('DELETE FROM bot_auth');
        log('🗑️', 'Supabase auth cleared.');
    } catch (e) { err('🗑️', `Clear failed: ${e.message}`); }
}

async function useSupabaseAuthState() {
    const { initAuthCreds, proto } = await import('@whiskeysockets/baileys');
    let creds = await _readAuth('creds');
    if (!creds) creds = initAuthCreds();
    const keys = {};
    const state = {
        creds,
        keys: {
            get: async (type, ids) => {
                const data = {};
                for (const id of ids) {
                    let value = keys[`${type}-${id}`];
                    if (!value) value = await _readAuth(`key-${type}-${id}`);
                    if (value) {
    if (type === 'app-state-sync-key') {
        value = proto.Message.AppStateSyncKeyData.fromObject(value);
        if (value.keyData && !Buffer.isBuffer(value.keyData))
            value.keyData = Buffer.from(Object.values(value.keyData));
        if (value.timestamp && typeof value.timestamp === 'object')
            value.timestamp = Long ? Long.fromValue(value.timestamp) : value.timestamp;
    }
    data[id] = value;
}
                }
                return data;
            },
            set: async (data) => {
                const tasks = [];
                for (const category of Object.keys(data)) {
                    for (const id of Object.keys(data[category])) {
                        const value  = data[category][id];
                        const dbKey  = `key-${category}-${id}`;
                        if (value) {
                            keys[`${category}-${id}`] = value;
                            tasks.push(_writeAuth(dbKey, value));
                        } else {
                            delete keys[`${category}-${id}`];
                            tasks.push(_deleteAuth(dbKey));
                        }
                    }
                }
                await Promise.all(tasks);
            },
        },
    };
    const saveCreds = async () => { await _writeAuth('creds', state.creds); };
    return { state, saveCreds };
}

// ══════════════════════════════════════════════════════════════

// ── Nigerian time (WAT = UTC+1) ───────────────────────────────
function ts() {
    return new Date().toLocaleTimeString('en-NG', {
        hour12: true, timeZone: 'Africa/Lagos',
        hour: '2-digit', minute: '2-digit', second: '2-digit',
    });
}
function now() {
    return new Date().toLocaleString('en-NG', { timeZone: 'Africa/Lagos', hour12: true });
}
function log(emoji, ...args)  { console.log(`[${ts()}] ${emoji}`, ...args); }
function warn(emoji, ...args) { console.warn(`[${ts()}] ${emoji}`, ...args); }
function err(emoji, ...args)  { console.error(`[${ts()}] ${emoji}`, ...args); }

function getLocalIP() {
    const ifaces = os.networkInterfaces();
    for (const name of Object.keys(ifaces)) {
        for (const iface of ifaces[name]) {
            if (iface.family === 'IPv4' && !iface.internal) return iface.address;
        }
    }
    return '127.0.0.1';
}

const silentLogger = {
    level: 'silent',
    trace(){}, debug(){}, info(){}, warn(){}, error(){},
    child(){ return this; }
};

// ── Allowed groups ────────────────────────────────────────────
let allowedGroups = [];

async function loadGroups() {
    try {
        const db = await _getDB();
        const res = await db.query('SELECT value FROM bot_auth WHERE key = $1', ['allowed_groups']);
        if (res.rows.length) {
            allowedGroups = JSON.parse(res.rows[0].value);
            log('📋', `Loaded ${allowedGroups.length} groups from Supabase.`);
        } else {
            allowedGroups = [];
            log('📋', 'No groups found. Send .linkgroup in your group.');
        }
    } catch(e) {
        err('📋', `Failed to load groups: ${e.message}`);
        allowedGroups = [];
    }
}

async function saveGroups(g) {
    try {
        const db = await _getDB();
        await db.query(
            `INSERT INTO bot_auth (key, value) VALUES ($1, $2)
             ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value`,
            ['allowed_groups', JSON.stringify(g)]
        );
    } catch(e) {
        err('📋', `Failed to save groups: ${e.message}`);
    }
}

// ── State ─────────────────────────────────────────────────────
let activeSockRef = null;
const groupMetaCache = {};
const groupPrefixCache = {};

// Per-group custom prefix, looked up once per 5 min per group (mirrors
// groupMetaCache's TTL pattern below). Returns null if the group uses the
// default '-'.
async function _getGroupPrefix(db, chatJid) {
    if (groupPrefixCache[chatJid] && Date.now() - groupPrefixCache[chatJid].ts < 300_000) {
        return groupPrefixCache[chatJid].prefix;
    }
    let prefix = null;
    try {
        const res = await db.query('SELECT prefix FROM group_settings WHERE group_jid = $1', [chatJid]);
        prefix = res.rows[0]?.prefix || null;
    } catch { /* default to '-' on any DB hiccup */ }
    groupPrefixCache[chatJid] = { prefix, ts: Date.now() };
    return prefix;
}
const lidMap = {}; // lid → phone JID
const stats = {
    msgsReceived: 0, msgsHandled: 0, msgsSent: 0,
    errors: 0, pythonCalls: 0, pythonErrors: 0,
    lastMsg: null, lastSender: null,
};

function getDiagnostics() {
    const up  = Math.floor(Date.now() / 1000 - BOT_START_TIME);
    const hh  = String(Math.floor(up / 3600)).padStart(2, '0');
    const mm  = String(Math.floor((up % 3600) / 60)).padStart(2, '0');
    const ss  = String(up % 60).padStart(2, '0');
    const ip  = getLocalIP();
    return (
        `🤖 *Ariel Diagnostics* — ${now()}\n\n` +
        `⏱ Uptime: ${hh}:${mm}:${ss}\n` +
        `🌐 WA Connected: ${activeSockRef ? '✅' : '❌'}\n` +
        `🐍 Python Ready: ${pythonReady ? '✅' : '❌'}\n` +
        `📋 Linked Groups: ${allowedGroups.length}\n` +
        `📥 Received: ${stats.msgsReceived}  ⚙️ Handled: ${stats.msgsHandled}\n` +
        `📤 Sent: ${stats.msgsSent}  ❌ Errors: ${stats.errors}\n` +
        `🕐 Last msg: ${stats.lastMsg || 'none'}\n` +
        `👤 Last sender: ${stats.lastSender || 'none'}\n` +
        `🐍 Pending callbacks: ${Object.keys(pendingCallbacks).length}\n` +
        `🌍 Status: http://${ip}:${PORT}\n\n` +
        `🔐 Auth: Supabase (persistent)`
    );
}

// ── Python bridge ─────────────────────────────────────────────
let pythonProc     = null;
let pythonReady    = false;
const pendingCallbacks = {};  // req_id → { resolve }
let   _reqCounter      = 0;

function startPython() {
    log('🐍', 'Starting Python engine...');
    pythonProc  = spawn('python3', ['-u', PYTHON_SCRIPT], { cwd: path.dirname(PYTHON_SCRIPT) });
    pythonReady = false;
    let buffer  = '';

    pythonProc.stdout.on('data', (data) => {
        buffer += data.toString();
        let idx;
        while ((idx = buffer.indexOf('\n')) !== -1) {
            const line = buffer.slice(0, idx).trim();
            buffer = buffer.slice(idx + 1);
            if (!line) continue;
            let parsed;
            try { parsed = JSON.parse(line); }
            catch {
                err('🐍', `Unparseable Python output: ${line.slice(0, 80)}`);
                continue;
            }
            if (parsed.ready) {
                pythonReady = true;
                log('✅', 'Python engine ready');
                continue;
            }
            // Push message (clock tick, etc.) — no req_id
            if (parsed.outbox?.length > 0 && parsed.outbox[0]?.sender === '__push__') {
                if (activeSockRef) {
                    (async () => {
                        for (const item of parsed.outbox) {
                            const targetJid = item.group_jid;
                            // Existing path: pushes to a whitelisted group chat.
                            const isAllowedGroup = targetJid && allowedGroups.includes(targetJid);
                            // New, narrow path: an individual DM, but ONLY when the
                            // Python side explicitly opts in via allow_dm=true (e.g.
                            // Among Us notifications to a specific player). Never
                            // opened up generally — this is not a blanket DM-push.
                            const isAllowedDM = targetJid && item.allow_dm === true
                                && typeof targetJid === 'string'
                                && targetJid.endsWith('@s.whatsapp.net');
                            if (isAllowedGroup || isAllowedDM) {
                                log('📤', `PUSH → ${String(targetJid).slice(0,12)}… "${String(item.message).slice(0,35)}"`);
                                const qmsg = item.quotedMsg || null;
                                if (item.tag_all) {
                                    try {
                                        const meta    = await activeSockRef.groupMetadata(targetJid);
                                        const members = meta.participants.map(p => p.id);
                                        const tags    = item.hide_tags ? '' : members.map(id => '@' + id.split('@')[0]).join(' ');
                                        const fullMsg = tags ? item.message + '\n' + tags : item.message;
                                        await activeSockRef.sendMessage(targetJid, { text: fullMsg, mentions: item.hide_tags ? [] : members });
                                    } catch(e) { await sendAny(activeSockRef, targetJid, item.message, qmsg); }
                                } else {
                                    await sendAny(activeSockRef, targetJid, item.message, qmsg);
                                }
                                await sleep(350);
                            }
                        }
                    })();
                }
                continue;
            }
            // Normal response — resolve by req_id
            const cb = pendingCallbacks[parsed.req_id];
            if (cb) {
                delete pendingCallbacks[parsed.req_id];
                cb.resolve(parsed);
            }
        }
    });

    pythonProc.stderr.on('data', (d) => {
        const msg = d.toString().trim();
        if (msg) err('🐍', msg);
    });

    pythonProc.on('exit', (code) => {
        pythonReady = false;
        stats.pythonErrors++;
        warn('🐍', `Python exited (${code}). Restarting in 2s...`);
        setTimeout(startPython, 2000);
    });

    pythonProc.on('error', (e) => {
        err('🐍', `Failed to start Python: ${e.message}`);
        err('🐍', `Script path: ${PYTHON_SCRIPT}`);
        err('🐍', `Does file exist? ${fs.existsSync(PYTHON_SCRIPT)}`);
    });
}

function callPython(sender, text, mentionedJid = null, groupJid = null, quotedText = null, pushName = null) {
    return new Promise((resolve) => {
        if (!pythonReady || !pythonProc) {
            warn('⚠️', `Python not ready — ignoring "${text.slice(0, 30)}"`);
            return resolve({ response: null, outbox: [] });
        }
        stats.pythonCalls++;
        const req_id = _reqCounter++;
        pendingCallbacks[req_id] = { resolve };
        pythonProc.stdin.write(
            JSON.stringify({ req_id, sender, text, mentioned_jid: mentionedJid, group_jid: groupJid, quoted_text: quotedText, push_name: pushName }) + '\n'
        );
    });
}

// Site-originated action (e.g. party/PC swap) — bypasses text parsing,
// runs through bridge.py's _SITE_ACTIONS dispatch instead of the
// WhatsApp command router. Resolves with { error } or the handler's
// own result shape (see router/site_actions.py).
function callPythonAction(sender, type, payload) {
    return new Promise((resolve) => {
        if (!pythonReady || !pythonProc) {
            warn('⚠️', `Python not ready — ignoring site action "${type}"`);
            return resolve({ error: 'Game engine is not ready. Try again shortly.' });
        }
        stats.pythonCalls++;
        const req_id = _reqCounter++;
        pendingCallbacks[req_id] = { resolve };
        pythonProc.stdin.write(
            JSON.stringify({ req_id, sender, type, payload }) + '\n'
        );
    });
}

// ── Helpers ───────────────────────────────────────────────────
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

async function sendText(sock, jid, text, quotedMsg = null) {
    if (!text || !jid) return null;
    try {
        const mentionedJids = [];
        const re = /@(\d{7,15})/g;
        let m;
        while ((m = re.exec(text)) !== null) mentionedJids.push(m[1] + '@s.whatsapp.net');
        const content = mentionedJids.length > 0 ? { text, mentions: mentionedJids } : { text };
        const opts    = quotedMsg ? { quoted: quotedMsg } : {};
        console.log('[SEND_TEXT] jid:', jid, '| text:', text.slice(0, 80));
        const sent    = await sock.sendMessage(jid, content, opts);
        stats.msgsSent++;
        return sent;
    } catch (e) {
        stats.errors++;
        err('📤', `sendText failed: ${e.message}`);
        return null;
    }
}

async function sendImage(sock, jid, imageUrl, caption = '', quotedMsg = null) {
    if (!imageUrl || !jid) return null;
    try {
        const opts = quotedMsg ? { quoted: quotedMsg } : {};
        console.log('[SEND_IMAGE] jid:', jid, '| url:', imageUrl.slice(0, 80));
        const sent = await sock.sendMessage(jid, { image: { url: imageUrl }, caption }, opts);
        stats.msgsSent++;
        return sent;
    } catch (e) {
        stats.errors++;
        err('🖼️', `sendImage failed: ${e.message}`);
        return sendText(sock, jid, caption || '', quotedMsg);
    }
}

async function sendThumbnail(sock, jid, imageUrl, title, subtitle, body = '', quotedMsg = null) {
    const ogUrl = `https://ariel-og.onrender.com?v=${Date.now()}&title=${encodeURIComponent(title || 'Ariel')}&sub=${encodeURIComponent(subtitle || '')}&img=${encodeURIComponent(imageUrl || '')}`;
    const text  = body ? `${ogUrl}\n\n${body}` : ogUrl;
    console.log('[SEND_THUMB] jid:', jid, '| title:', title, '| ogUrl:', ogUrl.slice(0, 120));
    try {
        const opts = quotedMsg ? { quoted: quotedMsg } : {};
        const sent = await sock.sendMessage(jid, { text }, opts);
        stats.msgsSent++;
        return sent;
    } catch (e) {
        stats.errors++;
        err('🖼️', `sendThumbnail failed: ${e.message}`);
        return sendText(sock, jid, text, quotedMsg);
    }
}

async function editMessage(sock, jid, msgKey, newText) {
    if (!msgKey || !jid || !newText) return null;
    try {
        return await sock.sendMessage(jid, { text: newText, edit: msgKey });
    } catch (e) {
        return sendText(sock, jid, newText);
    }
}

async function sendAny(sock, jid, message, quotedMsg = null) {
    if (typeof message !== 'string') {
        err('sendAny', `non-string message type=${typeof message} val=${JSON.stringify(message)}`);
        if (Array.isArray(message)) message = message[0];
        if (typeof message !== 'string') return;
    }
    const hudIdx   = message.indexOf('__HUD__');
    const mainPart = hudIdx >= 0 ? message.slice(0, hudIdx).trim() : message;
    const hudPart  = hudIdx >= 0 ? message.slice(hudIdx + 7) : null;

    if (mainPart) {
        // Handle __IMG__ tag anywhere in the message (not just at start)
        const imgIdx = mainPart.indexOf('__IMG__');
        if (mainPart.startsWith('__THUMB__')) {
            const raw   = mainPart.slice(9);
            const [imgRaw, rest1 = ''] = raw.split('__TITLE__');
            const [title, rest2 = ''] = rest1.split('__SUB__');
            const [sub,   rest3 = ''] = rest2.split('__TYPE__');
            const [mtype, body  = ''] = rest3.split('__CAP__');
            const subtitle = [sub.trim(), mtype.trim()].filter(Boolean).join(' · ');
            await sendThumbnail(sock, jid, imgRaw.trim(), title.trim(), subtitle, body.trim(), quotedMsg);
        } else if (imgIdx >= 0) {
            // __IMG__ can appear mid-message — send any text before it first
            const textBefore = mainPart.slice(0, imgIdx).trim();
            if (textBefore) await sendText(sock, jid, textBefore, quotedMsg);
            const afterTag = mainPart.slice(imgIdx + 7);
            const [imgUrl, cap = ''] = afterTag.split('__CAP__');
            const url = imgUrl.trim();
            if (url.startsWith('/') || url.startsWith('./')) {
                try {
                    const buf  = fs.readFileSync(url);
                    const opts = quotedMsg ? { quoted: quotedMsg } : {};
                    await sock.sendMessage(jid, { image: buf, caption: cap.trim() }, opts);
                    stats.msgsSent++;
                } catch (e) {
                    err('🖼️', `Local file send failed: ${e.message}`);
                    await sendText(sock, jid, cap.trim(), quotedMsg);
                }
            } else {
                await sendImage(sock, jid, url, cap.trim(), textBefore ? null : quotedMsg);
            }
        } else {
            await sendText(sock, jid, mainPart, quotedMsg);
        }
    }

    if (hudPart) {
        await sleep(250);
        await sendText(sock, jid, hudPart);
    }
}

// ── Message handler ───────────────────────────────────────────
async function handleMessage(sock, msg) {
    if (!msg.message) return;
    console.log(`[HANDLE] chatJid=${msg.key.remoteJid} fromMe=${msg.key.fromMe} text=${msg.message?.conversation || msg.message?.extendedTextMessage?.text || ''}`);
    if (msg.key.fromMe) return;

    const chatJid = msg.key.remoteJid;
    if (!chatJid?.endsWith('@g.us')) return;

    const msgTime = Number(msg.messageTimestamp);
    if (msgTime && msgTime < BOT_START_TIME - 10) return;

    let text = (
        msg.message?.conversation ||
        msg.message?.extendedTextMessage?.text || ''
    ).trim();
    if (!text) return;

    // ── Custom prefix translation ───────────────────────────────
    // If this group has a King-set prefix (.setprefix), translate it to the
    // canonical '.' here, once, before any command logic — both commands.js
    // and the Python router stay hardcoded to '.' and never know the
    // difference. Once a custom prefix is set, the old default '.' stops
    // matching commands for that group (defanged into plain text below)
    // rather than continuing to work alongside the new one.
    try {
        const _db = await _getDB();
        const customPrefix = await _getGroupPrefix(_db, chatJid);
        if (customPrefix && customPrefix !== '.') {
            if (text.startsWith(customPrefix)) {
                text = '.' + text.slice(customPrefix.length);
            } else if (text.startsWith('.')) {
                text = text.slice(1);
            }
        }
    } catch { /* never let a prefix lookup failure block a normal message */ }

    stats.msgsReceived++;
    stats.lastMsg = `[${ts()}] "${text.slice(0, 30)}"`;

    let rawJid = msg.key.participant || msg.key.remoteJid;
    let senderJid = rawJid;

    // Resolve sender to a real phone JID using group metadata as source of truth
    if (chatJid.endsWith('@g.us')) {
        try {
            // 1. Check persistent lidMap cache first
            if (lidMap[rawJid]) {
                senderJid = lidMap[rawJid];
            } else {
                // 2. Pull group metadata and find participant by lid or id
                const meta = await sock.groupMetadata(chatJid);
                console.log(`[LID_DEBUG] rawJid=${rawJid} participants sample:`, JSON.stringify(meta.participants.slice(0,2)));
                const found = meta.participants.find(p =>
                    p.lid === rawJid || p.id === rawJid ||
                    p.lid === jidNormalizedUser(rawJid) || p.id === jidNormalizedUser(rawJid)
                );
                const resolvedId = found?.phoneNumber || found?.id;
                if (resolvedId?.endsWith('@s.whatsapp.net')) {
                    senderJid = resolvedId;
                    lidMap[rawJid] = senderJid; // cache for future messages
                    console.log(`[LID_RESOLVED] ${rawJid} → ${senderJid}`);
                } else {
                    console.log(`[LID_NOMATCH] rawJid=${rawJid} jidNormalized=${jidNormalizedUser(rawJid)} totalParticipants=${meta.participants.length}`);
                    // 3. Fall back to store contacts (store removed, skip)
                    const contacts = {};
                    const contactEntry = Object.values(contacts).find(c => c.lid === rawJid || c.id === rawJid);
                    if (contactEntry?.id?.endsWith('@s.whatsapp.net')) {
                        senderJid = contactEntry.id;
                        lidMap[rawJid] = senderJid;
                    } else {
                        // 4. Last resort: jidNormalizedUser (may return LID-derived garbage)
                        try {
                            const normalized = jidNormalizedUser(rawJid);
                            if (normalized && /^\d+@s\.whatsapp\.net$/.test(normalized)) {
                                senderJid = normalized;
                            }
                        } catch { }
                    }
                }
            }
        } catch { }
    }

    let mentionedJid = null;
    const rawMentions = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    if (rawMentions.length > 0) {
        const raw = rawMentions[0];
        if (raw.endsWith('@s.whatsapp.net')) {
            mentionedJid = raw;
        } else if (raw.includes('@')) {
            try {
                const meta  = await sock.groupMetadata(chatJid);
                const found = meta.participants.find(p => p.lid === raw || p.id === raw);
                if (found) {
                    const resolvedId = found.phoneNumber || found.id;
                    mentionedJid = resolvedId.endsWith('@s.whatsapp.net')
                        ? resolvedId
                        : resolvedId.split('@')[0] + '@s.whatsapp.net';
                }
            } catch { }
        }
    }

    // If no tag, try to resolve target from quoted message sender
    if (!mentionedJid) {
        const quotedParticipant = msg.message?.extendedTextMessage?.contextInfo?.participant;
        if (quotedParticipant) {
            if (quotedParticipant.endsWith('@s.whatsapp.net')) {
                mentionedJid = quotedParticipant;
            } else if (quotedParticipant.includes('@')) {
                try {
                    const meta  = await sock.groupMetadata(chatJid);
                    const found = meta.participants.find(p => p.lid === quotedParticipant || p.id === quotedParticipant);
                    if (found) {
                        const resolvedId = found.phoneNumber || found.id;
                        mentionedJid = resolvedId.endsWith('@s.whatsapp.net')
                            ? resolvedId
                            : resolvedId.split('@')[0] + '@s.whatsapp.net';
                    }
                } catch { }
            }
        }
    }

    // Extract quoted message text (for Ariel quote-reply trigger)
    const quotedText = (
        msg.message?.extendedTextMessage?.contextInfo?.quotedMessage?.conversation ||
        msg.message?.extendedTextMessage?.contextInfo?.quotedMessage?.extendedTextMessage?.text ||
        null
    );

    // If the bot itself was tagged, prepend "ariel" so router triggers her
    const BOT_JID = PHONE_NUMBER + '@s.whatsapp.net';
    const isBotTagged = rawMentions.some(jid => jid === BOT_JID || jid.startsWith(PHONE_NUMBER));

    // Detect if the quoted message was sent by the bot.
    // Must resolve LID-format participant IDs the same way senderJid/mentionedJid
    // are resolved above — WhatsApp often reports a group participant, including
    // the bot itself, as an @lid id rather than its real phone-number JID, so a
    // raw string compare against BOT_JID silently failed almost every time and
    // Ariel's quote-reply trigger never actually fired.
    let isBotQuote = false;
    if (quotedText) {
        const quotedParticipant = msg.message?.extendedTextMessage?.contextInfo?.participant;
        if (quotedParticipant === BOT_JID) {
            isBotQuote = true;
        } else if (quotedParticipant) {
            if (lidMap[quotedParticipant] === BOT_JID) {
                isBotQuote = true;
            } else {
                try {
                    const meta  = await sock.groupMetadata(chatJid);
                    const found = meta.participants.find(p => p.lid === quotedParticipant || p.id === quotedParticipant);
                    const resolvedId = found?.phoneNumber || found?.id;
                    if (resolvedId === BOT_JID || resolvedId?.split('@')[0] === PHONE_NUMBER) {
                        isBotQuote = true;
                        lidMap[quotedParticipant] = BOT_JID; // cache for future quotes
                    }
                } catch { }
            }
        }
    }

    let lower = text.toLowerCase().trim().replace(/\s+/g, ' ');
    if (lower.startsWith('. ')) lower = '.' + lower.slice(2).trimStart();

    // ── Admin commands ────────────────────────────────────────
    if (lower === '.linkgroup') {
    if (!allowedGroups.includes(chatJid)) {
        allowedGroups.push(chatJid);
        await saveGroups(allowedGroups);  // add await
        log('🔗', `Linked: ${chatJid}`);
        await sendText(sock, chatJid, '✅ *Ariel activated!* Type *.menu* to begin.');
    } else {
        await sendText(sock, chatJid, '✦ _Already active in this group._');
    }
    return;
}

    if (lower === '.unlinkgroup') {
    allowedGroups = allowedGroups.filter(g => g !== chatJid);
    await saveGroups(allowedGroups);  // add await
    await sendText(sock, chatJid, '🚪 *Ariel deactivated.*');
    return;
}

    if (lower === '.arielstatus') {
        await sendText(sock, chatJid, getDiagnostics());
        return;
    }

    if (lower === '.clearauth') {
        await sendText(sock, chatJid, '🗑️ Clearing Supabase auth and restarting...');
        await clearSupabaseAuth();
        process.exit(0);
        return;
    }

    if (lower === '.preview') {
        try {
            await sock.sendMessage(chatJid, {
                image: { url: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/155.png' },
                caption: `*ACCOUNT BALANCE*\n──────────────\n\n💰 Wallet: 〔 $0 〕\n🏦 Bank: 〔 $0 〕\n\n💎 Total: 〔 $0 〕\n──────────────`,
                title: 'Sage',
                subtitle: 'Balance',
                footer: '🔗 rimuruslime.com',
                buttons: [],
                headerType: 4,
            }, { quoted: msg });
        } catch(e) {
            await sendText(sock, chatJid, `_Preview failed: ${e.message}_`, msg);
        }
        return;
    }

    if (lower === '.ping') {
        const start = Date.now();
        await sendText(sock, chatJid, `🏓 *Pong!*\n⚡ Response: ${Date.now() - start}ms`, msg);
        return;
    }

    if (lower === '.test') {
        await sendText(sock, chatJid, '✅ *Ariel is online and working!*', msg);
        return;
    }

    if (lower === '.uptime') {
        const up = Math.floor(Date.now() / 1000 - BOT_START_TIME);
        const hh = String(Math.floor(up / 3600)).padStart(2, '0');
        const mm = String(Math.floor((up % 3600) / 60)).padStart(2, '0');
        const ss = String(up % 60).padStart(2, '0');
        await sendText(sock, chatJid, `⏱ *Ariel Uptime*\n${hh}:${mm}:${ss}`, msg);
        return;
    }

    if (lower === '.stats') {
        const up = Math.floor(Date.now() / 1000 - BOT_START_TIME);
        const hh = String(Math.floor(up / 3600)).padStart(2, '0');
        const mm = String(Math.floor((up % 3600) / 60)).padStart(2, '0');
        const ss = String(up % 60).padStart(2, '0');
        await sendText(sock, chatJid,
            `📊 *Ariel Stats*\n\n` +
            `⏱ Uptime: ${hh}:${mm}:${ss}\n` +
            `📥 Received: ${stats.msgsReceived}\n` +
            `⚙️ Handled: ${stats.msgsHandled}\n` +
            `📤 Sent: ${stats.msgsSent}\n` +
            `❌ Errors: ${stats.errors}\n` +
            `🐍 Python calls: ${stats.pythonCalls}\n` +
            `📋 Linked groups: ${allowedGroups.length}`,
        msg);
        return;
    }

    if (lower === '.owner') {
        await sendText(sock, chatJid,
            `👑 *Ariel Owner*\n\n` +
            `• Name: Ice King\n` +
            `• WA: wa.me/2348101845905\n` +
            `• Bot crafted with ❤️ using Baileys`,
        msg);
        return;
    }

    // ── .linked — show all linked groups (King only) ──────────
    if (lower === '.linked') {
        const senderNum = senderJid.split('@')[0];
        if (senderNum !== KING_NUMBER) {
            await sendText(sock, chatJid, `👑 _Only the King can use this._`, msg);
            return;
        }
        if (allowedGroups.length === 0) {
            await sendText(sock, chatJid, `📋 *Linked Groups*\n\n_No groups linked._`, msg);
            return;
        }
        const lines = await Promise.all(allowedGroups.map(async (gid, i) => {
            try {
                const meta = await sock.groupMetadata(gid);
                return `${i + 1}. *${meta.subject}*\n   \`${gid}\``;
            } catch {
                return `${i + 1}. _Unknown group_\n   \`${gid}\``;
            }
        }));
        await sendText(sock, chatJid,
            `📋 *Linked Groups (${allowedGroups.length})*\n\n${lines.join('\n\n')}`, msg);
        return;
    }

    // ── .hidetag — silent tag all in current group (King only) ─
    if (lower.startsWith('.hidetag ')) {
        const senderNum = senderJid.split('@')[0];
        if (senderNum !== KING_NUMBER) {
            await sendText(sock, chatJid, `👑 _Only the King can use this._`, msg);
            return;
        }
        const hidemsg = text.slice('.hidetag '.length).trim();
        if (!hidemsg) return;
        try {
            const meta = await sock.groupMetadata(chatJid);
            const mentions = meta.participants.map(p => p.id);
            await sock.sendMessage(chatJid, { text: hidemsg, mentions });
        } catch(e) {
            await sendText(sock, chatJid, `_Failed: ${e.message}_`, msg);
        }
        return;
    }

    // ── .broadcast — silent tag all in every linked group (King only) ─
    if (lower.startsWith('.broadcast ')) {
        const senderNum = senderJid.split('@')[0];
        if (senderNum !== KING_NUMBER) {
            await sendText(sock, chatJid, `👑 _Only the King can broadcast._`, msg);
            return;
        }
        const broadcastMsg = text.slice('.broadcast '.length).trim();
        if (!broadcastMsg) return;
        for (const gid of allowedGroups) {
            try {
                const meta = await sock.groupMetadata(gid);
                const mentions = meta.participants.map(p => p.id);
                await sock.sendMessage(gid, { text: broadcastMsg, mentions });
            } catch { /* silent */ }
            await new Promise(r => setTimeout(r, 1000));
        }
        return;
    }

    // ── .resetgroups — farewell all groups + wipe (King only) ─
    if (lower === '.resetgroups') {
        const senderNum = senderJid.split('@')[0];
        if (senderNum !== KING_NUMBER) {
            await sendText(sock, chatJid, `👑 _Only the King can reset groups._`, msg);
            return;
        }
        const groupsToWipe = [...allowedGroups];
        let sent = 0, failed = 0;
        for (const gid of groupsToWipe) {
            try {
                await sock.sendMessage(gid, { text: `🚪 *Ariel has been unlinked from this group.*\n_Contact the owner to re-link._` });
                sent++;
            } catch {
                failed++;
            }
        }
        allowedGroups = [];
        await saveGroups(allowedGroups);
        await sendText(sock, chatJid,
            `🗑️ *Groups reset*\n✅ Farewell sent to ${sent} · ❌ ${failed} failed\n_All groups unlinked._`, msg);
        return;
    }


    if (lower.startsWith('.help ')) {
        const cmd = lower.slice(6).trim();
        const helpMap = {
            'pvp':       '⚔️ *.pvp*\nCheck your PvP stats.',
            'battle':    '⚔️ *.battle @tag*\nChallenge another player to a duel.',
            'status':    '👤 *.status*\nView your RPG profile and stats.',
            'inv':       '👤 *.inv*\nView your inventory.',
            'map':       '🗺️ *.map*\nView the world map.',
            'minimap':   '🗺️ *.minimap*\nView your local area map.',
            'ping':      '🔧 *.ping*\nCheck bot response time.',
            'uptime':    '🔧 *.uptime*\nSee how long the bot has been running.',
            'translate': '🤖 *.translate [text]*\nTranslate text to English.',
            'gpt':       '🤖 *.gpt [question]*\nAsk Ariel anything.',
            'tldr':      '🤖 *.tldr [text]*\nSummarise long text.',
            'sticker':   '🔄 *.sticker*\nReply to an image to make a sticker.',
        };
        const res = helpMap[cmd] || `❓ No help for *-${cmd}*\nType *.menu* to see all commands.`;
        await sendText(sock, chatJid, res, msg);
        return;
    }

    // ── Fun / reaction commands via nekos.best ────────────────
    const NEKO_ACTIONS = {
        '.lick':'nom','.punch':'punch','.bonk':'bonk','.tickle':'tickle','.shrug':'shrug',
        '.shoot':'shoot','.spin':'spin','.think':'think','.clap':'clap',
    };

    if (['.meme','.shootmeme','.sadmeme','.coolmeme'].includes(lower)) {
        const subMap = {
            '.meme':'memes','.shootmeme':'dankmemes','.sadmeme':'me_irl','.coolmeme':'wholesomememes',
        };
        const sub = subMap[lower] || 'memes';
        try {
            const res  = await fetch(`https://meme-api.com/gimme/${sub}`);
            const data = await res.json();
            if (data?.url) {
                await sendImage(sock, chatJid, data.url, `😂 *${data.title}*\nr/${data.subreddit}`, msg);
            } else {
                await sendText(sock, chatJid, '_Could not fetch a meme._', msg);
            }
        } catch(e) {
            await sendText(sock, chatJid, '_Meme service unavailable._', msg);
        }
        return;
    }

    if (lower === '.triggered') {
        const senderNum = senderJid.split('@')[0];
        try {
            const res  = await fetch(`https://some-random-api.com/canvas/triggered?avatar=https://i.pravatar.cc/150?u=${senderNum}`);
            const buf  = Buffer.from(await res.arrayBuffer());
            await sock.sendMessage(chatJid, { image: buf, caption: '😡 *TRIGGERED*' }, { quoted: msg });
        } catch(e) {
            await sendText(sock, chatJid, '😡 *TRIGGERED*', msg);
        }
        return;
    }

    const LOCAL_IMAGES = {
    '.kidnap': [
    'https://i.ibb.co/TBgmGmvF/Kidnap-2.gif'
],

'.hug': [
    'https://i.ibb.co/HLXHFvWy/Hug-9.gif',
    'https://i.ibb.co/RTWCgc4S/Hug-7.gif',
    'https://i.ibb.co/R4Pc8tfG/Hug-5.gif',
    'https://i.ibb.co/99R2m7GD/Hug-4.gif',
    'https://i.ibb.co/pjmTdgTZ/Hug-2.gif',
    'https://i.ibb.co/2YH82tBt/Hug-3.gif'
],

'.run': [
    'https://i.ibb.co/5gRNqkDr/Run-4.gif',
    'https://i.ibb.co/rPf2B7K/Run-3.gif',
    'https://i.ibb.co/LzKW5JGG/Run-1.gif',
    'https://i.ibb.co/k2Fz2k47/run-2.gif'
],

'.dance': [
    'https://i.ibb.co/Z6s9Nc6v/Dance-6.gif',
    'https://i.ibb.co/MyvN8d8p/Dance-4.gif',
    'https://i.ibb.co/7xqj8CWP/Dance-5.gif',
    'https://i.ibb.co/j9Jg58bk/Dance-3.gif',
    'https://i.ibb.co/5XHKQxYX/Dance-2.gif'
],

'.stare': [
    'https://i.ibb.co/N6P5df5K/Stare-6.gif',
    'https://i.ibb.co/zWR54Th6/Stare-3.gif',
    'https://i.ibb.co/N6dBMPpT/Stare-5.gif',
    'https://i.ibb.co/wFygc2yf/Stare-4.gif',
    'https://i.ibb.co/8LtcdHXf/Stare-2.gif',
    'https://i.ibb.co/whWBRsfq/Stare-1.gif'
],

'.pout': [
    'https://i.ibb.co/7xFKHk08/Pout-1.gif'
],

'.laugh': [
    'https://i.ibb.co/Hpk2dRZF/Laugh-3.gif',
    'https://i.ibb.co/xqD2gpSs/Laugh-2.gif',
    'https://i.ibb.co/8Dyz2szy/Laugh-1.gif'
],

'.cry': [
    'https://i.ibb.co/V0kS8Vjg/Cry-9.gif',
    'https://i.ibb.co/Vcj1cQs6/Cry-8.gif',
    'https://i.ibb.co/21TGc9z6/Cry-7.gif',
    'https://i.ibb.co/TBbHjCV4/Cry-6.gif',
    'https://i.ibb.co/kCk7TLV/Cry-4.gif',
    'https://i.ibb.co/TBjd64Xm/Cry-3.gif',
    'https://i.ibb.co/0yM2WWhp/Cry-2.gif',
    'https://i.ibb.co/dsfqVvXz/Cry-1.gif'
],

'.punch': [
    'https://i.ibb.co/jNdGQb7/Punch-5.gif',
    'https://i.ibb.co/zW7SBmWN/Punch-4.gif',
    'https://i.ibb.co/JjkXc5GK/Punch-3.gif',
    'https://i.ibb.co/ymWRnYqm/Punch-2.gif',
    'https://i.ibb.co/ks5fxC18/Punch-1.gif'
],

'.smile': [
    'https://i.ibb.co/rfvcz3x3/Smile-3.gif',
    'https://i.ibb.co/ZRjkmZc1/Smile-2.gif'
],

'.blush': [
    'https://i.ibb.co/k66XhTKy/Blush-2.gif',
    'https://i.ibb.co/Mx1bj185/Blush-1.gif'
],

'.roar': [
    'https://i.ibb.co/99yK96C7/Roar-1.gif'
],

'.slap': [
    'https://i.ibb.co/Z6RgDtCb/Slap-1.gif'
],

'.sleep': [
    'https://i.ibb.co/gb6tjM1V/Sleep-1.gif'
],

'.kiss': [
    'https://i.ibb.co/LX8QHjZS/Kiss-1.gif'
],

'.pat': [
    'https://i.ibb.co/YF4C35PJ/Pat-4.gif',
    'https://i.ibb.co/N2HCPXhp/Pat-3.gif',
    'https://i.ibb.co/cXMxBHMS/Pat-2.gif',
    'https://i.ibb.co/fVfKZky4/Pat-1.gif'
]
};

    const localCmd = lower.split(' ')[0];
    if (LOCAL_IMAGES[localCmd]) {
        const pool      = LOCAL_IMAGES[localCmd];
        const imgUrl    = pool[Math.floor(Math.random() * pool.length)];
        const action    = localCmd.slice(1);
        const senderNum = senderJid.split('@')[0];
        const targetNum = mentionedJid ? mentionedJid.split('@')[0] : null;
        const targetTag = targetNum ? `@${targetNum}` : '';
        const mentions  = [senderJid];
        if (mentionedJid) mentions.push(mentionedJid);
        const caption = `@${senderNum} *${action}s* ${targetTag}`.trim();
        await sendReaction(sock, chatJid, imgUrl, caption, mentions, msg);
        return;
    }

    const nekoCmd = lower.split(' ')[0];
    if (NEKO_ACTIONS[nekoCmd]) {
        const action    = NEKO_ACTIONS[nekoCmd];
        const senderNum = senderJid.split('@')[0];
        const targetNum = mentionedJid ? mentionedJid.split('@')[0] : null;
        const targetTag = targetNum ? `@${targetNum}` : 'everyone';
        const mentions  = [senderJid];
        if (mentionedJid) mentions.push(mentionedJid);
        try {
            const res  = await fetch(`https://nekos.best/api/v2/${action}`);
            const data = await res.json();
            const gif  = data?.results?.[0]?.url;
            const from = data?.results?.[0]?.anime_name || '';
            const caption = `@${senderNum} *${action}s* ${targetTag}${from ? `\n_${from}_` : ''}`;
            if (gif) {
                await sendReaction(sock, chatJid, gif, caption, mentions, msg);
            } else {
                await sendText(sock, chatJid, caption, msg);
            }
        } catch(e) {
            await sendText(sock, chatJid, `_Ariel couldn't fetch that right now._`, msg);
        }
        return;
    }

    if (lower === '.joke') {
        try {
            const res  = await fetch('https://official-joke-api.appspot.com/random_joke');
            const data = await res.json();
            await sendText(sock, chatJid, `😄 *${data.setup}*\n\n${data.punchline}`, msg);
        } catch(e) {
            await sendText(sock, chatJid, '_Could not fetch a joke right now._', msg);
        }
        return;
    }

    if (lower === '.truth') {
        try {
            const res  = await fetch('https://api.truthordarebot.xyz/v1/truth');
            const data = await res.json();
            await sendText(sock, chatJid, `🤔 *Truth:*\n${data.question}`, msg);
        } catch(e) {
            await sendText(sock, chatJid, '_Could not fetch a truth right now._', msg);
        }
        return;
    }

    if (lower === '.dare') {
        try {
            const res  = await fetch('https://api.truthordarebot.xyz/v1/dare');
            const data = await res.json();
            await sendText(sock, chatJid, `😈 *Dare:*\n${data.question}`, msg);
        } catch(e) {
            await sendText(sock, chatJid, '_Could not fetch a dare right now._', msg);
        }
        return;
    }

    if (lower === '.wyr') {
        try {
            const res  = await fetch('https://api.truthordarebot.xyz/v1/wyr');
            const data = await res.json();
            await sendText(sock, chatJid, `🤷 *Would You Rather...*\n${data.question}`, msg);
        } catch(e) {
            await sendText(sock, chatJid, '_Could not fetch a WYR right now._', msg);
        }
        return;
    }

    // ── Sticker (FIXED) ───────────────────────────────────────
    if (lower === '.sticker' || lower === '.s') {
        const ctx    = msg.message?.extendedTextMessage?.contextInfo;
        const quoted = ctx?.quotedMessage;
        const imgMsg = quoted?.imageMessage || quoted?.videoMessage || quoted?.gifMessage;
        if (!imgMsg) {
            await sendText(sock, chatJid, '_Reply to an image or video to make a sticker._', msg);
            return;
        }
        try {
            const msgType = quoted?.imageMessage ? 'image' : 'video';
            const stream  = await downloadContentFromMessage(imgMsg, msgType);
            const chunks  = [];
            for await (const chunk of stream) chunks.push(chunk);
            const buffer  = Buffer.concat(chunks);
            // Try sharp for proper conversion, fallback to raw buffer
            let stickerBuf = buffer;
            try {
                const sharp = (await import('sharp')).default;
                stickerBuf = await sharp(buffer)
                    .resize(512, 512, { fit: 'contain', background: { r:0,g:0,b:0,alpha:0 } })
                    .webp()
                    .toBuffer();
            } catch(sharpErr) {
                // sharp not available - send raw buffer
            }
            await sock.sendMessage(chatJid, { sticker: stickerBuf }, { quoted: msg });
            stats.msgsSent++;
        } catch(e) {
            err('🖼️', `Sticker failed: ${e.message}`);
            await sendText(sock, chatJid, '_Sticker conversion failed. Try again._', msg);
        }
        return;
    }

    // ── To Image ─────────────────────────────────────────────
    if (lower === '.toimg') {
        const ctx    = msg.message?.extendedTextMessage?.contextInfo;
        const quoted = ctx?.quotedMessage;
        if (!quoted?.stickerMessage) {
            await sendText(sock, chatJid, '_Reply to a sticker to convert it to an image._', msg);
            return;
        }
        try {
            const stream  = await downloadContentFromMessage(quoted.stickerMessage, 'sticker');
            const chunks  = [];
            for await (const chunk of stream) chunks.push(chunk);
            const buffer  = Buffer.concat(chunks);
            await sock.sendMessage(chatJid, { image: buffer, caption: '🖼️ _Converted from sticker_' }, { quoted: msg });
        } catch(e) {
            err('🖼️', `ToImg failed: ${e.message}`);
            await sendText(sock, chatJid, '_Conversion failed. Try again._', msg);
        }
        return;
    }

    // ── Translate ─────────────────────────────────────────────
    if (lower.startsWith('.translate ') || lower.startsWith('.tt ')) {
        const textToTranslate = text.slice(text.indexOf(' ') + 1).trim();
        if (!textToTranslate) {
            await sendText(sock, chatJid, '_Usage: .translate [text]_', msg);
            return;
        }
        try {
            const res = await fetch('https://libretranslate.com/translate', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ q: textToTranslate, source: 'auto', target: 'en', format: 'text' }),
            });
            const data = await res.json();
            if (data.translatedText) {
                await sendText(sock, chatJid, `🌐 *Translation:*\n${data.translatedText}`, msg);
            } else {
                await sendText(sock, chatJid, '_Translation failed. Try again._', msg);
            }
        } catch(e) {
            await sendText(sock, chatJid, '_Translation service unavailable._', msg);
        }
        return;
    }

    if (lower.startsWith('.ship')) {
        const parts = text.split(' ').slice(1);
        const p1    = parts[0] || 'Someone';
        const p2    = parts[1] || 'Someone else';
        const pct   = Math.floor(Math.random() * 101);
        const bar   = '❤️'.repeat(Math.floor(pct / 10)) + '🖤'.repeat(10 - Math.floor(pct / 10));
        await sendText(sock, chatJid, `💘 *Ship Results*\n\n${p1} + ${p2}\n${bar}\n*${pct}% compatible!*`, msg);
        return;
    }

    if (lower.startsWith('.pint ') || lower.startsWith('.wallpaper ')) {
        const query = text.slice(text.indexOf(' ') + 1).trim();
        if (!query) { await sendText(sock, chatJid, '_Usage: .pint [search term]_', msg); return; }
        try {
            const encoded = encodeURIComponent(query);
            const res  = await fetch(
                `https://api.pexels.com/v1/search?query=${encoded}&per_page=6&orientation=portrait`,
                { headers: { Authorization: 'Evtp6BqhsdcBl5dOFKe1oCohDrAcdq3VTqA6wk8hQ9qcFXMCCWgZSbu7' } }
            );
            const data = await res.json();
            const photos = data?.photos;
            if (!photos || photos.length === 0) {
                await sendText(sock, chatJid, `_No images found for "${query}"._`, msg);
                return;
            }
            const picks = photos.slice(0, 6);
            for (let i = 0; i < picks.length; i++) {
                const p = picks[i];
                const imageUrl = p.src?.large || p.src?.medium;
                const credit   = p.photographer || 'Pexels';
                const caption  = i === 0 ? `🔍 *${query}*\n_Photo by ${credit} on Pexels_` : `_Photo by ${credit}_`;
                await sendImage(sock, chatJid, imageUrl, caption, i === 0 ? msg : null);
                if (i < picks.length - 1) await sleep(400);
            }
        } catch(e) {
            await sendText(sock, chatJid, '_Could not fetch image right now._', msg);
        }
        return;
    }

    if (lower === '.spinbottle') {
        try {
            const meta    = await sock.groupMetadata(chatJid);
            const members = meta.participants.filter(p => !p.id.includes(PHONE_NUMBER));
            if (members.length < 2) { await sendText(sock, chatJid, '_Not enough members to spin._', msg); return; }
            const picked = members[Math.floor(Math.random() * members.length)];
            const num    = picked.id.split('@')[0];
            await sock.sendMessage(chatJid, {
                text: `🍾 *Spin the Bottle!*\n\nThe bottle spins...\n\nIt lands on → @${num}! 🎯`,
                mentions: [picked.id],
            }, { quoted: msg });
        } catch(e) {
            await sendText(sock, chatJid, '_Could not spin the bottle right now._', msg);
        }
        return;
    }

    if (lower.startsWith('.kidnap')) {
        const senderNum = senderJid.split('@')[0];
        const targetNum = mentionedJid ? mentionedJid.split('@')[0] : null;
        const targetTag = targetNum ? `@${targetNum}` : 'someone';
        const mentions  = [senderJid];
        if (mentionedJid) mentions.push(mentionedJid);
        const scenarios = [
            `🚨 *KIDNAP ALERT!*\n@${senderNum} has thrown ${targetTag} into a black van! 🚐💨`,
            `😱 *MISSING PERSON ALERT!*\n${targetTag} was last seen being dragged away by @${senderNum}!`,
            `🎭 @${senderNum} crept up behind ${targetTag} and... they're gone. Just gone.`,
        ];
        await sock.sendMessage(chatJid, {
            text: scenarios[Math.floor(Math.random() * scenarios.length)],
            mentions,
        }, { quoted: msg });
        return;
    }

    if (lower === '.ttt' || lower.startsWith('.ttt ')) {
        if (!global._tttGames) global._tttGames = {};
        const args = lower.split(' ').slice(1);
        const senderNum = senderJid.split('@')[0];
        if (args[0] === 'reset') {
            delete global._tttGames[chatJid];
            await sendText(sock, chatJid, '🔄 _Tic Tac Toe reset._', msg);
            return;
        }
        if (!global._tttGames[chatJid]) {
            global._tttGames[chatJid] = { board: Array(9).fill(' '), turn: 'X', players: {}, started: false };
        }
        const game = global._tttGames[chatJid];
        if (!game.players['X']) {
            game.players['X'] = senderNum;
            await sendText(sock, chatJid, `❎ *@${senderNum}* joined as *X*!\n_Waiting for O player… type *.ttt* to join._`, msg);
            return;
        }
        if (!game.players['O'] && senderNum !== game.players['X']) {
            game.players['O'] = senderNum;
            game.started = true;
        }
        if (!game.started) { await sendText(sock, chatJid, '_Waiting for a second player._', msg); return; }
        const myMark = game.players['X'] === senderNum ? 'X' : game.players['O'] === senderNum ? 'O' : null;
        if (!myMark) { await sendText(sock, chatJid, '_This game is full._', msg); return; }
        if (myMark !== game.turn) { await sendText(sock, chatJid, `_It's *${game.turn}*'s turn._`, msg); return; }
        const pos = parseInt(args[0]);
        if (isNaN(pos) || pos < 1 || pos > 9) {
            const b = game.board;
            const grid = `\`\`\`\n ${b[0]}|${b[1]}|${b[2]}\n-+-+-\n ${b[3]}|${b[4]}|${b[5]}\n-+-+-\n ${b[6]}|${b[7]}|${b[8]}\n\`\`\``;
            await sendText(sock, chatJid, `${grid}\n_Type *.ttt [1-9]* to place._`, msg);
            return;
        }
        if (game.board[pos - 1] !== ' ') { await sendText(sock, chatJid, '_That spot is taken._', msg); return; }
        game.board[pos - 1] = myMark;
        const wins = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
        const b = game.board;
        const grid = `\`\`\`\n ${b[0]}|${b[1]}|${b[2]}\n-+-+-\n ${b[3]}|${b[4]}|${b[5]}\n-+-+-\n ${b[6]}|${b[7]}|${b[8]}\n\`\`\``;
        const won  = wins.some(([a,c,d]) => b[a] !== ' ' && b[a] === b[c] && b[c] === b[d]);
        const draw = b.every(c => c !== ' ');
        if (won) {
            await sendText(sock, chatJid, `${grid}\n\n🏆 *@${senderNum} wins!*\n_Type *.ttt reset* to play again._`, msg);
            delete global._tttGames[chatJid]; return;
        }
        if (draw) {
            await sendText(sock, chatJid, `${grid}\n\n🤝 *Draw!*\n_Type *.ttt reset* to play again._`, msg);
            delete global._tttGames[chatJid]; return;
        }
        game.turn = myMark === 'X' ? 'O' : 'X';
        await sendText(sock, chatJid, `${grid}\n_@${game.players[game.turn]}'s turn (${game.turn})._`, msg);
        return;
    }

    if (lower.startsWith('.note')) {
        if (!global._notes) global._notes = {};
        const parts = text.trim().split(' ');
        const sub   = parts[1]?.toLowerCase();
        const senderNum = senderJid.split('@')[0];
        if (!sub || sub === 'list') {
            const mine = global._notes[senderNum];
            if (!mine || mine.length === 0) {
                await sendText(sock, chatJid, '📝 _No notes. Use *.note save [text]*_', msg);
            } else {
                await sendText(sock, chatJid, `📝 *Your Notes*\n\n${mine.map((n,i) => `${i+1}. ${n}`).join('\n')}\n\n_.note del [number] to delete_`, msg);
            }
            return;
        }
        if (sub === 'save') {
            const content = parts.slice(2).join(' ').trim();
            if (!content) { await sendText(sock, chatJid, '_Usage: *.note save [text]*_', msg); return; }
            if (!global._notes[senderNum]) global._notes[senderNum] = [];
            if (global._notes[senderNum].length >= 10) { await sendText(sock, chatJid, '⚠️ _Max 10 notes._', msg); return; }
            global._notes[senderNum].push(content);
            await sendText(sock, chatJid, `✅ _Note saved (${global._notes[senderNum].length}/10)._`, msg);
            return;
        }
        if (sub === 'del' || sub === 'delete') {
            const idx  = parseInt(parts[2]) - 1;
            const mine = global._notes[senderNum];
            if (!mine || isNaN(idx) || idx < 0 || idx >= mine.length) { await sendText(sock, chatJid, '_Invalid number._', msg); return; }
            const removed = mine.splice(idx, 1)[0];
            await sendText(sock, chatJid, `🗑️ _Deleted: "${removed}"_`, msg);
            return;
        }
        if (sub === 'clear') { global._notes[senderNum] = []; await sendText(sock, chatJid, '🗑️ _Cleared._', msg); return; }
        await sendText(sock, chatJid, '📝 *Note Commands*\n\n*.note list* · *.note save [text]* · *.note del [number]* · *.note clear*', msg);
        return;
    }

    if (lower.startsWith('.copilot ')) {
        const question = text.slice(9).trim();
        if (!question) { await sendText(sock, chatJid, '_Usage: .copilot [question]_', msg); return; }
        const result = await callPython(senderJid, `.gpt ${question}`, mentionedJid, chatJid);
        if (result?.response) await sendAny(sock, chatJid, result.response, msg);
        return;
    }

    if (!allowedGroups.includes(chatJid)) return;

    if (rawJid !== senderJid) console.log(`[LID] ${rawJid} → ${senderJid}`);
    if (senderJid.endsWith('@lid')) console.warn(`[LID] UNRESOLVED: ${senderJid}`);
    const sender      = senderJid;
    const cleanNumber = senderJid.split('@')[0];
    if (cleanNumber === PHONE_NUMBER) return;

    // ── Mute check ────────────────────────────────────────────
    const db = await _getDB();
    if (await isMuted(db, chatJid, senderJid)) return;

    // ── Bot commands (independent of game state) ──────────────
    let groupParticipants = [];
    try {
        if (!groupMetaCache[chatJid] || Date.now() - groupMetaCache[chatJid].ts > 300_000) {
            groupMetaCache[chatJid] = { meta: await sock.groupMetadata(chatJid), ts: Date.now() };
        }
        groupParticipants = groupMetaCache[chatJid].meta.participants;
    } catch {}

    // Check registration status for commands that need it
    let isRegistered = false;
    try {
        const regCheck = await db.query(
            'SELECT 1 FROM players WHERE sender = $1 LIMIT 1', [senderJid]
        );
        isRegistered = (regCheck.rows?.length ?? regCheck.length ?? 0) > 0;
    } catch { }

    const botReply = await handleBotCommand({
        sock, db, msg, chatJid, senderJid, text,
        mentionedJid, groupParticipants, isRegistered, groupPrefixCache,
    });
    if (botReply) {
        await sendAny(sock, chatJid, botReply, msg);
        return;
    }

    stats.msgsHandled++;
    stats.lastSender = cleanNumber;
    log('💬', `[${ts()}] ${cleanNumber} in ${chatJid.slice(0, 15)}… → "${text.slice(0, 45)}"`);

    let response, outbox;
    try {
        // If bot was tagged or player quoted the bot, prepend "ariel"
        const lower_ = text.toLowerCase();
        const effectiveText = (isBotTagged || isBotQuote) && !lower_.includes('ariel')
            ? `ariel ${text}`.trim()
            : text;
        const pushName = msg.pushName || null;
        const pythonQuotedText = isBotQuote ? quotedText : null;
        ({ response, outbox } = await callPython(sender, effectiveText, mentionedJid, chatJid, pythonQuotedText, pushName));
    } catch (e) {
        stats.errors++;
        err('🐍', `callPython error: ${e.message}`);
        return;
    }

    if (response) {
        log('📤', `[${ts()}] → ${response.length} chars to ${chatJid.slice(0, 15)}…`);
        const isHud = response.includes('__HUD__');
        const quote = isHud ? null : msg;
        await sendAny(sock, chatJid, response, quote);
    }

    if (outbox?.length > 0) {
        const seen = new Set();
        for (const item of outbox) {
            if (seen.has(item.message)) continue;
            seen.add(item.message);
            const targetJid = item.group_jid || chatJid;
            if (item.tag_all) {
                try {
                    const meta    = await sock.groupMetadata(targetJid);
                    const members = meta.participants.map(p => p.id);
                    const tags    = item.hide_tags ? '' : members.map(id => '@' + id.split('@')[0]).join(' ');
                    const fullMsg = tags ? item.message + '\n' + tags : item.message;
                    await sock.sendMessage(targetJid, {
                        text: fullMsg,
                        mentions: item.hide_tags ? [] : members,
                    });
                } catch(e) {
                    await sendAny(sock, targetJid, item.message, null);
                }
            } else {
                await sendAny(sock, targetJid, item.message, msg);
            }
            await sleep(300);
        }
    }
}

// ── Express status server ─────────────────────────────────────
let currentQR = null;
let currentPairingCode = null;
const app = express();

// ── CORS: allow the Vercel-hosted site to call this API with cookies ──
// TODO: swap this placeholder for your real Vercel domain once it's live,
// e.g. 'https://niflheim-online.vercel.app'
const SITE_ORIGIN = process.env.SITE_ORIGIN || 'https://YOUR-SITE.vercel.app';
app.use((req, res, next) => {
    const origin = req.headers.origin;
    if (origin === SITE_ORIGIN || origin === 'http://localhost:3000') {
        res.setHeader('Access-Control-Allow-Origin', origin);
        res.setHeader('Access-Control-Allow-Credentials', 'true');
        res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
        res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    }
    if (req.method === 'OPTIONS') return res.sendStatus(204);
    next();
});
app.use(express.json());
app.use(cookieParser());

// ── Site auth API ───────────────────────────────────────────
app.post('/api/auth/signup', async (req, res) => {
    try {
        const { username, countryCode, phoneNumber, password } = req.body || {};

        if (!username || !username.trim() || username.length > 50) {
            return res.status(400).json({ error: 'Username is required (max 50 characters).' });
        }
        if (!countryCode || !phoneNumber) {
            return res.status(400).json({ error: 'Phone number is required.' });
        }
        if (!password || password.length < 5) {
            return res.status(400).json({ error: 'Password must be at least 5 characters.' });
        }

        const sender = buildSenderJid(countryCode, phoneNumber);
        const phone  = sender.split('@')[0];
        const trimmedName = username.trim();

        const db = await _getDB();

        // One account per phone number, ever — reject if already signed up on the site.
        const existingUser = await db.query('SELECT 1 FROM users WHERE phone = $1 LIMIT 1', [phone]);
        if (existingUser.rows.length > 0) {
            return res.status(409).json({ error: 'An account already exists for this phone number. Try logging in instead.' });
        }

        // Symbiotic upsert into players: rename existing WA trainer, or leave untouched
        // (a real Player row gets created later when they register in-game).
        const existingPlayer = await db.query('SELECT data FROM players WHERE sender = $1', [sender]);
        if (existingPlayer.rows.length > 0) {
            const data = existingPlayer.rows[0].data;
            data.name = trimmedName;
            await db.query('UPDATE players SET data = $1 WHERE sender = $2', [data, sender]);
        }

        const passwordHash = await argon2.hash(password, { type: argon2.argon2id });
        await db.query(
            `INSERT INTO users (phone, username, password_hash) VALUES ($1, $2, $3)`,
            [phone, trimmedName, passwordHash]
        );

        issueSessionCookie(res, { phone, username: trimmedName });
        res.status(201).json({ username: trimmedName, phone });
    } catch (e) {
        err('🔐', `signup error: ${e.message}`);
        res.status(500).json({ error: 'Something went wrong. Try again.' });
    }
});

app.post('/api/auth/login', async (req, res) => {
    try {
        const { countryCode, phoneNumber, password } = req.body || {};
        if (!countryCode || !phoneNumber || !password) {
            return res.status(400).json({ error: 'Phone number and password are required.' });
        }

        const sender = buildSenderJid(countryCode, phoneNumber);
        const phone  = sender.split('@')[0];

        const db = await _getDB();
        const result = await db.query('SELECT username, password_hash FROM users WHERE phone = $1', [phone]);
        if (result.rows.length === 0) {
            return res.status(401).json({ error: 'No account found for this phone number.' });
        }

        const { username, password_hash } = result.rows[0];
        const valid = await argon2.verify(password_hash, password);
        if (!valid) {
            return res.status(401).json({ error: 'Incorrect password.' });
        }

        issueSessionCookie(res, { phone, username });
        res.status(200).json({ username, phone });
    } catch (e) {
        err('🔐', `login error: ${e.message}`);
        res.status(500).json({ error: 'Something went wrong. Try again.' });
    }
});

app.get('/api/auth/me', (req, res) => {
    const token = req.cookies?.niflheim_session;
    if (!token) return res.status(401).json({ error: 'Not logged in.' });
    try {
        const payload = jwt.verify(token, JWT_SECRET);
        res.json({ username: payload.username, phone: payload.phone });
    } catch {
        res.status(401).json({ error: 'Session expired.' });
    }
});

app.post('/api/auth/logout', (req, res) => {
    res.clearCookie('niflheim_session', { httpOnly: true, secure: true, sameSite: 'none' });
    res.status(200).json({ ok: true });
});

// ── Site player-data API ────────────────────────────────────
// Shared helper: verify session cookie, return { phone, sender } or null.
function _siteAuth(req) {
    const token = req.cookies?.niflheim_session;
    if (!token) return null;
    try {
        const payload = jwt.verify(token, JWT_SECRET);
        return { phone: payload.phone, sender: `${payload.phone}@s.whatsapp.net` };
    } catch {
        return null;
    }
}

app.get('/api/player/me', async (req, res) => {
    const auth = _siteAuth(req);
    if (!auth) return res.status(401).json({ error: 'Not logged in.' });

    try {
        const db = await _getDB();
        const result = await db.query('SELECT data FROM players WHERE sender = $1', [auth.sender]);
        if (result.rows.length === 0) {
            // Account exists (site login worked) but no in-game Player row yet —
            // they haven't registered via WhatsApp. Not an error, just empty state.
            return res.status(200).json({ registered: false });
        }

        const data = result.rows[0].data; // TEXT column — always a raw JSON string
        const player = JSON.parse(data);

        res.status(200).json({
            registered: true,
            stats: {
                name: player.name,
                level: player.level,
                pvp_wins: player.pvp_wins,
                pvp_losses: player.pvp_losses,
                badges_count: (player.badges || []).length,
                pokedex_caught: (player.pokedex_caught || []).length,
                bio: player.bio,
                rank: null,   // placeholder — no ranking system yet
                guild: null,  // placeholder — no guild system yet
            },
            party: player.party || [],
            pc: player.box || [],
            inventory: player.inventory || {},
            badges: player.badges || [],
        });
    } catch (e) {
        err('🌐', `player/me error: ${e.message}`);
        res.status(500).json({ error: 'Something went wrong loading player data.' });
    }
});

app.post('/api/player/swap', async (req, res) => {
    const auth = _siteAuth(req);
    if (!auth) return res.status(401).json({ error: 'Not logged in.' });

    const { from, to } = req.body || {};
    if (!from || !to) {
        return res.status(400).json({ error: '"from" and "to" slots are required.' });
    }

    try {
        const result = await callPythonAction(auth.sender, 'swap', { from, to });
        if (result?.site_result?.error) {
            return res.status(400).json({ error: result.site_result.error });
        }
        if (result?.error) {
            return res.status(503).json({ error: result.error });
        }
        res.status(200).json(result.site_result);
    } catch (e) {
        err('🌐', `player/swap error: ${e.message}`);
        res.status(500).json({ error: 'Something went wrong performing the swap.' });
    }
});

app.get('/', (req, res) => {
    const ip = getLocalIP();
    if (!currentQR && !currentPairingCode) {
        return res.send(`<!DOCTYPE html><html><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Ariel Bot</title>
<style>body{font-family:sans-serif;text-align:center;padding:30px;background:#111;color:#eee}
h2{color:#7fc97f}p{color:#aaa}.status{font-size:2em;margin:20px}</style>
<meta http-equiv="refresh" content="10">
</head><body>
<h2>⚔️ Ariel Bot</h2>
<div class="status">✅ Connected</div>
<p>Auth stored in Supabase — survives deploys.</p>
<p><a href="/status" style="color:#7fc97f">View JSON status →</a></p>
<hr><p style="font-size:0.8em">IP: ${ip} · Port: ${PORT}</p>
</body></html>`);
    }
    if (currentPairingCode) {
        return res.send(`<!DOCTYPE html><html><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Ariel — Pairing Code</title>
<style>body{font-family:sans-serif;text-align:center;padding:30px;background:#111;color:#eee}
h2{color:#7fc97f}
.code{font-size:3em;font-weight:bold;color:#7fc97f;letter-spacing:8px;
background:#1a1a1a;padding:20px 40px;border-radius:12px;border:2px solid #7fc97f;display:inline-block;margin:20px 0}
.steps{text-align:left;max-width:400px;margin:0 auto;color:#aaa;line-height:2}
.highlight{color:#7fc97f;font-weight:bold}</style>
<meta http-equiv="refresh" content="30">
</head><body>
<h2>⚔️ Ariel Bot — Enter This Code</h2>
<div class="code">${currentPairingCode}</div>
<div class="steps">
<p><span class="highlight">Step 1:</span> Open WhatsApp</p>
<p><span class="highlight">Step 2:</span> Tap ⋮ → Linked Devices</p>
<p><span class="highlight">Step 3:</span> Link a Device</p>
<p><span class="highlight">Step 4:</span> Link with phone number instead</p>
<p><span class="highlight">Step 5:</span> Enter the code above</p>
</div>
<p style="color:#666;font-size:0.8em">Expires in ~60s. Auto-refreshes.</p>
</body></html>`);
    }
    res.send(`<!DOCTYPE html><html><head>
<meta charset="utf-8"><title>Ariel — Scan QR</title>
<style>body{font-family:sans-serif;text-align:center;padding:20px;background:#111;color:#eee}
h2{color:#7fc97f}img{max-width:300px;width:90vw;border:4px solid #7fc97f;border-radius:12px;margin:20px auto;display:block}
p{color:#aaa}.note{color:#f90;font-size:0.9em}</style>
<meta http-equiv="refresh" content="20">
</head><body>
<h2>⚔️ Scan QR with WhatsApp</h2>
<img src="https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(currentQR)}" alt="QR Code">
<p class="note">⚠️ QR expires every ~20s. Auto-refreshes.</p>
<p>WhatsApp → Linked Devices → Link a Device → Scan</p>
</body></html>`);
});

app.get('/health', (req, res) => {
    res.status(200).json({ status: 'ok', uptime: Math.floor(Date.now()/1000 - BOT_START_TIME) });
});

app.get('/reset', (req, res) => {
    res.send(`<!DOCTYPE html><html><head><meta charset="utf-8">
<title>Ariel — Reset</title>
<style>body{font-family:sans-serif;text-align:center;padding:40px;background:#111;color:#eee}
h2{color:#f66}button{background:#f66;color:#fff;border:none;padding:15px 30px;font-size:1.2em;border-radius:8px;cursor:pointer;margin:20px}</style>
</head><body>
<h2>⚠️ Reset WhatsApp Session</h2>
<p>Clears Supabase auth and restarts. You'll need to re-pair.</p>
<form method="POST" action="/reset"><button type="submit">🗑️ Clear & Restart</button></form>
</body></html>`);
});

app.post('/reset', (req, res) => {
    res.send(`<!DOCTYPE html><html><head><meta charset="utf-8">
<title>Resetting...</title>
<style>body{font-family:sans-serif;text-align:center;padding:40px;background:#111;color:#eee}
h2{color:#7fc97f}p{color:#aaa}.big{font-size:3em;color:#f90}</style>
</head><body>
<h2>✅ Auth Cleared!</h2>
<div class="big" id="timer">30</div>
<p>Go to WhatsApp → Linked Devices → <strong>Unlink ALL devices</strong> now.</p>
<p>Bot will hard-restart automatically when the timer hits zero.</p>
<script>
let t = 30;
const el = document.getElementById('timer');
const iv = setInterval(() => { el.textContent = -.t; if(t<=0) clearInterval(iv); }, 1000);
</script>
</body></html>`);
    setTimeout(async () => {
        await clearSupabaseAuth();
        log('🗑️', 'Auth cleared via /reset. Restarting...');
        setTimeout(() => process.exit(0), 30_000);
    }, 1000);
});

app.get('/status', (req, res) => {
    res.json({
        time: now(), connected: !!activeSockRef, pythonReady,
        uptime: Math.floor(Date.now() / 1000 - BOT_START_TIME),
        linkedGroups: allowedGroups.length, groups: allowedGroups,
        pendingCallbacks: Object.keys(pendingCallbacks).length, stats, ip: getLocalIP(),
    });
});

app.listen(PORT, '0.0.0.0', () => {
    const ip = getLocalIP();
    log('🌐', `Web server started`);
    log('🌐', `On THIS phone:  http://localhost:${PORT}`);
    log('🌐', `On OTHER phone: http://${ip}:${PORT}`);
});

// ── Baileys (Supabase auth) ───────────────────────────────────
async function startSock() {
    await loadGroups();
    console.log('BufferJSON:', typeof BufferJSON, Object.keys(BufferJSON));
    // ... rest of the code
    let state, saveCreds;
    try {
        ({ state, saveCreds } = await useSupabaseAuthState());
        log('🔐', 'Auth loaded from Supabase.');
    } catch (e) {
        err('🔐', `Supabase auth failed: ${e.message}`);
        err('🔐', 'Check SUPABASE_DB_URL env var.');
        return setTimeout(startSock, 5000);
    }

    let version;
    try {
        ({ version } = await fetchLatestBaileysVersion());
        log('🔌', `Baileys v${version.join('.')}`);
    } catch (e) {
        warn('🔌', `Could not fetch Baileys version. Using fallback.`);
        version = [2, 3000, 1023527190];
    }

    const sock = makeWASocket({
        version,
        auth: {
        creds: state.creds,
        keys: makeCacheableSignalKeyStore(state.keys, silentLogger),
    },
        logger:              silentLogger,
        printQRInTerminal:   false,
        mobile:              false,
        browser:             ['Ubuntu', 'Chrome', '20.0.04'],
        markOnlineOnConnect: false,
        syncFullHistory:     false,
        getMessage: async (key) => { return { conversation: '' }; },
        connectTimeoutMs:    60_000,
        keepAliveIntervalMs: 30_000,
    });
    // Build LID → phone JID map from contacts
    sock.ev.on('contacts.upsert', (contacts) => {
        for (const c of contacts) {
            if (c.lid && c.id) lidMap[c.lid] = c.id;
        }
    });
    sock.ev.on('contacts.update', (updates) => {
        for (const c of updates) {
            if (c.lid && c.id) lidMap[c.lid] = c.id;
        }
    });

    activeSockRef = sock;
    let pairingRequested = false;
    let wasConnected = false;

        sock.ev.on('connection.update', async ({ connection, lastDisconnect, qr }) => {
        if (qr && !state.creds.registered && !pairingRequested) {
            pairingRequested = true;
            currentQR = qr;
            log('📱', `Attempting pairing code for ${PAIRING_NUMBER}...`);
            try {
                await sleep(2000);
                const code = await sock.requestPairingCode(PAIRING_NUMBER);
                const formatted = code?.match(/.{1,4}/g)?.join('-') || code;
                log('🔑', `PAIRING CODE: ${formatted}`);
                currentPairingCode = formatted;
            } catch(e) {
                err('🔑', `Pairing code failed: ${e.message}`);
            }
        }

        if (connection === 'open') {
            wasConnected       = true;
            currentQR          = null;
            currentPairingCode = null;
            activeSockRef      = sock;
            log('✅', `ARIEL ONLINE — ${now()}`);
            log('✅', `Linked groups: ${allowedGroups.length}`);
        }

        if (connection === 'close') {
            activeSockRef = null;
            const code   = lastDisconnect?.error?.output?.statusCode;
            const reason = lastDisconnect?.error?.message || 'unknown';
            const logout = code === DisconnectReason.loggedOut;
            warn('🔌', `Disconnected — code ${code}...`);
if (code === 440) {
    err('🔌', 'Conflict — newer instance detected. Shutting down.');
    process.exit(0);
}
if (logout && wasConnected) {
                warn('🔐', 'Logged out. Clearing Supabase auth...');
                setTimeout(startSock, code === 515 || code === 428 ? 3000 : 30_000);
            } else {
                setTimeout(startSock, code === 515 || code === 428 ? 3000 : 5000);
            }
        }
    });

    sock.ev.on('creds.update', saveCreds);

    // Log ALL events to see what's being received
    const origEmit = sock.ev.emit.bind(sock.ev);
    sock.ev.emit = (event, ...args) => {

        return origEmit(event, ...args);
    };

    // ── Group participant events (welcome / leave) ───────────
    sock.ev.on('group-participants.update', async ({ id, participants, action }) => {
        // Only fire welcome/leave if bot is actually connected and linked to this group
        if (!activeSockRef) return;
        if (!allowedGroups.includes(id)) return;
        const db = await _getDB();
        const ctx = { sock, db, chatJid: id, groupParticipants: [] };
        // Normalize — participants can be strings or objects
        const jids = participants.map(p => typeof p === 'string' ? p : p.id || p.jid || String(p));
        if (action === 'add') {
            for (const jid of jids) await onMemberJoin(ctx, jid);
        }
        if (action === 'remove' || action === 'leave') {
            for (const jid of jids) await onMemberLeave(ctx, jid);
        }
    });

    sock.ev.on('messages.upsert', async ({ messages, type }) => {
        console.log(`[MSG] upsert type=${type} count=${messages.length}`);
        if (type !== 'notify') return;
        for (const msg of messages) {
            console.log(`[MSG] from=${msg.key.remoteJid} fromMe=${msg.key.fromMe}`);
            try {
                await handleMessage(sock, msg);
            } catch (e) {
                stats.errors++;
                err('💬', `handleMessage crash: ${e.message}`);
                err('💬', e.stack?.split('\n')[1] || '');
            }
        }
    });
}

// ── Boot ──────────────────────────────────────────────────────
log('🚀', `Ariel booting — ${now()}`);
log('🚀', `Auth: Supabase`);
log('🚀', `Python: ${PYTHON_SCRIPT}`);

startPython();
startSock();

// ── Render keepalive ──────────────────────────────────────────
if (process.env.RENDER || process.env.FLY_APP_NAME) {
    const RENDER_URL = process.env.RENDER_EXTERNAL_URL
        || (process.env.FLY_APP_NAME ? `https://${process.env.FLY_APP_NAME}.fly.dev` : `http://localhost:${PORT}`);
    setInterval(async () => {
        try {
            const http = await import('http');
            const url  = new URL('/health', RENDER_URL);
            http.default.get(url.toString(), (res) => { res.resume(); }).on('error', () => {});
        } catch(e) {}
    }, 14 * 60 * 1000);
    log('💓', `Render keepalive active`);
}
