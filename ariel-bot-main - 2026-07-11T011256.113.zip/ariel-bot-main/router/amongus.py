# ============================================================
# NIFLHEIM — router/amongus.py
# Among Us mode — fully isolated from the Pokémon/Player system.
# No registration, no shared state, no Supabase persistence.
#
# Architecture note: handle.py calls AmongUsManager.pre_dispatch()
# as the VERY FIRST thing in handle(), before the Pokémon
# registration gate or stage machine ever run. If pre_dispatch
# returns NOT_HANDLED, handle() falls through to normal Pokémon
# logic untouched. Anything else IS the final response (even None,
# which means "handled silently, no reply").
# ============================================================

import threading
import time

# Sentinel — distinguishes "not our command, let Pokémon handle it"
# from a real (possibly None/silent) Among Us response.
NOT_HANDLED = object()

MIN_PLAYERS = 4
MAX_PLAYERS = 20
INACTIVITY_TIMEOUT_SECONDS = 10 * 60  # 10 minutes, per design notes


def _impostor_count(player_count):
    """1 under 7, 2 under 14, 3 under 20."""
    if player_count < 7:
        return 1
    if player_count < 14:
        return 2
    return 3


class Lobby:
    """A single Among Us lobby. Only one can be open at a time."""

    _id_counter = 0

    def __init__(self, group_jid, host):
        Lobby._id_counter += 1
        self.id = Lobby._id_counter
        self.group_jid = group_jid
        self.host = host
        self.players = [host]
        self.started = False

    def roster_text(self):
        return "\n".join(f"{i+1}. {p}" for i, p in enumerate(self.players))


class AmongUsManager:
    def __init__(self, router):
        self.router = router
        self.amongus_on = set()       # senders currently in Among Us mode
        self.pokemon_off = set()      # senders who've disabled Pokémon commands
        self.lobby = None             # single global open Lobby, or None
        self.game = None              # active Game, or None
        self._timer = None            # inactivity threading.Timer
        self._ghosts_group_jid = None # set via .setghostgroup by host

    # ── Mode toggle — always reachable, regardless of current mode ──
    def pre_dispatch(self, sender, text, group_jid=None):
        raw = (text or "").strip()
        low = raw.lower()

        if low == ".amongus on":
            self.amongus_on.add(sender)
            return (
                "🔪 *Among Us mode ON.*\n"
                ".lobby open to host a game, or .join if one's already open.\n"
                "_.amongus off to leave._"
            )
        if low == ".amongus off":
            self.amongus_on.discard(sender)
            self._remove_player(sender)
            return "👋 *Among Us mode OFF.*"

        if low == ".pokemon off":
            self.pokemon_off.add(sender)
            return "⏸️ *Pokémon commands disabled.* _.pokemon on to re-enable._"
        if low == ".pokemon on":
            self.pokemon_off.discard(sender)
            return "▶️ *Pokémon commands re-enabled.*"

        if sender in self.amongus_on:
            return self._dispatch(sender, raw, group_jid)

        if sender in self.pokemon_off:
            return None  # swallow — Pokémon commands ignored for this sender

        return NOT_HANDLED

    # ── Among Us command dispatch ──
    def _dispatch(self, sender, text, group_jid):
        parts = text.split()
        if not parts:
            return None
        cmd = parts[0].lower()
        arg = parts[1].lower() if len(parts) > 1 else ""

        # Lobby commands (always reachable even mid-game)
        if cmd == ".lobby" and arg == "open":
            return self._lobby_open(sender, group_jid)
        if cmd == ".lobby" and arg == "start":
            return self._lobby_start(sender)
        if cmd == ".lobby" and arg == "list":
            return self._lobby_list()
        if cmd == ".join":
            return self._lobby_join(sender, group_jid)
        if cmd == ".leave":
            return self._lobby_leave(sender)
        if cmd == ".amenu":
            return self._amenu()
        if cmd == ".setghostgroup":
            return self._set_ghost_group(sender, group_jid)

        # In-game commands — route to the active Game
        if self.game and not self.game.over:
            # GC .vote goes through handle_gc_vote
            if group_jid and cmd == ".vote":
                return self.game.handle_gc_vote(sender, text)
            return self.game.handle(sender, text)

        if self.game and self.game.over:
            return "_The game is over. Start a new lobby with .lobby open._"

        return "❓ _Not a recognized Among Us command. Try .amenu._"

    # ── Lobby actions ──
    def _lobby_open(self, sender, group_jid):
        if not group_jid:
            return "⚠️ _.lobby open needs to be sent in the group chat, not a DM._"
        if self.lobby and not self.lobby.started:
            return "⚠️ _A lobby's already open. .join it instead._"
        self.lobby = Lobby(group_jid, sender)
        self._reset_timer()
        return (
            f"🛰️ *Lobby #{self.lobby.id} opened* by {sender}.\n"
            f".join to enter ({MIN_PLAYERS}-{MAX_PLAYERS} players).\n"
            "Host: send *.lobby start* once ready."
        )

    def _lobby_join(self, sender, group_jid):
        lobby = self.lobby
        if not lobby or lobby.started:
            return "⚠️ _No open lobby right now. Ask someone to .lobby open._"
        if sender in lobby.players:
            return "_You're already in this lobby._"
        if len(lobby.players) >= MAX_PLAYERS:
            return f"⚠️ _Lobby's full ({MAX_PLAYERS} max)._"
        lobby.players.append(sender)
        self._reset_timer()
        return f"✅ Joined. ({len(lobby.players)}/{MAX_PLAYERS})\n\n{lobby.roster_text()}"

    def _lobby_leave(self, sender):
        self._remove_player(sender)
        return "👋 _Left the lobby._"

    def _lobby_list(self):
        lobby = self.lobby
        if not lobby:
            return "_No open lobby right now._"
        from .amongus import _impostor_count
        n_imp = _impostor_count(len(lobby.players))
        return (
            f"🛰️ *Lobby #{lobby.id}* — {len(lobby.players)}/{MAX_PLAYERS} players "
            f"({n_imp} impostor(s) at this size)\n"
            f"Host: {lobby.host}\n\n"
            f"{lobby.roster_text()}"
        )

    def _remove_player(self, sender):
        lobby = self.lobby
        if not lobby or sender not in lobby.players:
            return
        lobby.players.remove(sender)
        if sender == lobby.host:
            if lobby.players:
                lobby.host = lobby.players[0]
                self._broadcast(
                    f"👋 Host left — *{lobby.host}* is now host.\n\n{lobby.roster_text()}"
                )
            else:
                self._cancel_timer()
                self.lobby = None
                self._broadcast("👋 _Last player left — lobby closed._")
        else:
            self._reset_timer()

    def _lobby_start(self, sender):
        lobby = self.lobby
        if not lobby:
            return "⚠️ _No open lobby._"
        if lobby.started:
            return "⚠️ _Already started._"
        if sender != lobby.host:
            return "⚠️ _Only the host can start the game._"
        if len(lobby.players) < MIN_PLAYERS:
            return f"⚠️ _Need at least {MIN_PLAYERS} players ({len(lobby.players)}/{MIN_PLAYERS})._"
        lobby.started = True
        self._cancel_timer()
        from .amongus_game import Game
        self.game = Game(self, lobby)
        return None  # Game.__init__ broadcasts the start message itself

    def _set_ghost_group(self, sender, group_jid):
        if not group_jid:
            return "⚠️ _Send this from the Ghosts group chat._"
        if self.lobby and sender != self.lobby.host:
            return "⚠️ _Only the host can set the Ghosts group._"
        self._ghosts_group_jid = group_jid
        return f"👻 Ghosts group set: {group_jid}"

    def _amenu(self):
        return (
            "*Among Us — Commands*\n"
            ".amongus on / off\n"
            ".pokemon on / off\n"
            ".lobby open  _(in GC)_\n"
            ".lobby start  _(host only)_\n"
            ".lobby list\n"
            ".join / .leave\n"
            ".setghostgroup  _(host, from Ghosts GC)_\n"
            "\n*In-game (DM):*\n"
            ".m  — list rooms\n"
            ".m <room or number>  — move\n"
            ".where  — your current location\n"
            ".task  — list tasks here\n"
            ".task <n>  — do a task\n"
            ".tasks  — your full task list\n"
            ".progress  — task progress bar\n"
            ".players  — who's still alive\n"
            ".kill / .kill <jid>  — kill _(impostor)_\n"
            ".vent / .vent <n>  — vent _(impostor)_\n"
            ".sabotage reactor  _(impostor)_\n"
            ".cooldown  — fix meltdown\n"
            ".follow <jid>\n"
            ".report  — report a body\n"
            ".meeting  — emergency meeting\n"
            ".vote <jid> / .vote skip  _(DM or GC)_\n"
            ".c <message>  — ghost chat _(ghosts only)_\n"
            "\n*Utility (anywhere):*\n"
            ".groupid  — get JID / LID of this chat"
        )

    # ── Ghost chat ──
    def _push_ghost_chat(self, game, sender_jid, message):
        dead = [p for p in game.players.values() if not p.alive and p.jid != sender_jid]
        formatted = f"👻 *{sender_jid}:* {message}"
        if self._ghosts_group_jid:
            self._broadcast(formatted, group_jid=self._ghosts_group_jid)
        else:
            # Fallback: DM each ghost individually
            for p in dead:
                self._push_dm(p.jid, formatted)

    # ── Inactivity timeout ──
    def _reset_timer(self):
        self._cancel_timer()
        self._timer = threading.Timer(INACTIVITY_TIMEOUT_SECONDS, self._timeout)
        self._timer.daemon = True
        self._timer.start()

    def _cancel_timer(self):
        if self._timer:
            self._timer.cancel()
            self._timer = None

    def _timeout(self):
        lobby = self.lobby
        if not lobby or lobby.started:
            return
        lobby_id = lobby.id
        self.lobby = None
        self._broadcast(f"_Lobby {lobby_id} has ended._", group_jid=lobby.group_jid)

    # ── Send helpers ──
    def _broadcast(self, message, group_jid=None):
        """Push to the lobby's group chat (or a specified GC)."""
        send = getattr(self.router, "_direct_send", None)
        if not send:
            return
        target = group_jid or (self.lobby.group_jid if self.lobby else None)
        if target:
            send(message, group_jid=target)
        else:
            send(message)

    def _push_dm(self, player_jid, message):
        """Push directly to one player's DM via the JS allow_dm extension."""
        send = getattr(self.router, "_direct_send", None)
        if not send:
            return
        send(message, group_jid=player_jid, allow_dm=True)

# Among Us mode — fully isolated from the Pokémon/Player system.
# No registration, no shared state, no Supabase persistence.
#
# Architecture note: handle.py calls AmongUsManager.pre_dispatch()
# as the VERY FIRST thing in handle(), before the Pokémon
# registration gate or stage machine ever run. If pre_dispatch
# returns NOT_HANDLED, handle() falls through to normal Pokémon
# logic untouched. Anything else IS the final response (even None,
# which means "handled silently, no reply").
# ============================================================

import threading
import time

# Sentinel — distinguishes "not our command, let Pokémon handle it"
# from a real (possibly None/silent) Among Us response.
NOT_HANDLED = object()

MIN_PLAYERS = 4
MAX_PLAYERS = 20
INACTIVITY_TIMEOUT_SECONDS = 10 * 60  # 10 minutes, per design notes


def _impostor_count(player_count):
    """1 under 7, 2 under 14, 3 under 20 — boundary behavior at exactly
    7/14/20 wasn't specified in design, treating the bracket ceiling as
    exclusive (i.e. 7 players gets 2, 14 gets 3) until Joel says otherwise."""
    if player_count < 7:
        return 1
    if player_count < 14:
        return 2
    return 3


