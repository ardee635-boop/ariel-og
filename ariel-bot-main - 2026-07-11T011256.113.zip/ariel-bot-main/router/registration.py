# ============================================================
# NIFLHEIM — router/registration.py
# Instant .start registration — all 3 starters added to party
# ============================================================

import random
import datetime
from models import Player, OwnedPokemon
from ._constants import STATE_EXPLORING

ELEMENTAL_BALLS = ["Pyro Ball", "Cryo Ball", "Atmo Ball", "Floro Ball", "Volt Ball"]

# ── Curated starter pools ────────────────────────────────────
FIRE_STARTERS  = ["charmander", "cyndaquil", "torchic", "chimchar", "fennekin",
                  "tepig", "litten", "scorbunny", "fuecoco", "growlithe"]
WATER_STARTERS = ["squirtle", "totodile", "mudkip", "piplup", "oshawott",
                  "froakie", "popplio", "sobble", "quaxly", "shellder"]
GRASS_STARTERS = ["bulbasaur", "chikorita", "treecko", "turtwig", "snivy",
                  "chespin", "rowlet", "grookey", "sprigatito", "oddish"]


class RegistrationMixin:

    def _start(self, sender, push_name=None):
        # Already registered
        if self.db.exists(sender):
            player = self._get(sender)
            return (
                f"Welcome back, {player.name}.\n"
                "_Use 1 2 3 4 to move._"
            )

        # Already mid-reg — clean up
        if sender in self.reg:
            del self.reg[sender]
            self.db.delete_reg(sender)

        return self._reg_finish(sender, push_name=push_name)

    def _reg_handle(self, sender, text):
        # Stale reg entry — player already created
        if self.db.exists(sender):
            del self.reg[sender]
            self.db.delete_reg(sender)
        return None

    def _reg_finish(self, sender, push_name=None):
        import pokeapi

        name = (push_name or "Traveller").strip()
        if len(name) > 16:
            name = name[:16]

        # Build player
        player           = Player(name)
        player.story_stage = "has_starter"
        player.joined_at = datetime.datetime.utcnow().isoformat()
        player.zone      = "oak_town"
        player.zone_x    = 12
        player.zone_y    = 6
        player.set_flag("visited_zones", ["oak_town", "route_1", "greenwood_town"])

        # Starter pack
        elemental_ball = random.choice(ELEMENTAL_BALLS)
        player.give_item("Poké Ball",    3)
        player.give_item(elemental_ball, 1)
        player.give_item("Master Ball",  1)
        player.give_item("Potion",       3)
        player.give_item("Full Heal",    1)
        player.coins += 300

        # Pick one random starter per type and add all 3 to party
        chosen = [
            random.choice(FIRE_STARTERS),
            random.choice(WATER_STARTERS),
            random.choice(GRASS_STARTERS),
        ]
        starter_names = []
        for species in chosen:
            try:
                data = pokeapi.get_full(self.db, species)
                if data:
                    poke = OwnedPokemon(data, level=5)
                    poke.is_starter = True
                    player.add_to_party(poke)
                    player.see_pokemon(species)
                    player.catch_pokemon(species)
                    starter_names.append(poke.nickname)
            except Exception:
                starter_names.append(species.capitalize())

        # Greenwood quest
        from .quests import make_quest
        try:
            gq = make_quest("greenwood_1")
            if not hasattr(player, "quests"):
                player.quests = []
            player.quests.append(gq)
            player.set_flag("greenwood_given", True)
        except Exception:
            gq = None

        # Save
        self.cache[sender] = player
        self.db.save(sender, player)
        self._session(sender).transition(STATE_EXPLORING)

        # ── Message 1: welcome ────────────────────────────────
        RM = "\u200b" * 700
        msg1 = (
            f"Hey, {name} 👋 Welcome to Niflheim.\n"
            f"Use *.quicktravel* to change location\n"
            f"{RM}\n"
            f"🌿 *.hunt* only works in routes with grass\n\n"
            f"◈ Poké Ball ×3\n"
            f"◈ {elemental_ball} ×1\n"
            f"◈ Master Ball ×1\n"
            f"◈ Potion ×3\n"
            f"◈ Full Heal ×1\n"
            f"◈ 300c\n\n"
            f"*.party* — your Soul Bounds\n"
            f"*.inv* — your bag\n"
            f"*.pmenu* — player menu\n"
            f"*.quests* — active quests\n"
            f"*.minimap* — where you are\n\n"
            f"_Your party is ready. Use 1 2 3 4 to move._"
        )

        # ── Message 2: starter cards ──────────────────────────
        card_lines = []
        for i, poke in enumerate(player.party, start=1):
            types = getattr(poke, "types", []) or []
            type_str = " / ".join(t.capitalize() for t in types)
            genus = (getattr(poke, "genus", "") or "").strip()
            flavor = (getattr(poke, "flavor_text", "") or "").strip()
            card_lines.append(
                f"*{i}.*\n"
                f"Name: {poke.nickname}\n"
                f"Species: {genus}\n"
                f"Type: {type_str}\n"
                f"Stars: ✧✧✧✧✧✧\n"
                f"Description: {flavor}"
            )

        party_header = f"Here are your Pokémon.\n{RM}\n"
        msg2 = party_header + "\n\n─────────────\n\n".join(card_lines)
        self._queue_message(sender, msg2, delay=1)

        # ── Message 3: quest card ─────────────────────────────
        if gq:
            msg3 = (
                f"📋 *Quest Unlocked*\n"
                f"{RM}\n"
                f"*{gq.title}*\n"
                f"_{gq.description}_\n\n"
                f"_Check *.quests* to track progress._"
            )
            self._queue_message(sender, msg3, delay=2)

        return msg1

    def _render_zone_map(self, sender, player):
        from map import render_minimap
        return render_minimap(player)

