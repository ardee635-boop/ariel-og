# ============================================================
# NIFLHEIM — router/movement.py
# Zone-grid movement (oak_town, route_1, etc.)
# ============================================================

import random
from ._constants import STATE_EXPLORING, STATE_IDLE
from npc import old_man_block, old_man_pass


class MovementMixin:

    def _handle_movement(self, sender, player, direction: str) -> str | None:
        """
        Zone-aware movement for any zone file (oak_town, route_1, etc).
        Returns reply string, or None to fall through to world_registry movement.
        """
        # ── Static state — movement silently blocked ───────────
        if getattr(player, "static_state", None):
            return None

        # ── Arena state — movement locked ─────────────────────
        from combat_session import STATE_ARENA, STATE_ARENA_PENDING, STATE_GYM, STATE_GYM_PENDING, STATE_BATTLE
        _sess = self._session(sender)
        if _sess.state == STATE_ARENA:
            return "_You're in the arena. Use_ `.next` _to fight or finish your battles._"
        if _sess.state == STATE_ARENA_PENDING:
            return "_Battle is about to start..._"
        if _sess.state == STATE_GYM:
            return "_You're in the gym. Use_ `.next` _to fight or finish your battles._"
        if _sess.state == STATE_GYM_PENDING:
            return "_Battle is about to start..._"
        if _sess.state == STATE_BATTLE and getattr(_sess, "arena_trainer_name", None):
            return "_You're in an arena battle! Finish the fight first._"
        if _sess.state == "battle_menu" and getattr(_sess, "arena_trainer_name", None):
            return "_You're in an arena battle! Finish the fight first._"

        # ── PC healing — block movement until timestamp expires ─
        pc_heal_val = self.db.get_meta(sender, "pc_healing")
        if pc_heal_val:
            import time as _time
            try:
                if _time.time() < float(pc_heal_val):
                    return "_Please wait while your Pokémon are being healed..._"
                else:
                    self.db.delete_meta(sender, "pc_healing")
            except ValueError:
                self.db.delete_meta(sender, "pc_healing")

        # ── NPC conversation — movement breaks it ─────────────
        active_npc = self.db.get_meta(sender, "active_npc")
        if active_npc:
            self.db.delete_meta(sender, "active_npc")
            self.db.delete_meta(sender, "active_npc_name")
            # Don't block movement — just end convo silently and continue

        zone_id = getattr(player, "zone", "oak_town")

        from map import load_zone, IMPASSABLE, get_npc, get_sign

        ZONE = load_zone(zone_id)
        if not ZONE:
            return None

        col, row = player.zone_x, player.zone_y

        MOVE_DELTA = {"1": (0, -1), "2": (0, 1), "3": (-1, 0), "4": (1, 0),
                      "-1": (0, -1), "-2": (0, 1), "-3": (-1, 0), "-4": (1, 0)}
        dc, dr  = MOVE_DELTA.get(direction, (0, 0))
        new_col = col + dc
        new_row = row + dr

        grid   = ZONE["grid"]
        width  = ZONE["width"]
        height = ZONE["height"]

        # ── Out of bounds — hard wall ─────────────────────────
        is_oob = not (0 <= new_col < width and 0 <= new_row < height)
        if is_oob:
            return "_There is nothing that way._"

        tile = grid[new_row][new_col]

        # ── EX tile — zone exit ───────────────────────────────
        if tile == "EX":
            exits = ZONE.get("exits", {})
            exit_def = exits.get(f"{new_row},{new_col}")
            if not exit_def:
                return "_The way is blocked._"

            to_zone   = exit_def["to_zone"]
            to_exit   = exit_def.get("to_exit")
            dest_zone = load_zone(to_zone)
            if not dest_zone:
                return "_The way is blocked._"

            # ── ID-based exit linking ─────────────────────────
            if to_exit:
                exit_positions = dest_zone.get("exit_positions", {})
                dest_pos = exit_positions.get(to_exit)
                if not dest_pos:
                    return "_The way is blocked._"
                sc, sr = dest_pos
            else:
                # fallback: legacy hardcoded spawn
                sc, sr = exit_def["spawn"]

            # Oak Town → Route 1 gate check
            if zone_id == "oak_town" and to_zone == "route_1":
                if getattr(player, "story_stage", "new") not in ("has_starter", "route_1"):
                    return old_man_block()
                player.story_stage = "route_1"
                player.objective   = "Explore Route 1 — find and catch wild Pokémon"

            player.zone   = to_zone
            player.zone_x = sc
            player.zone_y = sr
            # Track visited zones for .quicktravel
            visited = player.get_flag("visited_zones", [])
            if to_zone not in visited:
                visited.append(to_zone)
                player.set_flag("visited_zones", visited)
            # Quest hook — reach_location
            try:
                from .quests import on_move as _on_move
                _on_move(player, to_zone)
            except Exception:
                pass
            self._session(sender).transition(STATE_EXPLORING)
            self._save(sender, player)
            dest_name = dest_zone.get("name", to_zone.replace("_", " ").title())
            arrival   = f"📍 *Entering {dest_name}*"
            return arrival + "\n" + self._render_zone_map(sender, player)

        # ── Impassable tiles ──────────────────────────────────
        if tile in IMPASSABLE:
            if tile == "~~":
                return "_The sea blocks your path._"
            if tile == "WW":
                return "_The water is too deep to cross._"
            if tile == "BB":
                return "_A berry tree blocks your way._"
            return "_The way is blocked._"

        # ── Lab tile (oak_town only) ───────────────────────────
        if tile == "LL":
            player.zone_x = new_col
            player.zone_y = new_row

            if getattr(player, "story_stage", "new") in ("has_starter", "route_1"):
                player.static_state = None
                self._save(sender, player)
                return "_The doctor is busy right now..._"

            player.static_state = "oak_lab_1"

            from .quests import on_lab_entered
            quest_msgs = on_lab_entered(player)
            for i, msg in enumerate(quest_msgs, 1):
                self._queue_message(sender, msg, delay=i)

            if getattr(player, "story_stage", "new") not in ("choosing", "confirming", "at_lab"):
                player.story_stage = "at_lab"

            self._save(sender, player)

            delay = len(quest_msgs) + 1
            oak_msg = (
                "*Prof. Oak looks up from his notes.*\n"
                "Ah — {name}. I was starting to think you wouldn't come.\n"
                "Welcome to the Pokélab. I have something important to show you.\n\n"
                "_Reply to this message to continue._\n"
                "_Note: NPCs can be conversed with by saying their name or replying to them only_"
            ).format(name=player.name)
            self._queue_message(sender, oak_msg, delay=delay)
            return None

        # ── House tile ────────────────────────────────────────
        if tile == "HH":
            return "_You peek inside. Nothing for you here yet._"

        # ── Pokémart tile ─────────────────────────────────────
        if tile == "PS":
            return self._open_mart(sender, player)



        # ── Pokémon Center tile ───────────────────────────────
        if tile == "PC":
            player.zone_x = new_col
            player.zone_y = new_row

            # Heal all party
            healed = 0
            for mon in getattr(player, "party", []):
                if hasattr(mon, "heal_full"):
                    mon.heal_full()
                    healed += 1

            from combat_session import STATE_EXPLORING, STATE_DEAD
            import time as _time
            session = self._session(sender)
            if session.state == STATE_DEAD:
                session.transition(STATE_EXPLORING)

            # Set heal lock with expiry timestamp (3 seconds)
            self.db.set_meta(sender, "pc_healing", str(_time.time() + 3))
            self._save(sender, player)

            self._queue_message(sender,
                "🏥 *Pokémon Center*\n"
                "━━━━━━━━━━━━━━━━\n"
                "_Welcome to the Pokémon Care Center.\n"
                "Please wait while we heal your Pokémon..._",
                delay=0
            )

            heal_msg = (
                f"✅ _All {healed} of your Pokémon have been healed to full health!_\n"
                "_You're free to go._"
            ) if healed else "✨ _Your Pokémon are already at full health!_\n_You're free to go._"

            self._queue_message(sender, f"🏥 *Pokémon Care Center*\n━━━━━━━━━━━━━━━━\n{heal_msg}", delay=3)
            return None

        # ── Sign tile ─────────────────────────────────────────
        if tile == "SG":
            sign = get_sign(zone_id, new_row, new_col)
            if sign:
                return f"📋 {sign}"

        # ── Cave tile — blocked for now ───────────────────────
        if tile == "CC":
            return "_The cave entrance is sealed. Come back later._"

        # ── Normal movement ───────────────────────────────────
        player.zone_x = new_col
        player.zone_y = new_row
        self._save(sender, player)

        # ── Encounter check for grass/water tiles ─────────────
        try:
            if tile in ("GG", "WW") and zone_id not in ("oak_town",):
                from encounters import roll_encounter
                respite = player.get_flag("respite_steps", 0)
                if respite > 0:
                    player.set_flag("respite_steps", respite - 1)
                    self._save(sender, player)
                else:
                    grass_steps = player.get_flag("grass_steps", 0)
                    if roll_encounter(grass_steps):
                        player.set_flag("grass_steps", 0)
                        player.set_flag("respite_steps", 1)
                        self._save(sender, player)
                        from ._constants import STATE_EXPLORING
                        session = self._session(sender)
                        session.transition(STATE_EXPLORING)
                        return self._spawn_encounter(sender, player, session, direction,
                                                     "water" if tile == "WW" else "GG")
                    else:
                        player.set_flag("grass_steps", grass_steps + 1)
                        self._save(sender, player)
            elif tile not in ("GG", "WW"):
                player.set_flag("grass_steps", 0)
                self._save(sender, player)
        except Exception as e:
            import sys
            print(f"[MOVEMENT] encounter check error: {e}", file=sys.stderr, flush=True)

        return self._render_zone_map(sender, player)

