# ============================================================
# NIFLHEIM — router/lord.py
# Lord commands: .throne, .dethrone, .spawn, .spawnp
# ============================================================

import random
from lords import is_king, is_lord, throne, dethrone, list_lords, _jid_from_mention
from encounters import build_wild_monster, encounter_screen
from combat_session import STATE_ENCOUNTER, STATE_EXPLORING


class LordMixin:

    # ── Entry point ───────────────────────────────────────────

    def _handle_lord(self, sender, player, cmd, args, text, mentioned_jid):
        """Called for any .throne/.dethrone/.spawn/.spawnp command."""

        # ── .throne / .dethrone (King only) ──────────────────
        if cmd == ".throne":
            return self._cmd_throne(sender, args, mentioned_jid)

        if cmd == ".dethrone":
            return self._cmd_dethrone(sender, args, mentioned_jid)

        if cmd == ".lords":
            return self._cmd_lords(sender)

        # Below here: Lords (and King)
        if not is_lord(sender):
            return None   # not a lord — let handler fall through

        if cmd == ".spawn":
            return self._cmd_spawn(sender, args)

        if cmd == ".spawnp":
            return self._cmd_spawnp(sender, player, args)

        if cmd == ".ff":
            return self._cmd_ff(sender, args)

        if cmd == ".ffp":
            return self._cmd_ffp(sender, args)

        return None

    # ── .throne ───────────────────────────────────────────────

    def _cmd_throne(self, sender, args, mentioned_jid):
        if not is_king(sender):
            return "👑 _Only the King can grant lordship._"

        target = mentioned_jid or (args[0] if args else None)
        if not target:
            return "⚠️ Usage: *.throne @number*"

        jid = _jid_from_mention(target)
        throne(jid)
        num = jid.split("@")[0]
        return f"👑 *+{num}* has been granted *Lord* status."

    # ── .dethrone ─────────────────────────────────────────────

    def _cmd_dethrone(self, sender, args, mentioned_jid):
        if not is_king(sender):
            return "👑 _Only the King can dethrone a Lord._"

        target = mentioned_jid or (args[0] if args else None)
        if not target:
            return "⚠️ Usage: *.dethrone @number*"

        jid = _jid_from_mention(target)
        dethrone(jid)
        num = jid.split("@")[0]
        return f"⚔️ *+{num}* has been dethroned."

    # ── .lords ────────────────────────────────────────────────

    def _cmd_lords(self, sender):
        if not is_king(sender) and not is_lord(sender):
            return None
        from lords import KING_JID
        lords = list_lords()
        if not lords:
            lines = ["_(no lords yet)_"]
        else:
            lines = [f"  +{j.split('@')[0]}" for j in lords]
        return (
            "╭━━❰ ⌖ 𝙻𝙾𝚁𝙳𝚂 ⌖ ❱━━╮\n"
            f"┃ 👑 King  › +{KING_JID.split('@')[0]}\n"
            "┃\n"
            "┃ ⚔️ Lords:\n" +
            "\n".join(f"┃ {l}" for l in lines) + "\n"
            "╰━━━━━━━━━━━━━━━━━╯"
        )

    # ── .spawn (cache tool) ───────────────────────────────────

    def _cmd_spawn(self, sender, args):
        """Cache a Pokémon's data without spawning in-world."""
        from pokeapi import get_full

        if args:
            name_or_id = args[0].lower()
        else:
            name_or_id = random.randint(1, 1025)

        self._send_to(sender, f"_Fetching data for *{name_or_id}*…_")
        data = get_full(self.db, name_or_id)
        if not data:
            return f"❌ Could not fetch data for `{name_or_id}`."

        name = data["name"].capitalize()
        types = "/".join(t.capitalize() for t in data.get("types", []))
        hp    = data["base_stats"].get("hp", "?")
        atk   = data["base_stats"].get("attack", "?")
        return (
            f"✅ *{name}* cached.\n"
            f"Type: {types}  |  Base HP: {hp}  |  Base ATK: {atk}\n"
            f"_Data saved to PokéAPI cache._"
        )

    # ── .spawnp (spawn in-world for all players in zone) ──────

    def _cmd_spawnp(self, sender, player, args):
        """
        .spawnp name lvl zone   → spawn in specific zone
        .spawnp name lvl        → spawn in random zone
        """
        from pokeapi import get_full
        from encounters import build_wild_monster, encounter_screen
        from map import load_zone
        from combat_session import STATE_ENCOUNTER

        # ── Parse args ────────────────────────────────────────
        if len(args) < 2:
            return (
                "⚠️ Usage:\n"
                "  *.spawnp name level zone*\n"
                "  *.spawnp name level*  _(random zone)_"
            )

        name_input = args[0].lower()
        try:
            level = max(1, min(100, int(args[1])))
        except ValueError:
            return "⚠️ Level must be a number. `.spawnp name level [zone]`"

        if len(args) >= 3:
            zone_id = args[2].lower()
        else:
            # pick a random zone that has players, else any known zone
            known_zones = ["oak_town", "route_1"]
            all_senders = self.db.all_senders()
            zones_with_players = set()
            for s in all_senders:
                p = self._get(s)
                if p:
                    zones_with_players.add(getattr(p, "zone", "oak_town"))
            zone_id = random.choice(list(zones_with_players)) if zones_with_players else random.choice(known_zones)

        # ── Validate zone ─────────────────────────────────────
        zone = load_zone(zone_id)
        if not zone:
            return f"❌ Zone `{zone_id}` not found."

        # ── Fetch Pokémon data ─────────────────────────────────
        self._send_to(sender, f"_Summoning *{name_input.capitalize()}* to {zone.get('name', zone_id)}…_")
        api_data = get_full(self.db, name_input)
        if not api_data:
            return f"❌ Could not find Pokémon `{name_input}`."

        monster = build_wild_monster(api_data, level)

        # ── Broadcast to all players in that zone ─────────────
        all_senders = self.db.all_senders()
        targets = []
        for s in all_senders:
            p = self._get(s)
            if p and getattr(p, "zone", None) == zone_id:
                targets.append((s, p))

        if not targets:
            return f"⚠️ No players currently in *{zone.get('name', zone_id)}*. Nobody to encounter it."

        zone_name  = zone.get("name", zone_id)
        spawn_msg  = encounter_screen(monster)
        notif      = f"⚡ _A wild Pokémon has been summoned in *{zone_name}*!_\n\n" + spawn_msg

        count = 0
        for s, p in targets:
            sess = self._session(s)
            # Only interrupt idle/exploring players — don't stomp active battles
            if sess.state in (STATE_EXPLORING, "idle"):
                sess.set_encounter(monster.copy(), None)
                p.see_pokemon(api_data["name"])
                self._save(s, p)
                self._send_to(s, notif)
                count += 1

        conf_name = api_data["name"].capitalize()
        return (
            f"✅ *{conf_name}* Lv.{level} spawned in *{zone_name}*.\n"
            f"_{count} player(s) received the encounter._"
        )

    # ── .ff (fetch/cache moves) ───────────────────────────────

    def _cmd_ff(self, sender, args):
        """
        .ff            → 1 random move
        .ff 10         → 10 random moves
        .ff light      → 1 random move containing 'light'
        .ff light 10   → 10 random moves containing 'light'
        .ff tackle     → cache specific move 'tackle'
        .ff cyndaquil  → all moves of cyndaquil (detected by non-numeric, non-filter)
        """
        import requests
        from pokeapi import get_move, get_full

        # Parse args
        filter_str = None
        count      = 1
        is_poke    = False

        if len(args) == 0:
            pass
        elif len(args) == 1:
            if args[0].isdigit():
                count = min(int(args[0]), 50)
            else:
                filter_str = args[0].lower()
        elif len(args) >= 2:
            if args[1].isdigit():
                filter_str = args[0].lower()
                count      = min(int(args[1]), 50)
            else:
                filter_str = args[0].lower()

        self._send_to(sender, f"_Fetching move list from PokéAPI…_")

        # Check if filter_str is a Pokémon name
        if filter_str:
            poke_data = get_full(self.db, filter_str)
            if poke_data and poke_data.get("moves"):
                # It's a Pokémon — fetch all its moves
                move_names = [m["move"]["name"] if isinstance(m, dict) and "move" in m
                              else m for m in poke_data["moves"]]
                self._send_to(sender, f"_Found {len(move_names)} moves for *{filter_str.capitalize()}*. Caching…_")
                cached, failed = 0, 0
                for mn in move_names:
                    try:
                        result = get_move(self.db, mn)
                        if result:
                            cached += 1
                        else:
                            failed += 1
                    except Exception:
                        failed += 1
                return (
                    f"✅ *{filter_str.capitalize()}* moves cached.\n"
                    f"  Cached: *{cached}* · Failed: *{failed}*"
                )

        # Fetch full move list from PokeAPI
        try:
            resp  = requests.get("https://pokeapi.co/api/v2/move?limit=10000", timeout=10)
            moves = resp.json().get("results", [])
        except Exception as e:
            return f"❌ Failed to fetch move list: {e}"

        all_names = [m["name"] for m in moves]

        # Apply filter
        if filter_str:
            pool = [n for n in all_names if filter_str in n]
            if not pool:
                return f"❌ No moves found matching `{filter_str}`."
        else:
            pool = all_names

        selected = random.sample(pool, min(count, len(pool)))

        self._send_to(sender, f"_Caching *{len(selected)}* move(s)…_")
        cached, failed = 0, 0
        for mn in selected:
            try:
                result = get_move(self.db, mn)
                if result:
                    cached += 1
                else:
                    failed += 1
            except Exception:
                failed += 1

        names_preview = ", ".join(n.replace("-", " ").title() for n in selected[:5])
        if len(selected) > 5:
            names_preview += f" … (+{len(selected) - 5} more)"
        return (
            f"✅ Move fetch complete.\n"
            f"  Cached: *{cached}* · Failed: *{failed}*\n"
            f"  _{names_preview}_"
        )

    # ── .ffp (fetch/cache Pokémon + their moves) ─────────────

    def _cmd_ffp(self, sender, args):
        """
        .ffp      → 1 random Pokémon + all its moves
        .ffp 10   → 10 random Pokémon + all their moves
        """
        import requests
        from pokeapi import get_full, get_move

        count = 1
        if args and args[0].isdigit():
            count = min(int(args[0]), 20)

        self._send_to(sender, f"_Fetching Pokémon list from PokéAPI…_")

        try:
            resp  = requests.get("https://pokeapi.co/api/v2/pokemon?limit=10000", timeout=10)
            pokes = resp.json().get("results", [])
        except Exception as e:
            return f"❌ Failed to fetch Pokémon list: {e}"

        all_names = [p["name"] for p in pokes]
        selected  = random.sample(all_names, min(count, len(all_names)))

        self._send_to(sender, f"_Caching *{len(selected)}* Pokémon + their moves…_")

        total_poke, total_moves, failed = 0, 0, 0
        for pname in selected:
            try:
                pdata = get_full(self.db, pname)
                if not pdata:
                    failed += 1
                    continue
                total_poke += 1
                move_names = [m["move"]["name"] if isinstance(m, dict) and "move" in m
                              else m for m in pdata.get("moves", [])]
                for mn in move_names:
                    try:
                        if get_move(self.db, mn):
                            total_moves += 1
                    except Exception:
                        pass
            except Exception:
                failed += 1

        poke_preview = ", ".join(n.capitalize() for n in selected[:5])
        if len(selected) > 5:
            poke_preview += f" … (+{len(selected) - 5} more)"
        return (
            f"✅ Pokémon fetch complete.\n"
            f"  Pokémon: *{total_poke}* · Moves: *{total_moves}* · Failed: *{failed}*\n"
            f"  _{poke_preview}_"
        )
