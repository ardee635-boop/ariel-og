# ============================================================
# NIFLHEIM-ONLINE — SITE ACTION HANDLERS
#
# Actions dispatched from the site (via bridge.py's "type" field,
# as opposed to WhatsApp commands via "text"). These run through
# the same Player/OwnedPokemon model as the bot, so party/PC rules
# never drift between WhatsApp and the site.
#
# Every handler takes (router, sender, payload) and returns a plain
# dict — no game text, just structured data for the site to render.
# Errors are returned as {"error": "..."} rather than raised, since
# bridge.py forwards this straight back to Node/the site as JSON.
#
# MODEL NOTE: player.party and player.box are both flat lists with
# no gaps (see models.Player.add_to_party) — "empty slot" in the UI
# just means index >= len(list), it isn't a stored null. So a swap
# either exchanges two existing mons, or moves one mon into a list
# that has room, never creates a hole.
# ============================================================

MAX_PARTY = 6


def _list_for(player, loc):
    if loc == "party":
        return player.party
    if loc == "pc":
        return player.box
    return None


def _serialize_slots(player):
    return {
        "party": [p.to_dict() for p in player.party],
        "pc":    [p.to_dict() for p in player.box],
    }


def handle_swap(router, sender, payload):
    """
    Move/swap a Pokémon between two slots — party<->party, pc<->pc,
    or party<->pc.

    payload: {
        "from": {"loc": "party"|"pc", "idx": int},
        "to":   {"loc": "party"|"pc", "idx": int},
    }

    Rules:
    - Both slots must reference an EXISTING mon, OR the destination
      may be "one past the end" (an empty visual slot) as long as
      the target list has room (party capped at 6, pc uncapped).
    - If destination holds a mon, source and destination swap places.
    - If destination is the empty slot past the end, the mon simply
      moves there and is removed from the source list.
    """
    player = router._get(sender)
    if not player:
        return {"error": "No player record found."}

    frm = payload.get("from") or {}
    to  = payload.get("to") or {}
    from_loc, from_idx = frm.get("loc"), frm.get("idx")
    to_loc,   to_idx   = to.get("loc"),   to.get("idx")

    from_list = _list_for(player, from_loc)
    to_list   = _list_for(player, to_loc)

    if from_list is None or to_list is None:
        return {"error": "Invalid location. Must be 'party' or 'pc'."}
    if not isinstance(from_idx, int) or not isinstance(to_idx, int):
        return {"error": "Invalid slot index."}
    if from_idx < 0 or to_idx < 0:
        return {"error": "Slot index out of range."}
    if from_idx >= len(from_list):
        return {"error": "No Pokémon in that slot."}

    # Same list, same index — no-op.
    if from_loc == to_loc and from_idx == to_idx:
        return {"ok": True, **_serialize_slots(player)}

    dest_has_mon = to_idx < len(to_list)
    dest_is_next_empty = to_idx == len(to_list)

    if not dest_has_mon and not dest_is_next_empty:
        return {"error": "Destination slot is out of range."}

    if to_loc == "party" and to_idx >= MAX_PARTY:
        return {"error": "Party is capped at 6 Pokémon."}

    moving_mon = from_list[from_idx]

    if from_loc == to_loc:
        # Same list — plain positional swap (dest always has_mon here,
        # since same-list "next empty" would mean idx == len(list),
        # which can't happen unless the list is being appended to itself).
        from_list[from_idx], from_list[to_idx] = from_list[to_idx], from_list[from_idx]
    else:
        # Cross-list move.
        if dest_has_mon:
            # True swap: each mon takes the other's slot.
            other_mon = to_list[to_idx]
            to_list[to_idx] = moving_mon
            from_list[from_idx] = other_mon
        else:
            # Destination is the empty slot past the end — plain move.
            # (Party cap already checked above before any mutation.)
            to_list.append(moving_mon)
            from_list.pop(from_idx)

    router._save(sender, player)
    return {"ok": True, **_serialize_slots(player)}
