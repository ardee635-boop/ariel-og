# ============================================================
# NIFLHEIM — router/admin.py
# Admin commands and test utilities
# ============================================================

from models import Player
from ._constants import STATE_IDLE


class AdminMixin:

    def _handle_admin(self, sender, player, cmd, args, text, mentioned_jid):
        if cmd == ".player":
            return self._admin_test_player(sender, args)

        if cmd == ".tp":
            player.zone         = "oak_town"
            player.zone_x       = 2
            player.zone_y       = 4
            player.static_state = None
            self._save(sender, player)
            return (
                "🌀 *Teleported to Oak Town entrance.*\n\n"
                + self._render_zone_map(sender, player)
            )

        if cmd == ".setstage":
            if not args:
                return "⚠️ Usage: *.setstage [stage]*"
            player.story_stage = args[0]
            self._save(sender, player)
            return f"✅ story_stage set to `{args[0]}`"

        if cmd == ".tagall":
            msg = text[len(".tagall"):].strip()
            grp = getattr(self, "_last_group_jid", None)
            if hasattr(self, "_direct_send"):
                self._direct_send(msg, grp, tag_all=True, hide_tags=False)
            return None

        if cmd == ".hidetag":
            msg = text[len(".hidetag"):].strip()
            grp = getattr(self, "_last_group_jid", None)
            if hasattr(self, "_direct_send"):
                self._direct_send(msg, grp, tag_all=True, hide_tags=True)
            return None

        if cmd == ".delete":
            if not args: return "⚠️ Usage: *.delete [name]*"
            tn = " ".join(args)
            ts, tp = self._find_player_by_name(tn)
            if not tp: return f"❓ '{tn}' not found."
            self.db.delete(ts); self.db.delete_reg(ts)
            self.cache.pop(ts, None); self.sessions.pop(ts, None)
            return f"🗑️ *{tn}* deleted."

        return None

    def _find_player_by_name(self, name):
        import json
        try:
            rows = self.db.conn.execute("SELECT sender, data FROM players").fetchall()
            for sender, data in rows:
                try:
                    d = json.loads(data)
                    if d.get("name", "").lower() == name.lower():
                        p = self._get(sender)
                        if p: return sender, p
                except: pass
        except: pass
        return None, None

    def _admin_test_player(self, sender, args):
        test = Player("TestPlayer")
        test.story_stage = "new"
        test.zone        = "oak_town"
        test.zone_x      = 12
        test.zone_y      = 6
        self.cache[sender] = test
        self.db.save(sender, test)
        return "🧪 Test player created."
