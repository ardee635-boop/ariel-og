# ============================================================
# NIFLHEIM — router/amongus_map.py
# Room graph for Among Us mode, transcribed from the Skeld
# reference image Joel confirmed. Dwell times are EYEBALLED
# placeholders (varied by visual distance, not measured) —
# easy to retune later, the engine just reads these numbers.
# ============================================================

START_ROOM = "CAFETERIA"

# room -> {neighbor: seconds}. Symmetric (built both directions below).
_EDGES_RAW = [
    ("CAFETERIA", "MEDBAY", 4),
    ("CAFETERIA", "WEAPONS", 4),
    ("CAFETERIA", "STORAGE", 5),
    ("CAFETERIA", "ADMIN", 6),       # confirmed direct — not only via Storage
    ("UPPER_ENGINE", "REACTOR", 4),
    ("REACTOR", "LOWER_ENGINE", 4),
    ("REACTOR", "SECURITY", 4),      # the 4-way junction (Upper/Lower Engine, Security all meet at Reactor)
    ("SECURITY", "MEDBAY", 4),
    ("SECURITY", "ELECTRICAL", 4),
    ("ELECTRICAL", "STORAGE", 4),
    ("STORAGE", "ADMIN", 4),
    ("STORAGE", "COMMUNICATIONS", 5),
    ("ADMIN", "SHIELDS", 5),
    ("WEAPONS", "O2", 4),
    ("O2", "NAVIGATION", 5),
    ("NAVIGATION", "SHIELDS", 4),
    ("SHIELDS", "COMMUNICATIONS", 4),
]

EDGES = {}
for _a, _b, _t in _EDGES_RAW:
    EDGES.setdefault(_a, {})[_b] = _t
    EDGES.setdefault(_b, {})[_a] = _t

ROOMS = sorted(EDGES.keys())

# Impostor-only vent network. Best-read transcription of the triangle
# markers — flagged as less certain than the room adjacency, confirm
# against the real map if something feels off.
VENTS = {
    "REACTOR":      ["UPPER_ENGINE", "LOWER_ENGINE"],
    "UPPER_ENGINE":  ["REACTOR", "LOWER_ENGINE"],
    "LOWER_ENGINE":  ["REACTOR", "UPPER_ENGINE"],
    "ELECTRICAL":   ["MEDBAY", "SECURITY"],
    "MEDBAY":       ["ELECTRICAL", "SECURITY"],
    "SECURITY":     ["ELECTRICAL", "MEDBAY"],
    "WEAPONS":      ["NAVIGATION"],
    "NAVIGATION":   ["WEAPONS", "SHIELDS"],
    "SHIELDS":      ["NAVIGATION"],
}

# One task per room for this test build — real game gives each crewmate
# a randomized SUBSET of tasks; for the first test run every crewmate
# gets the full list so .task/.progress are easy to exercise everywhere.
TASKS = {
    "CAFETERIA":      ("Empty Garbage", 6),
    "MEDBAY":         ("Submit Scan", 10),
    "UPPER_ENGINE":   ("Fuel Engine", 7),
    "SECURITY":       ("Fix Wiring", 6),
    "REACTOR":        ("Start Reactor", 9),
    "LOWER_ENGINE":   ("Fuel Engine", 7),
    "ELECTRICAL":     ("Fix Wiring", 8),
    "STORAGE":        ("Fuel Engines", 6),
    "ADMIN":          ("Swipe Card", 5),
    "WEAPONS":        ("Clear Asteroids", 6),
    "O2":             ("Empty Garbage", 6),
    "NAVIGATION":     ("Chart Course", 7),
    "SHIELDS":        ("Prime Shields", 6),
    "COMMUNICATIONS": ("Upload Data", 6),
}

# Meltdown's two fix-rooms — mapped to the real game's actual O2
# sabotage pairing (two separate rooms), per the design notes' rule
# that Meltdown always needs two different rooms to confirm from.
MELTDOWN_ROOMS = ("O2", "ADMIN")
MELTDOWN_DOOM_SECONDS = 30
COOLDOWN_ACTION_SECONDS = 6


def shortest_path(start, end):
    """Dijkstra over EDGES, minimizing total travel TIME (not hop count),
    since dwell time varies per edge. Returns list of rooms including
    start and end, or None if unreachable (shouldn't happen — graph's
    fully connected) or start==end (returns [start])."""
    if start == end:
        return [start]
    import heapq
    dist = {start: 0}
    prev = {}
    pq = [(0, start)]
    visited = set()
    while pq:
        d, node = heapq.heappop(pq)
        if node in visited:
            continue
        visited.add(node)
        if node == end:
            break
        for nbr, w in EDGES.get(node, {}).items():
            nd = d + w
            if nbr not in dist or nd < dist[nbr]:
                dist[nbr] = nd
                prev[nbr] = node
                heapq.heappush(pq, (nd, nbr))
    if end not in dist:
        return None
    path = [end]
    while path[-1] != start:
        path.append(prev[path[-1]])
    path.reverse()
    return path


def path_hops(path):
    """[(room_a, room_b, seconds), ...] for each leg of a path."""
    return [(path[i], path[i+1], EDGES[path[i]][path[i+1]]) for i in range(len(path) - 1)]
