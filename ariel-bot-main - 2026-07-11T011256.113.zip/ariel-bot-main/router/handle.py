# ============================================================
# NIFLHEIM — router/handle.py
# Main message dispatch — handle()
# ============================================================

import random, re, sys
from interfaces import UI
from npc import oak_intro
from combat_session import STATE_ARENA_PENDING, STATE_GYM_PENDING
from ._constants import (
    STATE_IDLE, STATE_EXPLORING, STATE_ENCOUNTER, STATE_BATTLE,
    STATE_DEAD, STATE_PVP, STATE_RAID, STATE_ARENA, STATE_GYM,
    ADMIN_SENDER, DIRECTIONS, DODGE_WORDS,
    TutorialManager,
    victory_level_up, active_quests_ui, quest_card_ui,
    quest_offer_ui, get_mira_quest_offer, is_mira_quest_request,
    LOCATION_NPC_MAP, NPC_DECLINE_LINES, board_ui,
    generate_board, get_premade_quest, should_offer_quest,
    generate_ai_quest, validate_report, register_quest_spawn,
    clear_quest_spawn, can_access_rank, check_rank_up,
    RANK_ORDER, RANK_LEVEL, RANK_TITLES, RANK_BADGE,
    RANK_UP_AT, MAX_QUESTS, _M, MonsterLibrary,
)
from npc import (
    talk_to_npc, NPC_PROFILES, NPC_ALIASES, ZONE_NPCS,
    npc_available_in_zone, resolve_npc_alias,
    physical_npc_speak, ariel_route, check_directive_fired,
    ariel_wants_fight,
)


class HandleMixin:

    BATTLE_SAFE_CMDS = {
        ".status", ".card", ".cardv", ".setage", ".setbio", ".skills", ".skill",
        ".inv", ".inventory", ".party", ".quests", ".quest",
        ".board", ".redeem", ".accept", ".rankup", ".talk", ".arena", ".gym", ".next",
        ".quest", ".hud", ".cds", ".bal", ".pokedex", ".heal", ".me",
        ".buy", ".sell",
    }

    # Commands that always work regardless of battle/encounter state
    GLOBAL_CMDS = {
        ".resetprofile", ".reset", ".menu", ".pmenu",
        ".quicktravel", ".ranks", ".whois", ".rules",
        ".warnings", ".location", ".minimap", ".dash", ".heal", ".shop",
        ".buy", ".sell", ".font",
    }

    DIRECTIVE_COOLDOWN_SECONDS = 1800  # 30 min, per directive

    def handle(self, sender, text, mentioned_jid=None, quoted_text=None):
        # ── Among Us mode gate — fully isolated, checked before ANYTHING
        # else (Ariel calls, directives, Pokémon registration, stage
        # machine). If not handled here, falls through unchanged. ──
        from .amongus import NOT_HANDLED
        _au_group_jid = getattr(self, "_last_group_jid", None)
        _au_result = self.amongus.pre_dispatch(sender, text, _au_group_jid)
        if _au_result is not NOT_HANDLED:
            return _au_result

        # ── .groupid — returns JID/LID of the current chat (always reachable) ──
        if text.strip().lower() == ".groupid":
            _gj = getattr(self, "_last_group_jid", None)
            _lid = getattr(self, "_last_lid", None)
            if _gj:
                parts = [f"*Group JID:* `{_gj}`"]
                if _lid:
                    parts.append(f"*LID:* `{_lid}`")
                return "\n".join(parts)
            return f"*Your JID:* `{sender}`"

        # ── Reactive directives — only costs anything if sender is actually watched ──
        try:
            group_jid = getattr(self, "_last_group_jid", None)
            watched = self.db.directives_targeting(sender, group_jid=group_jid)
            if watched and text.strip():
                import datetime
                now = datetime.datetime.utcnow()
                for d in watched:
                    if d["last_fired"]:
                        try:
                            last = datetime.datetime.fromisoformat(d["last_fired"])
                            if (now - last).total_seconds() < self.DIRECTIVE_COOLDOWN_SECONDS:
                                continue
                        except ValueError:
                            pass
                    if check_directive_fired(d["condition"], text):
                        self.db.directive_touch_fired(d["id"])
                        self._send_to(sender, f"*Ariel:* _{d['action']}_")
                        break  # one firing per message, keeps this from cascading
        except Exception as e:
            print(f"[DIRECTIVES] check failed: {e}", file=sys.stderr, flush=True)

        # ── Ariel trigger ─────────────────────────────────────
        raw_lower = text.lower().strip()
        is_ariel_call = bool(re.search(r'\bariel\b', raw_lower))
        is_gpt_call = raw_lower.startswith(".gpt")
        if is_gpt_call:
            parts_gpt = text.split(None, 1)
            text = parts_gpt[1] if len(parts_gpt) > 1 else ""
            raw_lower = text.lower().strip()
            is_ariel_call = True
        if is_ariel_call or quoted_text:
            session = self._session(sender)
            stage   = getattr(session, "state", None)
            not_in_battle = stage not in (STATE_BATTLE, STATE_ARENA, STATE_ARENA_PENDING, STATE_GYM, STATE_GYM_PENDING, STATE_PVP, STATE_RAID, "battle_menu")
            if is_ariel_call or (quoted_text and not_in_battle):
                query = text.strip()
                if query or quoted_text:
                    full_query = query or f"(replying to: {quoted_text})"
                    player = self._get(sender)  # optional — None for unregistered

                    # ── Fight intent detection ───────────────────────
                    if player and not_in_battle and ariel_wants_fight(full_query):
                        from arena import ariel_prompt
                        msg = ariel_prompt(self.db, sender, player, initiated_by_player=True)
                        self._save(sender, player)
                        return msg

                    zone_id = getattr(player, "zone", "oak_town") if player else "oak_town"
                    zone_npc_ids = ZONE_NPCS.get(zone_id, [])
                    affection_tier_name, _affection_score = self.db.affection_tier(sender)
                    owner_directives = self.db.directives_list_owner(sender)

                    result = ariel_route(
                        sender, full_query, player=player, zone_id=zone_id,
                        zone_npc_ids=zone_npc_ids, affection_tier=affection_tier_name,
                        owner_directives=owner_directives, db=self.db,
                    )
                    persona   = result.get("persona", "ariel")
                    reply     = result.get("reply", "")
                    directive = result.get("directive")

                    extra_note = ""
                    if directive and directive.get("condition") and directive.get("action"):
                        new_id = self.db.directive_create(
                            owner=sender,
                            condition=directive["condition"],
                            action=directive["action"],
                            target_jid=mentioned_jid,
                            target_name=directive.get("target_name"),
                            group_jid=getattr(self, "_last_group_jid", None),
                            trigger_type="reactive",
                        )
                        if new_id is None:
                            extra_note = "\n\n_(You've already got 5 things I'm watching — clear one first.)_"

                    self.db.affection_add(sender, 1)

                    if persona != "ariel" and persona in zone_npc_ids:
                        npc_reply, _img = talk_to_npc(persona, sender, full_query, player=player, zone_id=zone_id)
                        self.db.familiarity_add(sender, persona, 1)
                        if npc_reply:
                            npc_display = NPC_PROFILES.get(persona, {}).get("name", persona)
                            return f"*{npc_display}:* _{npc_reply}_"

                    if reply:
                        return reply + extra_note

        # Strip leading bot mention (e.g. "ariel 1" → "1")
        if text.lower().startswith("ariel "):
            text = text[6:].strip()
        text = self._normalize(text)
        if not text: return None
        print(f"[HANDLE] sender={sender} text={text}", file=sys.stderr, flush=True)

        parts = text.split()
        cmd   = parts[0].lower()
        args  = parts[1:]

        if cmd == ".start":
            push_name = getattr(self, "_last_push_name", None)
            return self._start(sender, push_name=push_name)

        try:
            if sender not in self.reg:
                db_reg = self.db.load_reg(sender)
                if db_reg: self.reg[sender] = db_reg
        except Exception as e:
            print(f"[ROUTER] load_reg failed: {e}", file=sys.stderr, flush=True)

        if cmd == ".resetprofile":
            self.db.delete(sender)
            self.cache.pop(sender, None)
            self.sessions.pop(sender, None)
            self.reg.pop(sender, None)
            self.db.delete_reg(sender)
            return "🗑️ *Profile deleted.*\n\n_Type *.start* to begin anew._"

        if sender in self.reg:
            return self._reg_handle(sender, text)

        if cmd == ".menu":
            player = self._get(sender)
            if player: return UI.menu(player)
            return UI.not_started()

        if cmd == ".pmenu":
            player = self._get(sender)
            if player: return UI.pmenu(player)
            return UI.not_started()

        player = self._get(sender)
        if not player:
            return UI.not_started() if text.startswith(".") else None

        session = self._session(sender)
        stage   = session.state

        # ── Arena state — only battle cmds + .next allowed ──
        ARENA_ALLOWED = {
            ".next",".atk",".run",".catch",".use",".med",
            ".inv",".party",".status",".card",".bag",
            ".throne",".dethrone",".lords",".spawn",".spawnp",".ff",".ffp",
            ".reset",".resetprofile",
        }
        if stage in (STATE_ARENA, STATE_ARENA_PENDING) and cmd and cmd.startswith(".") and cmd not in ARENA_ALLOWED:
            return None
        if stage in (STATE_GYM, STATE_GYM_PENDING) and cmd and cmd.startswith(".") and cmd not in ARENA_ALLOWED:
            return None

        # ── Static state — train switch, highest priority ─
        static = getattr(player, "static_state", None)
        if static:
            _lab_passthrough = {".yes", ".no", ".skip", ".next", ".name",
                                  ".buy", ".sell", ".shop", ".inv", ".inventory",
                                  ".bal", ".status", ".card", ".party", ".minimap"}
            is_dash_cmd = (
                text.startswith(".") and
                not text.strip().lstrip("-")[:1].isdigit() and
                text.split()[0].lower() not in _lab_passthrough
            )
            if not is_dash_cmd:
                if static == "oak_lab_1":
                    return self._handle_lab_flow(sender, player, text, quoted_text=quoted_text, mentioned_jid=mentioned_jid)
                if static == "oak_mart":
                    player.static_state = None
                    self._save(sender, player)
                return None  # unknown static state — silent ignore

        if stage == STATE_DEAD:
            if cmd in (".status", ".card"): return player.card_text()
            return "_All your Pokémon have fainted. Visit a Pokémon Center to heal up._"

        if stage == "pve_swap":
            monster = getattr(session, "encounter_monster", None)
            if cmd == ".swap":
                if not args or not args[0].isdigit():
                    return "_Usage: .swap (party no.)_"
                idx  = int(args[0]) - 1
                if idx < 0 or idx >= len(player.party):
                    return "⚠️ _Invalid slot._"
                poke = player.party[idx]
                if poke.is_fainted():
                    return f"_{poke.nickname} cannot be summoned right now_"
                player.set_active(idx)
                session.state = "battle_menu" if monster else STATE_EXPLORING
                self._save(sender, player)
                from battle import battle_screen
                msg = f"Go, *{poke.nickname}*!"
                if monster:
                    return msg + "\n\n" + battle_screen(poke, monster)
                return msg
            if cmd in (".flee", "flee"):
                session.clear_encounter()
                session.transition(STATE_EXPLORING)
                self._save(sender, player)
                return "_You fled the battle!_"
            if cmd not in self.BATTLE_SAFE_CMDS:
                return "_Choose a Pokémon to send out with .swap (no.), or .flee._"

        if stage == "pvp_blackout": return None

        if sender == ADMIN_SENDER:
            res = self._handle_admin(sender, player, cmd, args, text, mentioned_jid)
            if res is not None: return res

        # ── Lord commands ─────────────────────────────────────
        if cmd in (".throne", ".dethrone", ".lords", ".spawn", ".spawnp", ".ff", ".ffp"):
            res = self._handle_lord(sender, player, cmd, args, text, mentioned_jid)
            if res is not None: return res

        if cmd == ".reset":
            if hasattr(session, "end_battle"):   session.end_battle()
            if hasattr(session, "clear_encounter"): session.clear_encounter()
            if hasattr(session, "clear_arena"): session.clear_arena()
            self.db.set_meta(sender, "arena_round", "")
            self.db.set_meta(sender, "arena_pending", "")
            self.db.set_meta(sender, "gym_round", "")
            self.db.set_meta(sender, "gym_zone", "")
            self.db.set_meta(sender, "gym_used_names", "")
            self.db.set_meta(sender, "active_npc", "")
            session.transition(STATE_IDLE)
            player.current_monster = None
            if hasattr(player, "reset_battle"): player.reset_battle()
            self._save(sender, player)
            return "🔄 _State reset._"

        if cmd == ".forfeit":
            if stage == STATE_PVP:
                return self.handle_pvp_flee(sender, player)
            return "_.forfeit only applies to PvP battles. Use .flee instead._"

        if cmd in (".flee", "flee"):
            if stage == STATE_RAID: return "⚠️ _You cannot flee a raid._"
            if stage == STATE_PVP:
                return self.handle_pvp_flee(sender, player)
            if stage in (STATE_EXPLORING, STATE_ENCOUNTER, STATE_BATTLE):
                return self._flee(sender, player, session)
            if stage != "battle_menu":
                return None
            # stage == "battle_menu" → fall through to the BattleEngine dispatch
            # below, which runs the real speed-based flee-chance check.

        if stage == "tutorial":
            return TutorialManager.handle(sender, player, text.strip(), self)

        # ── Global commands — always pass through any state ──────
        if cmd in self.GLOBAL_CMDS:
            pass  # fall through to command handlers below
        elif stage in (STATE_ENCOUNTER, "battle_menu"):
            monster = getattr(session, "encounter_monster", None) or getattr(session, "monster", None)
            if not monster:
                session.transition(STATE_EXPLORING); return None

            from battle import BattleEngine
            engine = BattleEngine(self.db, sender)

            # Encounter screen — waiting for .fight or .flee
            if stage == STATE_ENCOUNTER:
                if cmd == ".fight":
                    result = engine.on_encounter(session, player)
                    self._save(sender, player)
                    return self._split_battle_result(sender, result)
                if cmd in self.BATTLE_SAFE_CMDS:
                    pass  # allow status/inv checks during encounter
                else:
                    return "_A wild Pokémon is blocking your path!_\n-fight to engage · .flee to escape"

            # In-battle commands (battle_menu state)
            elif stage == "battle_menu":
                result = engine.on_command(session, player, cmd, args)
                if result is not None:
                    self._save(sender, player)
                    return self._split_battle_result(sender, result)

                if cmd in self.BATTLE_SAFE_CMDS: pass
                else: return None

        if stage == STATE_RAID:
            return "⚠️ _Raids are not yet available._"

        if stage == STATE_PVP:
            if cmd == ".skills":
                poke = player.active_pokemon()
                if not poke: return "_No active Pokémon._"
                from encounters import skills_screen
                return skills_screen(poke)
            if cmd == ".swap":
                if not args or not args[0].isdigit():
                    return "_Usage: .swap (party no.)_"
                session_obj = self._pvp_sessions.get(sender) if hasattr(self, "_pvp_sessions") else None
                voluntary   = session_obj and session_obj.awaiting_swap != sender
                return self.handle_pvp_swap(sender, player, int(args[0]), voluntary=voluntary)
            if cmd == ".giveup":
                return self.handle_pvp_giveup(sender, player)
            if cmd not in self.BATTLE_SAFE_CMDS:
                move_name = cmd.lstrip("-") + (" " + " ".join(args) if args else "")
                return self.handle_pvp_skill(sender, player, move_name.strip())

        if stage == "pvp_pending":
            if cmd == ".accept":
                return self.handle_pvp_accept(sender, player)
            if cmd in (".decline", ".reject"):
                return self.handle_pvp_decline(sender, player)
            if cmd not in self.BATTLE_SAFE_CMDS:
                return None

        if stage == STATE_ARENA and cmd not in (".next", ".arena"):
            from battle import BattleEngine
            engine = BattleEngine(self.db, sender)
            if cmd in self.BATTLE_SAFE_CMDS:
                if session.monster:
                    result = engine.on_command(session, player, cmd, args)
                    if result is not None:
                        self._save(sender, player)
                        return self._split_battle_result(sender, result)
                    return None
                else:
                    pass  # safe cmd, no monster — fall through
            elif session.monster:
                result = engine.on_command(session, player, cmd, args)
                if result is not None:
                    self._save(sender, player)
                    return self._split_battle_result(sender, result)
            return None

        if stage == STATE_GYM and cmd not in (".next", ".gym"):
            from battle import BattleEngine
            engine = BattleEngine(self.db, sender)
            if cmd in self.BATTLE_SAFE_CMDS:
                if session.monster:
                    result = engine.on_command(session, player, cmd, args)
                    if result is not None:
                        self._save(sender, player)
                        return self._split_battle_result(sender, result)
                    return None
                else:
                    pass  # safe cmd, no monster — fall through
            elif session.monster:
                result = engine.on_command(session, player, cmd, args)
                if result is not None:
                    self._save(sender, player)
                    return self._split_battle_result(sender, result)
            return None

        if stage == STATE_EXPLORING:
            if not text.startswith(".") and cmd not in DIRECTIONS: return None

        # ── Movement ──────────────────────────────────────────
        if (cmd in DIRECTIONS and not getattr(player, "static_state", None)
                and getattr(player, "story_stage", None) != "setskill"):
            if stage in (STATE_EXPLORING, STATE_BATTLE, STATE_IDLE) or getattr(player, "story_stage", None) is not None:
                return self._handle_movement(sender, player, cmd)

        # ── NPC routing ───────────────────────────────────────
        # ── .accept / .reject with ariel_pending → Ariel battle ──
        if cmd == ".accept":
            if self.db.get_meta(sender, "ariel_pending"):
                from arena import ariel_enter
                import threading, time
                from battle import battle_hud
                msg = ariel_enter(self.db, sender, player, session)
                self._save(sender, player)

                # 5-second delayed HUD like arena
                def _send_ariel_begin():
                    time.sleep(5)
                    try:
                        session.commit_trainer_battle()
                        active = player.party[player.active_slot]
                        enemy  = session.arena_trainer_team[0] if session.arena_trainer_team else None
                        if enemy:
                            hud = battle_hud(active, enemy)
                            e_name = enemy.get("nickname") or enemy.get("name", "???")
                            begin_msg = (
                                f"*You* sent out *{active.nickname}*!\n"
                                f"*Ariel* sent out *{e_name.capitalize()}*!\n\n"
                                f"{hud}"
                            )
                            grp = getattr(self, "_last_group_jid", None)
                            self._send_to(sender, begin_msg, group_jid=grp)
                    except Exception as e:
                        print(f"[ARIEL-BATTLE] begin thread error: {e}", file=sys.stderr, flush=True)

                threading.Thread(target=_send_ariel_begin, daemon=True).start()
                return msg

        if cmd == ".accept":
            if self.db.get_meta(sender, "arena_pending"):
                from arena import arena_enter
                msg = arena_enter(self.db, sender, player, session)
                self._save(sender, player)
                return msg

        if cmd in (".reject", ".decline"):
            if self.db.get_meta(sender, "ariel_pending"):
                from arena import ariel_reject
                msg = ariel_reject(self.db, sender, player=player)
                self._save(sender, player)
                return msg

        if cmd in (".reject", ".decline"):
            if self.db.get_meta(sender, "arena_pending"):
                from arena import arena_reject
                msg = arena_reject(self.db, sender)
                self._save(sender, player)
                return msg

        if stage == STATE_IDLE:
            lower_text = text.lower()
            zone_id    = getattr(player, "zone", "oak_town") or "oak_town"

            # ── Quest accept/reject (text NPCs) ───────────────
            if lower_text.strip() in ("accept", "reject"):
                meta = self.db.get_meta(sender, "pending_quest_offer")
                if meta:
                    parts2   = meta.split(":", 1)
                    offer_id = int(parts2[0]) if parts2[0].isdigit() else None
                    npc_id   = parts2[1] if len(parts2) > 1 else ""
                    profile  = NPC_PROFILES.get(npc_id, {})
                    npc_name = profile.get("name", "NPC")
                    if offer_id:
                        if lower_text.strip() == "accept":
                            ok = self.db.npc_quest_accept(sender, offer_id)
                            if ok:
                                self.db.delete_meta(sender, "pending_quest_offer")
                                self.db.familiarity_add(sender, npc_id, 3)
                                nq = self.db.npc_quest_get(sender, offer_id)
                                if nq and nq.get("clear_trigger_type") == "spawn":
                                    zone  = nq.get("explore_zone") or ""
                                    spawn = nq.get("target_name", "")
                                    if zone and spawn:
                                        register_quest_spawn(sender, zone, spawn)
                                quest_title = nq["title"] if nq else "Quest"
                                return f"📜 *Quest Accepted!*\n*{quest_title}*\n_Check *.quests* to track your progress._"
                            return "⚠️ _Could not accept quest. Try again._"
                        else:
                            self.db.npc_quest_reject(sender, offer_id)
                            self.db.delete_meta(sender, "pending_quest_offer")
                            self.db.familiarity_add(sender, npc_id, -2)
                            decline_lines = ["Understood.", "Your choice.", "Fine. Come back if you change your mind."]
                            line = random.choice(decline_lines)
                            return f"*{npc_name}:* _{line}_"

            # ── Physical NPC quote-reply continuation ─────────
            active_npc = self.db.get_meta(sender, "active_npc")
            if active_npc and quoted_text:
                profile  = NPC_PROFILES.get(active_npc, {})
                npc_name = profile.get("name", "NPC")

                reply, _ = physical_npc_speak(active_npc, sender, player=player, query=text)
                if reply:
                    return f"*{npc_name}:* _{reply}_"
                return None

            elif not text.startswith("."):
                return None

        # ══ COMMANDS ══════════════════════════════════════════

        # ── .me — how Ariel sees you ─────────────────────────
        if cmd == ".me":
            tier, score = self.db.affection_tier(sender)
            directives = self.db.directives_list_owner(sender)
            active_directives = [d for d in directives if d["active"]]
            lines = [f"*Ariel's read on you:* {tier} ({score}/100)"]
            if active_directives:
                lines.append("\n_Things I'm watching for you:_")
                for d in active_directives[:5]:
                    who = d.get("target_name") or "someone"
                    lines.append(f"  • {who}: {d['condition']}")
            return "\n".join(lines)

        # ── .talk [npc name] — zone-gated text NPC dialogue ──
        if cmd == ".talk":
            zone_id  = getattr(player, "zone", "oak_town") or "oak_town"
            npc_name_input = args[0].lower().strip() if args else ""
            if not npc_name_input:
                return "_Talk to who? Try_ `.talk oak` _or_ `.talk sabrina`_._"

            npc_id = resolve_npc_alias(npc_name_input)
            if not npc_id:
                return f"_There's no one called '{args[0]}' around here._"

            profile = NPC_PROFILES.get(npc_id, {})
            if profile.get("type") == "physical":
                return f"_You need to find {profile.get('name', 'them')} in the world._"

            if not npc_available_in_zone(npc_id, zone_id):
                return f"_*{profile.get('name', npc_id)}* isn't here right now._"

            # Build query from remaining args
            query = " ".join(args[1:]).strip() if len(args) > 1 else ""
            self.db.familiarity_add(sender, npc_id, 1)
            reply, img = talk_to_npc(npc_id, sender, query, player=player, zone_id=zone_id)
            if reply:
                npc_display = profile.get("name", npc_id)
                return f"*{npc_display}:* _{reply}_"
            return "_They don't seem to be responding right now._"

        # ── .arena ────────────────────────────────────────────
        if cmd == ".arena":
            from arena import arena_prompt
            msg = arena_prompt(self.db, sender, player)
            self._save(sender, player)
            return msg

        # ── .gym ──────────────────────────────────────────────
        if cmd == ".gym":
            from gym import gym_enter
            msg = gym_enter(self.db, sender, player, session)
            self._save(sender, player)
            return msg

        # ── .next (arena rounds) ──────────────────────────────
        if cmd == ".next":
            send = getattr(self, "_direct_send", None)
            grp  = getattr(self, "_last_group_jid", None)
            if session.state == STATE_ARENA:
                from arena import arena_next
                round_str = self.db.get_meta(sender, "arena_round")
                if not round_str:
                    return None
                msg = arena_next(self.db, sender, player, session, direct_send=send, group_jid=grp)
                self._save(sender, player)
                return msg
            if session.state == STATE_GYM:
                from gym import gym_next
                round_str = self.db.get_meta(sender, "gym_round")
                if not round_str:
                    return None
                msg = gym_next(self.db, sender, player, session, direct_send=send, group_jid=grp)
                self._save(sender, player)
                return msg
            return None

        if cmd == ".minimap":
            return self._render_zone_map(sender, player)

        if cmd == ".heal":
            if stage in (STATE_BATTLE, STATE_ENCOUNTER, "battle_menu"):
                return None  # handled by BattleEngine
            from data_items import HEALING_ITEMS
            # Identify target pokemon
            if args:
                target_q = " ".join(args)
                target = None
                for i, p in enumerate(player.party):
                    if target_q.isdigit() and int(target_q) - 1 == i:
                        target = p; break
                    if p.nickname.lower() == target_q.lower() or p.name.lower() == target_q.lower():
                        target = p; break
                if not target:
                    return f"⚠️ _No Pokémon found for '{target_q}'._"
            else:
                # Default to active/first non-fainted
                target = player.active_pokemon()
                if not target:
                    return "_Your party has no conscious Pokémon._"
            if target.is_fainted():
                return f"_*{target.nickname}* has fainted and can't be healed with items._"
            if target.hp >= target.max_hp:
                return f"_*{target.nickname}* is already at full HP._"
            # Try healing items in priority order
            for item_name in ("Max Potion", "Hyper Potion", "Super Potion", "Potion"):
                if player.has_item(item_name):
                    player.use_item(item_name)
                    info = HEALING_ITEMS.get(item_name, {})
                    if info.get("effect") == "hp_full":
                        healed = target.max_hp - target.hp
                        target.hp = target.max_hp
                    else:
                        healed = target.heal(info.get("value", 20))
                    self._save(sender, player)
                    return f"_Used *{item_name}*! *{target.nickname}* recovered *{healed} HP*. ({target.hp}/{target.max_hp})_"
            return "_You have no healing items._"

        if cmd == ".location":
            from map import location_display
            return location_display(player)

        if cmd == ".shop":
            return self._handle_shop_cmd(sender, player)

        if cmd == ".buy":
            from .shop import handle_buy
            from egg import ALL_EGGS, start_incubation
            result = handle_buy(sender, player, args, lambda: self._save(sender, player))
            # Auto-start incubation if an egg was purchased
            if result and result.startswith("✅"):
                from data_items import get_shop_with_prices
                from .shop import _shop_context
                try:
                    context = _shop_context(player)
                    items   = get_shop_with_prices(context)
                    if args and args[0].isdigit():
                        idx = int(args[0]) - 1
                        if 0 <= idx < len(items):
                            item_name = items[idx]["name"]
                            if item_name in ALL_EGGS:
                                start_incubation(sender, item_name, self)
                except Exception:
                    pass
            return result

        if cmd == ".sell":
            from .shop import handle_sell
            return handle_sell(sender, player, args, lambda: self._save(sender, player))

        if cmd in (".inv", ".inventory"):
            if args:
                from .shop import handle_inv_detail
                return handle_inv_detail(player, args)
            return UI.inventory(player)

        if cmd == ".hatch":
            from egg import resolve_hatch
            return resolve_hatch(sender, self)

        if cmd in (".status", ".card"): return player.card_text()
        if cmd == ".pokedex": return player.pokedex_text()
        if cmd == ".bal":     return UI.balance(player)

        if cmd == ".setage":
            if not args:
                return "_Usage: .setage [value]_"
            player.age = " ".join(args)
            self._save(sender, player)
            return f"✅ _Age set to_ *{player.age}*"

        if cmd == ".setbio":
            if not args:
                return "_Usage: .setbio [text]_"
            player.bio = " ".join(args)
            self._save(sender, player)
            return f"✅ _Bio updated._"

        if cmd in (".skills", ".skill"):
            if not args:
                return "Please use .skills [pokemon name] to view its skills"

            query = " ".join(args)
            mon = None

            if query.isdigit():
                idx = int(query) - 1
                if 0 <= idx < len(player.party):
                    mon = player.party[idx]
            else:
                q = query.lower()
                for p in player.party:
                    if p.nickname.lower() == q or p.name.lower() == q:
                        mon = p
                        break

            if not mon:
                return f"You don't have a {query} in your party"

            lines = [f"🗡️ *{mon.display_name()}'s Skills*", ""]
            if mon.moves:
                for i, move in enumerate(mon.moves, 1):
                    lines.append(f"{i}. {move.replace('-', ' ').title()}")
            else:
                lines.append("_(no moves learned yet)_")
            return "\n".join(lines)
            themes = {1: "Normal", 2: "Glitch", 3: "Metallic", 4: "Flame"}
            if not args:
                lines = ["🎴 *Card Designs*", ""]
                for n, label in themes.items():
                    marker = " ✅" if n == player.card_theme else ""
                    lines.append(f"{n}. {label}{marker}")
                lines.append("")
                lines.append("_.cardv [no.] to switch_")
                return "\n".join(lines)
            if not args[0].isdigit() or int(args[0]) not in themes:
                return "⚠️ _Invalid design number. Use .cardv to see options._"
            player.card_theme = int(args[0])
            self._save(sender, player)
            return f"✅ _Card design set to_ *{themes[player.card_theme]}*"

        if cmd in (".quests", ".quest", ".board", ".redeem", ".accept", ".rankup"):
            return self._handle_quests(sender, player, cmd, args, text)

        if cmd == ".party":
            if not player.party:
                return "🎒 _Your party is empty. Get a starter from Prof. Oak._"
            # .party [no.] → full detail
            if args and args[0].isdigit():
                idx = int(args[0]) - 1
                if idx < 0 or idx >= len(player.party):
                    return "⚠️ _Invalid slot._"
                return player.party[idx].summary()
            # .party → names only
            lines = ["🎒 *Your Party*", ""]
            for i, p in enumerate(player.party):
                hp_bar = "💀" if p.is_fainted() else f"{p.hp}/{p.max_hp} HP"
                lines.append(f"  *{i+1}.* {p.nickname}  Lv.{p.level}  —  {hp_bar}")
            lines.append("")
            lines.append("_.party [no.] for full info_")
            return "\n".join(lines)

        if cmd == ".pheal":
            from world_registry import get_zone
            zone = get_zone(getattr(player, "zone", ""))
            if zone.get("zone_type") != "town":
                return "_You need to be in a town to do that._"
            if not player.party:
                return "🎒 _Your party is empty._"

            healed = 0
            for mon in player.party:
                if hasattr(mon, "heal_full"):
                    mon.heal_full()
                    healed += 1

            import time as _time
            session = self._session(sender)
            if session.state == STATE_DEAD:
                session.transition(STATE_EXPLORING)

            self.db.set_meta(sender, "pc_healing", str(_time.time() + 3))
            self._save(sender, player)

            self._queue_message(sender,
                "🏥 *Pokémon Center*\n"
                "━━━━━━━━━━━━━━━━\n"
                "_Welcome to the Pokémon Care Center.\n"
                "Please wait while we heal your Pokémon..._",
                delay=0
            )

            heal_msg = (
                f"✅ _All {healed} of your Pokémon have been healed to full health!_\n"
                "_You're free to go._"
            ) if healed else "✨ _Your Pokémon are already at full health!_\n_You're free to go._"

            self._queue_message(sender, f"🏥 *Pokémon Care Center*\n━━━━━━━━━━━━━━━━\n{heal_msg}", delay=3)
            return None

        if cmd == ".switch":
            # Outside battle — swap two party slots: .switch 1 2
            if len(args) < 2 or not args[0].isdigit() or not args[1].isdigit():
                return "_Usage: .switch [slot] [slot]  (e.g. .switch 1 3)_"
            a, b = int(args[0]) - 1, int(args[1]) - 1
            if not (0 <= a < len(player.party)) or not (0 <= b < len(player.party)):
                return "⚠️ _Invalid slot number._"
            if a == b:
                return "⚠️ _That's the same slot._"
            player.party[a], player.party[b] = player.party[b], player.party[a]
            self._save(sender, player)
            na, nb = player.party[a].nickname, player.party[b].nickname
            return f"✅ Swapped *{na}* (slot {a+1}) and *{nb}* (slot {b+1})."

        if cmd == ".lab":
            if getattr(player, "zone", "oak_town") != "oak_town":
                return "_You are not in Oak Town._"
            player.zone   = "lab"
            player.zone_x = 20
            player.zone_y = 9
            if not player.get_flag("oak_intro_seen"):
                player.set_flag("oak_intro_seen")
                if player.story_stage == "new":
                    player.story_stage = "at_lab"
                self._save(sender, player)
                return oak_intro(player.name)
            self._save(sender, player)
            return (
                "🜔 *Pokélab*\n"
                "_The Professor is inside._\n\n"
                "_Type_ `talk oak` _to speak with him._"
            )

        if cmd == ".leave":
            if getattr(player, "zone", "") == "lab":
                player.zone   = "oak_town"
                player.zone_x = 20
                player.zone_y = 12
                self._save(sender, player)
                return "📍 _Back in Oak Town._"
            player.location = "square"
            self._save(sender, player)
            return UI.town_square(player) if hasattr(UI, "town_square") else "📍 _Oak Town._"



        if cmd == ".hud":
            if not args or args[0] not in ("1", "2", "3"):
                return "🎨 *HUD Styles*\n\n*.hud 1* — Full\n*.hud 2* — Header\n*.hud 3* — Plain"
            player.hud_style = int(args[0])
            self._save(sender, player)
            return f"✅ HUD style *{args[0]}*."

        if cmd == ".font":
            from interfaces import RPGFont
            if not args or args[0] not in ("0", "1", "2", "3", "4"):
                return RPGFont.show_fonts()
            msg = RPGFont.set_preset(player, args[0])
            self._save(sender, player)
            return msg

        if cmd == ".tutorial":
            player.stage = "tutorial"; player.tutorial_phase = 0; player.tutorial_done = False
            self._save(sender, player)
            from tutorial import phase_awakening
            return phase_awakening(player)

        # ── Setskill flow ─────────────────────────────────────
        if getattr(player, "story_stage", None) == "setskill":
            return self._handle_setskill_flow(sender, player, text.strip())

        # ── Caught Pokémon naming ─────────────────────────────
        if getattr(player, "story_stage", None) == "caught_naming":
            return self._handle_caught_naming(sender, player, cmd, text, args)

        if cmd == ".name":
            # Standalone: .name p1 [nickname]  or  .name pc1 [nickname]
            if getattr(player, "story_stage", None) != "caught_naming":
                if not args:
                    return "_Usage: .name p[slot] [nickname]  or  .name pc[slot] [nickname]_"
                slot_arg = args[0].lower()
                nick = " ".join(args[1:]).strip() if len(args) > 1 else ""
                if nick.startswith("[") and nick.endswith("]"):
                    nick = nick[1:-1].strip()
                in_box = slot_arg.startswith("pc")
                num_str = slot_arg[2:] if in_box else slot_arg[1:]
                if not num_str.isdigit():
                    return "_Usage: .name p[slot] [nickname]  or  .name pc[slot] [nickname]_"
                idx = int(num_str) - 1
                pool = player.box if in_box else player.party
                loc  = "PC" if in_box else "party"
                if idx < 0 or idx >= len(pool):
                    return f"⚠️ _No Pokémon in {loc} slot {int(num_str)}._"
                target = pool[idx]
                if not nick:
                    return f"_Current name: *{target.nickname}*. Usage: .name {slot_arg} [nickname]_"
                if len(nick) > 16:
                    return "_Nickname must be 16 characters or less._"
                old_nick = target.nickname
                target.nickname = nick.capitalize()
                self._save(sender, player)
                return f"✅ *{old_nick}* renamed to *{target.nickname}*."

        if cmd == ".setskill":
            if stage in (STATE_BATTLE, STATE_ENCOUNTER):
                return "_You cannot set skill nicknames during battle._"
            raw_arg = " ".join(args).strip().lower()
            # .setskill → show menu
            if not raw_arg:
                return (
                    "⚙️ *Skill Nicknames*\n\n"
                    "_.setskill [pokemon]_ — assign a nickname to a skill\n"
                    "_.setskill list_ — view all your skill nicknames\n"
                    "_.unsetskill [pokemon]_ — remove a nickname"
                )
            # .setskill list
            if raw_arg == "list":
                return self._setskill_list(player)
            # .setskill [pokemon] — start flow
            return self._setskill_start(sender, player, raw_arg, removing=False)

        if cmd == ".unsetskill":
            if stage in (STATE_BATTLE, STATE_ENCOUNTER):
                return "_You cannot do this during battle._"
            raw_arg = " ".join(args).strip().lower()
            if not raw_arg:
                return "_Usage: .unsetskill [pokemon]_"
            return self._setskill_start(sender, player, raw_arg, removing=True)

        # ── setskill flow state ────────────────────────────────
        if getattr(player, "story_stage", None) == "setskill":
            return self._handle_setskill_flow(sender, player, text.strip())

        if cmd == ".challenge":
            # ── .challenge ariel (special case — anywhere outside battle) ──
            if args and args[0].lower() == "ariel":
                if stage in (STATE_BATTLE, STATE_ARENA, STATE_ARENA_PENDING, STATE_GYM, STATE_GYM_PENDING, STATE_PVP, STATE_RAID, "battle_menu"):
                    return "_You're already in a battle. Finish it first._"
                from arena import ariel_prompt
                msg = ariel_prompt(self.db, sender, player, initiated_by_player=True)
                self._save(sender, player)
                return msg
            grp_pvp = getattr(self, "_last_group_jid", None)
            return self.handle_challenge(sender, player, mentioned_jid, args=args, group_jid=grp_pvp)

        # ── .dash ─────────────────────────────────────────────
        if cmd == ".dash":
            from map import load_zone, IMPASSABLE, ENCOUNTER_TILES, SAFE_ZONES
            if stage in (STATE_BATTLE, STATE_ENCOUNTER):
                return "_You can't dash during a battle._"
            if not args or len(args) < 2:
                return "_Usage: .dash [1/2/3/4] [steps]  e.g. .dash 2 10_"
            direction = args[0]
            if direction not in ("1", "2", "3", "4"):
                return "_Direction must be 1 (north) 2 (south) 3 (west) 4 (east)._"
            if not args[1].isdigit():
                return "_Steps must be a number._"
            steps = min(int(args[1]), 20)  # cap at 20
            if steps < 1:
                return "_Steps must be at least 1._"

            DELTA = {"1": (0, -1), "2": (0, 1), "3": (-1, 0), "4": (1, 0)}
            dc, dr = DELTA[direction]

            zone_id  = getattr(player, "zone", "oak_town")
            zone     = load_zone(zone_id)
            grid     = zone.get("grid", [])
            height   = zone.get("height", len(grid))
            width    = zone.get("width", len(grid[0]) if grid else 0)
            exits    = zone.get("exits", {})
            npcs     = zone.get("npcs", {})

            # NPC tile positions
            npc_tiles = set()
            for r, row in enumerate(grid):
                for c, t in enumerate(row):
                    if t == "NP":
                        npc_tiles.add((r, c))

            moved   = 0
            stopped = None
            encounter_triggered = False

            cx, cy = player.zone_x, player.zone_y

            for _ in range(steps):
                nx = cx + dc
                ny = cy + dr

                # Check EX — stop before it
                exit_key = f"{ny},{nx}"
                if exit_key in exits:
                    stopped = "zone exit ahead"
                    break

                # Out of bounds
                if not (0 <= nx < width and 0 <= ny < height):
                    stopped = "edge of zone"
                    break

                tile = grid[ny][nx] if grid else "TT"

                # Impassable — stop before
                if tile in IMPASSABLE:
                    stopped = "blocked"
                    break

                # NPC adjacent — stop one tile before
                if (ny, nx) in npc_tiles:
                    stopped = "NPC ahead"
                    break

                # Move accepted
                cx, cy = nx, ny
                moved += 1

                # Encounter roll on encounter tiles
                if tile in ENCOUNTER_TILES and zone_id not in SAFE_ZONES:
                    import random
                    from encounters import roll_wild_pokemon, build_wild_monster, encounter_screen
                    from pokeapi import get_full
                    grass_walked = player.get_flag("dash_grass_steps", 0) + 1
                    player.set_flag("dash_grass_steps", grass_walked)
                    # Guaranteed encounter after 5 grass tiles; otherwise 30% per tile
                    roll = random.random()
                    if roll < 0.30 or grass_walked >= 5:
                        player.set_flag("dash_grass_steps", 0)
                        result = roll_wild_pokemon(zone_id, "grass")
                        if result:
                            species, level = result
                            api_data = get_full(self.db, species)
                            if api_data:
                                monster = build_wild_monster(api_data, level)
                                player.zone_x = cx
                                player.zone_y = cy
                                player.see_pokemon(species)
                                session.set_encounter(monster, None)
                                self._save(sender, player)
                                dir_names = {"1":"north","2":"south","3":"west","4":"east"}
                                return (
                                    f"_Dashed {moved} step(s) {dir_names[direction]}..._\n\n"
                                    + encounter_screen(monster)
                                )

            player.zone_x = cx
            player.zone_y = cy
            self._save(sender, player)

            dir_names = {"1":"north","2":"south","3":"west","4":"east"}
            msg = f"_Dashed {moved} step(s) {dir_names[direction]}._"
            if stopped:
                msg += f"\n_{stopped.capitalize()}._"
            if moved == 0:
                msg = f"_Can't move that way._"
            return msg + "\n\n" + self._render_zone_map(sender, player)

        # ── .hunt ─────────────────────────────────────────────
        if cmd == ".hunt":
            import time
            from map import SAFE_ZONES
            zone_id = getattr(player, "zone", "oak_town")
            if zone_id in SAFE_ZONES:
                return "_You can't hunt in a town._\n_Use .quicktravel to change location._"
            if stage in (STATE_BATTLE, STATE_ENCOUNTER):
                return "_You're already in a battle._"
            # Cooldown check — 15 seconds
            last_hunt = player.get_flag("last_hunt", 0)
            now = time.time()
            remaining = 15 - (now - last_hunt)
            if remaining > 0:
                return f"_Hunt is on cooldown. ({int(remaining)}s remaining)_"
            # Lower encounter chance than walking — flat 8%
            import random
            from encounters import roll_wild_pokemon, build_wild_monster, encounter_screen
            from pokeapi import get_full
            if random.random() > 0.60:
                player.set_flag("last_hunt", now)
                self._save(sender, player)
                return "_You search the area but find nothing..._"
            result = roll_wild_pokemon(zone_id, "grass")
            if not result:
                player.set_flag("last_hunt", now)
                self._save(sender, player)
                return "_Nothing seems to be around._"
            species, level = result
            api_data = get_full(self.db, species)
            if not api_data:
                player.set_flag("last_hunt", now)
                self._save(sender, player)
                return "_Something stirred but slipped away._"
            monster = build_wild_monster(api_data, level)
            player.see_pokemon(species)
            player.set_flag("last_hunt", now)
            session.set_encounter(monster, None)
            self._save(sender, player)
            return encounter_screen(monster)

        # ── .quicktravel ──────────────────────────────────────
        if cmd == ".quicktravel":
            import time
            from map import load_zone, SAFE_ZONES
            if stage in (STATE_BATTLE, STATE_ENCOUNTER):
                return "_You can't travel during a battle._"
            # Cooldown check — 60 seconds
            last_qt = player.get_flag("last_quicktravel", 0)
            now = time.time()
            remaining = 60 - (now - last_qt)
            if remaining > 0:
                return f"_Quick Travel is on cooldown. ({int(remaining)}s remaining)_"
            visited = player.get_flag("visited_zones", [])
            current = getattr(player, "zone", "oak_town")
            # Remove current zone from options
            options = [z for z in visited if z != current]
            if not args:
                if not options:
                    return "_You haven't visited any other zones yet._\n_You need to reach an area manually to travel there._"
                lines = ["🗺️ *Quick Travel*", "_Where would you like to go?_", ""]
                for i, z in enumerate(options, 1):
                    zone_data = load_zone(z)
                    name = zone_data.get("name", z.replace("_", " ").title())
                    lines.append(f"  *{i}.* {name}")
                lines.append("")
                lines.append("_.quicktravel [number]_")
                return "\n".join(lines)
            # Handle selection
            sel = " ".join(args)  # rejoin so multi-word names work
            if sel.isdigit():
                idx = int(sel) - 1
                if idx < 0 or idx >= len(options):
                    return "⚠️ _Invalid selection._"
                dest = options[idx]
            else:
                sel_key = sel.lower().replace(" ", "_")
                # Match against zone id or display name, case-insensitive
                dest = None
                for z in options:
                    if z == sel_key:
                        dest = z; break
                if not dest:
                    for z in options:
                        zd = load_zone(z)
                        zname = zd.get("name", z.replace("_", " ")).lower()
                        if zname == sel.lower():
                            dest = z; break
                if not dest:
                    return f"⚠️ _You haven't visited '{sel}'._"
            zone_data = load_zone(dest)
            if not zone_data:
                return "⚠️ _Unknown zone._"
            # Get arrival position from ZONE_SPAWNS first, fallback to exit_positions
            from encounters import ZONE_SPAWNS
            if dest in ZONE_SPAWNS:
                spawn = ZONE_SPAWNS[dest]
            else:
                exit_positions = zone_data.get("exit_positions", {})
                spawn = list(exit_positions.values())[0] if exit_positions else zone_data.get("spawn", (0, 0))
            player.zone   = dest
            player.zone_x = spawn[0]
            player.zone_y = spawn[1]
            player.set_flag("last_quicktravel", now)
            self._save(sender, player)
            zone_name = zone_data.get("name", dest.replace("_", " ").title())
            safe = dest in SAFE_ZONES
            arrival = f"⚡ _Travelled to_ *{zone_name}*{'.' if safe else ' — stay alert.'}"
            minimap = self._render_zone_map(sender, player)
            return arrival + "\n\n" + minimap

        return None
    # ══════════════════════════════════════════════════════════
    # SETSKILL SYSTEM
    # Storage: story_flags["skill_nicknames"]
    #   { "species_nickname_key": { "skill_name": ["phrase1", "phrase2"] } }
    # Flow state: story_flags["setskill_flow"]
    #   { "step": 1|2|3, "poke_key": str, "skill_name": str|None, "removing": bool }
    # ══════════════════════════════════════════════════════════

    def _poke_key(self, poke) -> str:
        return f"{poke.name}_{poke.nickname.lower()}"

    def _all_poke_ordered(self, player):
        """Party first, then box."""
        return [(p, False) for p in player.party] + [(p, True) for p in player.box]

    def _find_poke(self, player, query: str):
        """Find a Pokémon by number or name (party first, then box)."""
        all_poke = self._all_poke_ordered(player)
        if query.isdigit():
            idx = int(query) - 1
            if 0 <= idx < len(all_poke):
                return all_poke[idx]
            return None, None
        for poke, in_box in all_poke:
            if poke.nickname.lower() == query or poke.name.lower() == query:
                return poke, in_box
        return None, None

    def _setskill_list(self, player) -> str:
        """Show all skill nicknames grouped by Pokémon."""
        db = player.get_flag("skill_nicknames", {})
        if not db:
            return "_You haven't set any skill nicknames yet._"
        lines = ["📋 *Skill Nicknames*", ""]
        for poke, in_box in self._all_poke_ordered(player):
            key = self._poke_key(poke)
            if key not in db:
                continue
            loc = "📦 PC" if in_box else ""
            lines.append(f"*{poke.nickname}* {loc}")
            for skill, phrases in db[key].items():
                skill_display = skill.replace("-", " ").title()
                for phrase in phrases:
                    lines.append(f'  _{skill_display}_ → "{phrase}"')
            lines.append("")
        if len(lines) == 2:
            return "_You haven't set any skill nicknames yet._"
        return "\n".join(lines).strip()

    def _setskill_start(self, sender, player, query: str, removing: bool) -> str:
        """Start the setskill/unsetskill flow for a given Pokémon query."""
        poke, in_box = self._find_poke(player, query)
        if poke is None:
            return f"_No Pokémon found for \"{query}\"._"
        key = self._poke_key(poke)
        # Build skill list — equipped then unequipped
        equipped = poke.moves  # list of {name, pp, max_pp}
        pool = getattr(poke, "move_pool", [])
        current_names = {m["name"] for m in equipped}
        unequipped = [m for m in pool if m not in current_names]

        lines = [f"⚙️ *{poke.nickname}'s Skills*", ""]
        lines.append("*Equipped:*")
        for i, m in enumerate(equipped):
            lines.append(f"  {i+1}. {m['name'].replace('-',' ').title()} ({m['pp']}/{m['max_pp']} PP)")
        if unequipped:
            lines.append("\n*Unequipped:*")
            for j, m in enumerate(unequipped):
                lines.append(f"  {len(equipped)+j+1}. {m.replace('-',' ').title()}")
        lines.append("")
        action = "remove a nickname from" if removing else "nickname"
        lines.append(f"_Reply with the number of the skill you want to {action}._")
        lines.append("_Any other message cancels._")

        # Store flow state
        player.set_flag("setskill_flow", {
            "step": 1,
            "poke_key": key,
            "skill_index_map": {
                str(i+1): m["name"] for i, m in enumerate(equipped)
            } | {
                str(len(equipped)+j+1): m for j, m in enumerate(unequipped)
            },
            "skill_name": None,
            "removing": removing,
        })
        player.story_stage = "setskill"
        self._save(sender, player)
        return "\n".join(lines)

    def _handle_setskill_flow(self, sender, player, text: str) -> str:
        flow = player.get_flag("setskill_flow", {})
        step = flow.get("step", 1)
        removing = flow.get("removing", False)

        def _cancel():
            player.story_stage = None
            player.set_flag("setskill_flow", {})
            self._save(sender, player)
            return "_Cancelled._"

        if step == 1:
            # Expecting a skill number
            if not text.strip().isdigit():
                return _cancel()
            idx_map = flow.get("skill_index_map", {})
            skill_name = idx_map.get(text.strip())
            if not skill_name:
                return _cancel()

            flow["step"] = 2
            flow["skill_name"] = skill_name
            player.set_flag("setskill_flow", flow)
            self._save(sender, player)

            skill_display = skill_name.replace("-", " ").title()
            db = player.get_flag("skill_nicknames", {})
            poke_key = flow["poke_key"]
            existing = db.get(poke_key, {}).get(skill_name, [])

            if removing:
                if not existing:
                    player.story_stage = None
                    player.set_flag("setskill_flow", {})
                    self._save(sender, player)
                    return f"_No nicknames set for {skill_display}._"
                lines = [f"⚙️ *Nicknames for {skill_display}:*", ""]
                for i, phrase in enumerate(existing):
                    lines.append(f"  {i+1}. \"{phrase}\"")
                lines.append("")
                lines.append("_Reply with the number to remove. Any other message cancels._")
                flow["step"] = 3
                flow["existing"] = existing
                player.set_flag("setskill_flow", flow)
                self._save(sender, player)
                return "\n".join(lines)
            else:
                hint = ""
                if existing:
                    hint = f"_Existing: {', '.join(chr(34)+p+chr(34) for p in existing)}_\n"
                return (
                    f"⚙️ *{skill_display}*\n\n"
                    f"{hint}"
                    f"_Reply with the phrase you want to use for this skill._\n"
                    f"_Must contain at least one letter. Any command cancels._"
                )

        if step == 2:
            # Expecting a phrase (setskill only)
            import re
            if not re.search(r"[a-zA-Z]", text):
                return _cancel()
            phrase = text.strip().lower()
            skill_name = flow["skill_name"]
            poke_key = flow["poke_key"]
            db = player.get_flag("skill_nicknames", {})
            if poke_key not in db:
                db[poke_key] = {}
            if skill_name not in db[poke_key]:
                db[poke_key][skill_name] = []
            if phrase not in db[poke_key][skill_name]:
                db[poke_key][skill_name].append(phrase)
            player.set_flag("skill_nicknames", db)
            player.story_stage = None
            player.set_flag("setskill_flow", {})
            self._save(sender, player)
            skill_display = skill_name.replace("-", " ").title()
            return f"✅ *\"{text.strip()}\"* → *{skill_display}*"

        if step == 3:
            # Expecting a number to remove (unsetskill only)
            if not text.strip().isdigit():
                return _cancel()
            existing = flow.get("existing", [])
            idx = int(text.strip()) - 1
            if idx < 0 or idx >= len(existing):
                return _cancel()
            removed = existing[idx]
            skill_name = flow["skill_name"]
            poke_key = flow["poke_key"]
            db = player.get_flag("skill_nicknames", {})
            if poke_key in db and skill_name in db[poke_key]:
                db[poke_key][skill_name] = [p for p in db[poke_key][skill_name] if p != removed]
                if not db[poke_key][skill_name]:
                    del db[poke_key][skill_name]
                if not db[poke_key]:
                    del db[poke_key]
            player.set_flag("skill_nicknames", db)
            player.story_stage = None
            player.set_flag("setskill_flow", {})
            self._save(sender, player)
            skill_display = skill_name.replace("-", " ").title()
            return f"✅ Removed *\"{removed}\"* from *{skill_display}*."

        return _cancel()

    def _handle_caught_naming(self, sender, player, cmd, text, args):
        """Handle .name / .skip after catching a Pokémon."""
        in_box = player.get_flag("caught_naming_box", False)
        slot   = player.get_flag("caught_naming_slot", 0)
        target = player.box[slot] if in_box else (player.party[slot] if slot < len(player.party) else None)

        if not target:
            player.story_stage = "route_1"
            self._save(sender, player)
            return None

        if cmd == ".skip":
            player.story_stage = "route_1"
            player.set_flag("caught_naming_slot", None)
            player.set_flag("caught_naming_box", False)
            self._save(sender, player)
            return f"_Kept the name *{target.nickname}*._"

        if cmd == ".name" or cmd.startswith(".name"):
            raw = text.strip()[5:].strip() if len(text.strip()) > 5 else ""
            if not raw and args:
                raw = " ".join(args)
            if raw.startswith("[") and raw.endswith("]"):
                raw = raw[1:-1].strip()
            if not raw:
                return "_Usage: .name [nickname] or .skip_"
            if len(raw) > 16:
                return "_Nickname must be 16 characters or less._"
            target.nickname = raw.capitalize()
            player.story_stage = "route_1"
            player.set_flag("caught_naming_slot", None)
            player.set_flag("caught_naming_box", False)
            self._save(sender, player)
            return f"✅ Your Pokémon has been named *{target.nickname}*!"

        return "_Would you like to name this Pokémon?\n*.name [nickname]*\n*.skip*_"




