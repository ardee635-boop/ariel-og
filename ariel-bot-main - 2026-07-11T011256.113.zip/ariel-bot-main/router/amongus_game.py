# ============================================================
# NIFLHEIM — router/amongus_game.py
# Core game engine for an in-progress Among Us match.
# ============================================================

import random
import threading
import time

from . import amongus_map as M

KILL_DELAY_SECONDS       = 4
KILL_COOLDOWN_SECONDS    = 25
LINGER_THRESHOLD_SECONDS = 15
FOLLOW_REVEAL_SECONDS    = 5
VENT_TRANSIT_SECONDS     = 2
MEETING_VOTE_SECONDS     = 60


class PlayerState:
    def __init__(self, jid, role):
        self.jid              = jid
        self.role             = role          # "crewmate" | "impostor"
        self.alive            = True
        self.room             = M.START_ROOM
        self.path             = None          # remaining rooms to visit
        self.hop_started_at   = None
        self.hop_duration     = None
        self.settled          = True
        self.room_entered_at  = time.time()
        self.tasks            = [
            {"room": room, "name": name, "duration": dur, "done": False}
            for room, (name, dur) in M.TASKS.items()
        ]
        self.task_in_progress = None
        self.kill_cooldown_until = 0.0
        self.in_vent_until    = None
        self.vent_dest        = None
        self.following        = None
        self.follow_started_at = None

    def real_progress_pct(self):
        done = sum(1 for t in self.tasks if t["done"] and self.role == "crewmate")
        return int(100 * done / len(self.tasks)) if self.tasks else 100


class Game:
    def __init__(self, manager, lobby):
        self.manager   = manager
        self.lobby     = lobby
        self.group_jid = lobby.group_jid
        self.over      = False
        self._meeting  = None
        self._meltdown = None
        self._bodies   = {}   # room -> [jid, ...]  (fixed: init here, not lazily)

        members = list(lobby.players)
        random.shuffle(members)
        from .amongus import _impostor_count
        impostor_jids = set(members[:_impostor_count(len(members))])

        self.players = {
            jid: PlayerState(jid, "impostor" if jid in impostor_jids else "crewmate")
            for jid in members
        }
        self._announce_roles()

    # ── Setup ──────────────────────────────────────────────
    def _announce_roles(self):
        impostors = [p for p in self.players.values() if p.role == "impostor"]
        imp_names = ", ".join(p.jid for p in impostors)
        for p in self.players.values():
            if p.role == "impostor":
                msg = (
                    "🔪 *You are the IMPOSTOR.*\n"
                    f"Fellow impostor(s): {imp_names if len(impostors) > 1 else 'none'}\n"
                    f"Starting room: *{M.START_ROOM.replace('_',' ').title()}*\n"
                    "Blend in, sabotage, eliminate."
                )
            else:
                msg = (
                    "👨‍🚀 *You are a CREWMATE.*\n"
                    f"Starting room: *{M.START_ROOM.replace('_',' ').title()}*\n"
                    "Finish your tasks or vote out the impostor(s)."
                )
            self.manager._push_dm(p.jid, msg)
        n_imp = len(impostors)
        self.manager._broadcast(
            f"🚀 *Game live!* {len(self.players)} players, {n_imp} impostor(s).\n"
            "Check your DM for your role."
        )

    # ── Dispatch ───────────────────────────────────────────
    def handle(self, sender, text):
        p = self.players.get(sender)
        if not p:
            return "⚠️ _You're not in this game._"
        if not p.alive:
            return self._handle_ghost(p, text)
        self._resolve_movement(p)

        parts = text.split()
        cmd   = parts[0].lower()
        arg   = " ".join(parts[1:]).strip()

        if cmd == ".m":         return self._cmd_move(p, arg)
        if cmd == ".where":     return self._cmd_where(p)
        if cmd == ".kill":      return self._cmd_kill(p, arg)
        if cmd == ".task":      return self._cmd_task(p, arg)
        if cmd == ".tasks":     return self._cmd_tasks_all(p)
        if cmd == ".players":   return self._cmd_players()
        if cmd == ".progress":  return self._cmd_progress(p)
        if cmd == ".vent":      return self._cmd_vent(p, arg)
        if cmd == ".follow":    return self._cmd_follow(p, arg)
        if cmd == ".report":    return self._cmd_report(p)
        if cmd == ".meeting":   return self._cmd_call_meeting(p, "emergency")
        if cmd == ".vote":      return self._cmd_vote(p, arg, public=False)
        if cmd == ".sabotage" and arg.lower() == "reactor":
            return self._cmd_sabotage(p)
        if cmd == ".cooldown":  return self._cmd_cooldown(p)
        return "❓ _Not a recognised in-game command. Try .amenu._"

    def handle_gc_vote(self, sender, text):
        p = self.players.get(sender)
        if not p or not p.alive:
            return None
        parts = text.split()
        if parts and parts[0].lower() == ".vote":
            return self._cmd_vote(p, " ".join(parts[1:]).strip(), public=True)
        return None

    def _handle_ghost(self, p, text):
        if text.strip().lower().startswith(".c "):
            msg = text.strip()[3:].strip()
            self.manager._push_ghost_chat(self, p.jid, msg)
            return None
        return "👻 _You're dead. Use .c <message> to talk to other ghosts._"

    # ── Movement ───────────────────────────────────────────
    def _resolve_movement(self, p):
        now = time.time()

        # Vent transit
        if p.in_vent_until is not None:
            if now >= p.in_vent_until:
                p.room = p.vent_dest
                p.in_vent_until = None
                p.vent_dest     = None
                p.settled       = True
                p.room_entered_at = now
                self._ping_room(p, p.room, stage="final")
            return

        if p.path is None:
            return

        if now >= p.hop_started_at + p.hop_duration:
            arrived = p.path.pop(0)
            p.room  = arrived
            p.room_entered_at = now

            if p.path:
                # Mid-transit stop
                next_room = p.path[0]
                p.hop_started_at = now
                p.hop_duration   = M.EDGES[arrived][next_room]
                p.settled        = False
                self._ping_room(p, arrived, stage="transit")
            else:
                # Final destination
                p.path    = None
                p.settled = True
                self._ping_room(p, arrived, stage="final")

    def _ping_room(self, mover, room, stage):
        """stage: 'final' | 'transit' | 'leave'"""
        room_display = room.replace("_", " ").title()

        if stage == "leave":
            msg_others = f"*{mover.jid}* has left *{room_display}*."
            for other in self.players.values():
                if other.jid != mover.jid and other.alive and other.settled and other.room == room:
                    self.manager._push_dm(other.jid, msg_others)
            return

        if stage == "final":
            msg_self   = f"✅ You have arrived at *{room_display}*."
            msg_others = f"*{mover.jid}* has arrived at *{room_display}*."
        else:  # transit
            msg_self   = f"🚶 You are passing through *{room_display}*."
            msg_others = f"*{mover.jid}* is passing through *{room_display}*."

        # Tell the mover
        self.manager._push_dm(mover.jid, msg_self)

        # Tell settled occupants + lingering check
        for other in self.players.values():
            if other.jid == mover.jid or not other.alive or not other.settled or other.room != room:
                continue
            self.manager._push_dm(other.jid, msg_others)
            if self._lingering_flag(other):
                self.manager._push_dm(
                    mover.jid,
                    f"👀 *{other.jid}* seems to be lingering in *{room_display}*."
                )

        # Body check on final arrival only
        if stage == "final":
            self._check_body_here(mover, room)

    def _cmd_move(self, p, dest_raw):
        if not dest_raw:
            lines = [f"{i+1}. {r.replace('_',' ').title()}" for i, r in enumerate(M.ROOMS)]
            return "*Rooms:*\n" + "\n".join(lines)

        # Number shortcut: .m 7 picks the 7th room from the list
        if dest_raw.strip().isdigit():
            idx = int(dest_raw.strip()) - 1
            if 0 <= idx < len(M.ROOMS):
                dest_raw = M.ROOMS[idx]
            else:
                return f"⚠️ _Pick a number between 1 and {len(M.ROOMS)}._"

        dest = dest_raw.strip().upper().replace(" ", "_")
        if dest not in M.EDGES:
            lines = [f"{i+1}. {r.replace('_',' ').title()}" for i, r in enumerate(M.ROOMS)]
            return "⚠️ _Unknown room._\n\n*Rooms:*\n" + "\n".join(lines)
        if p.path is not None or p.in_vent_until is not None:
            return "⚠️ _You're already moving._"
        if dest == p.room:
            return f"_You're already in {p.room.replace('_',' ').title()}._"

        path = M.shortest_path(p.room, dest)
        if not path or len(path) < 2:
            return "⚠️ _No route found._"

        hops       = M.path_hops(path)
        total_secs = sum(h[2] for h in hops)
        p.path            = path[1:]
        p.hop_started_at  = time.time()
        p.hop_duration    = M.EDGES[p.room][path[1]]
        p.settled         = False
        self._ping_room(p, p.room, stage="leave")
        return f"🚶 Heading to *{dest.replace('_',' ').title()}* (~{total_secs}s)."

    def _cmd_where(self, p):
        room = p.room.replace("_", " ").title()
        if p.settled:
            linger = ""
            elapsed = int(time.time() - p.room_entered_at)
            if elapsed >= LINGER_THRESHOLD_SECONDS:
                linger = " _(lingering)_"
            return f"📍 You are in *{room}*{linger}."
        elif p.path:
            dest = p.path[-1].replace("_", " ").title()
            remaining = max(0, int(p.hop_started_at + p.hop_duration - time.time()))
            return f"🚶 Passing through *{room}*, heading to *{dest}* (~{remaining}s to next hop)."
        elif p.in_vent_until:
            remaining = max(0, int(p.in_vent_until - time.time()))
            return f"🌀 In a vent (~{remaining}s)."
        return f"📍 You are in *{room}*."

    def _lingering_flag(self, p):
        return p.settled and (time.time() - p.room_entered_at) >= LINGER_THRESHOLD_SECONDS

    # ── Kill ───────────────────────────────────────────────
    def _cmd_kill(self, p, arg):
        if p.role != "impostor":
            return None
        if not p.settled:
            return "⚠️ _You're mid-move._"
        now = time.time()
        if now < p.kill_cooldown_until:
            return f"⏳ _Kill on cooldown ({int(p.kill_cooldown_until - now)}s left)._"

        occupants = [
            o for o in self.players.values()
            if o.alive and o.settled and o.room == p.room and o.jid != p.jid
        ]
        if not occupants:
            return None

        if arg:
            target = next((o for o in occupants if o.jid == arg.strip()), None)
            if not target:
                return "⚠️ _They're not here._"
            # Crowd: everyone else is a guaranteed witness
            crowd = [o for o in occupants if o.jid != target.jid]
        else:
            if len(occupants) > 1:
                return "⚠️ _Too crowded — use .kill <jid> to force it._"
            target = occupants[0]
            crowd  = []

        def _resolve():
            self._resolve_kill(p, target, crowd)

        threading.Timer(KILL_DELAY_SECONDS, _resolve).start()
        return None

    def _resolve_kill(self, killer, target, crowd):
        if not killer.alive or not target.alive:
            return
        if target.room != killer.room or not target.settled or not killer.settled:
            return  # one of them moved during the delay — whiff

        killer.kill_cooldown_until = time.time() + KILL_COOLDOWN_SECONDS
        target.alive = False
        setattr(target, "death_room", killer.room)
        self._bodies.setdefault(killer.room, []).append(target.jid)

        # Guaranteed crowd witnesses (named kill)
        for w in crowd:
            if w.alive:
                self.manager._push_dm(
                    w.jid,
                    f"😱 You saw *{killer.jid}* kill *{target.jid}*!"
                )

        # Chance witnesses — anyone else in the room right now
        for o in self.players.values():
            if o.jid in (killer.jid, target.jid) or o.jid in {w.jid for w in crowd}:
                continue
            if o.alive and o.settled and o.room == killer.room:
                self.manager._push_dm(
                    o.jid,
                    f"😱 You saw *{killer.jid}* kill *{target.jid}*!"
                )

        self.manager._push_dm(
            target.jid,
            f"💀 You were killed by *{killer.jid}*.\n"
            "You're a ghost now — *.c <message>* to talk to other ghosts."
        )
        self._resolve_win_check()

    def _check_body_here(self, mover, room):
        bodies = self._bodies.get(room)
        if bodies:
            self.manager._push_dm(
                mover.jid,
                f"⚠️ *{len(bodies)} body/bodies here.* Send *.report* to call it in."
            )

    # ── Tasks ──────────────────────────────────────────────
    def _cmd_task(self, p, arg):
        if not p.settled:
            return "⚠️ _Can't start a task mid-move._"
        room_tasks = [t for t in p.tasks if t["room"] == p.room and not t["done"]]
        if not arg:
            if not room_tasks:
                return "_Nothing to do here._"
            lines = [f"{i+1}. {t['name']} ({t['duration']}s)" for i, t in enumerate(room_tasks)]
            return "*Tasks here:*\n" + "\n".join(lines)
        try:
            task = room_tasks[int(arg) - 1]
        except (ValueError, IndexError):
            return "⚠️ _Invalid number._"

        def _finish():
            task["done"] = True
            if p.role == "impostor":
                self.manager._push_dm(p.jid, f"✅ *{task['name']}* logged.")
            else:
                self.manager._push_dm(p.jid, f"✅ *{task['name']}* complete.")
                self._resolve_win_check()

        threading.Timer(task["duration"], _finish).start()
        return f"🔧 Started *{task['name']}* ({task['duration']}s)..."

    def _cmd_progress(self, p):
        if p.role == "impostor":
            return f"*<[{random.randint(10, 90)}%]>*"
        crew = [pl for pl in self.players.values() if pl.role == "crewmate"]
        if not crew:
            return "*<[0%]>*"
        avg = sum(pl.real_progress_pct() for pl in crew) / len(crew)
        return f"*<[{int(avg)}%]>*"

    # ── Vent ───────────────────────────────────────────────
    def _cmd_vent(self, p, arg):
        if p.role != "impostor":
            return None
        if not p.settled:
            return "⚠️ _You're mid-move._"
        options = M.VENTS.get(p.room, [])
        if not options:
            return "_No vent here._"
        if not arg:
            lines = [f"{i+1}. {r.replace('_',' ').title()}" for i, r in enumerate(options)]
            return "*Vent destinations:*\n" + "\n".join(lines)
        try:
            dest = options[int(arg) - 1]
        except (ValueError, IndexError):
            return "⚠️ _Invalid option._"

        p.in_vent_until = time.time() + VENT_TRANSIT_SECONDS
        p.vent_dest     = dest
        p.settled       = False
        self._ping_room(p, p.room, stage="leave")
        return None

    # ── Follow ─────────────────────────────────────────────
    def _cmd_follow(self, p, arg):
        if not arg:
            return "_Usage: .follow <jid>_"
        target = self.players.get(arg.strip())
        if not target or not target.alive:
            return "⚠️ _Can't follow them._"
        seen = (target.room == p.room) or (time.time() - target.room_entered_at < 5)
        if not seen:
            return "⚠️ _You haven't seen them recently enough._"

        p.following        = target.jid
        p.follow_started_at = time.time()

        # Sync follower onto the same path as the target
        if target.path:
            p.path           = list(target.path)
            p.hop_started_at = target.hop_started_at
            p.hop_duration   = target.hop_duration
            p.settled        = False
            self._ping_room(p, p.room, stage="leave")

        def _reveal():
            # Stop follow if target died or vented since follow started
            if not target.alive or target.in_vent_until is not None:
                p.following = None
                return
            if p.following == target.jid:
                self.manager._push_dm(
                    target.jid,
                    f"👀 *{p.jid}* is following you."
                )
        threading.Timer(FOLLOW_REVEAL_SECONDS, _reveal).start()
        return f"_You are following {target.jid}._"

    def _cmd_tasks_all(self, p):
        """Show full personal task list across all rooms."""
        pending = [t for t in p.tasks if not t["done"]]
        done    = [t for t in p.tasks if t["done"]]
        if not pending:
            return "✅ _All your tasks are complete!_"
        lines = []
        for t in pending:
            lines.append(f"• {t['name']} — _{t['room'].replace('_',' ').title()}_")
        result = f"*Your tasks ({len(done)}/{len(p.tasks)} done):*\n" + "\n".join(lines)
        return result

    def _cmd_players(self):
        """Show who's still alive."""
        alive = [p for p in self.players.values() if p.alive]
        dead  = [p for p in self.players.values() if not p.alive]
        lines = [f"👨‍🚀 {p.jid}" for p in alive]
        lines += [f"~{p.jid}~" for p in dead]
        return f"*Players ({len(alive)} alive):*\n" + "\n".join(lines)

    # ── Report ─────────────────────────────────────────────
    def _cmd_report(self, p):
        bodies = self._bodies.get(p.room)
        if not bodies:
            # Also works mid-transit — interrupt travel
            if not p.settled and p.path:
                # Check the room they just entered mid-hop
                bodies = self._bodies.get(p.room)
        if not bodies:
            return "_No body here to report._"

        # Interrupt travel if mid-move
        if not p.settled:
            p.path           = None
            p.hop_started_at = None
            p.hop_duration   = None
            p.settled        = True

        victims = ", ".join(bodies)
        self._bodies.pop(p.room, None)
        self.manager._broadcast(
            f"📢 *{p.jid}* found a body.\n"
            f"*{victims}* has been murdered.\n\n"
            f"{self._roster_text()}"
        )
        self._cmd_call_meeting(p, "report")
        return None

    def _roster_text(self):
        lines = []
        for pl in self.players.values():
            lines.append(f"~{pl.jid}~" if not pl.alive else pl.jid)
        return "\n".join(lines)

    # ── Meeting / Voting ───────────────────────────────────
    def _cmd_call_meeting(self, caller, reason):
        if self._meeting:
            return "⚠️ _A meeting's already in progress._"
        self._meeting = {"votes": {}, "started_at": time.time()}
        self.manager._broadcast(
            f"🚨 *Meeting called* ({reason}) by {caller.jid}.\n"
            f"Discuss then *.vote <jid>* or *.vote skip* "
            f"(DM or GC) — {MEETING_VOTE_SECONDS}s."
        )
        # 10s countdown warning before voting closes
        warning_delay = max(0, MEETING_VOTE_SECONDS - 10)
        threading.Timer(
            warning_delay,
            lambda: self.manager._broadcast("⏰ *10 seconds left to vote!*") if self._meeting else None
        ).start()
        threading.Timer(MEETING_VOTE_SECONDS, self._resolve_meeting).start()
        return None

    def _cmd_vote(self, p, arg, public):
        if not self._meeting:
            return "⚠️ _No active meeting._"
        if not arg:
            return "_Usage: .vote <jid> or .vote skip_"
        choice = arg.strip()
        if choice.lower() != "skip" and choice not in self.players:
            return "⚠️ _Unknown player._"
        self._meeting["votes"][p.jid] = choice
        return None if public else "_Vote registered._"

    def _resolve_meeting(self):
        if not self._meeting:
            return
        meeting       = self._meeting
        self._meeting = None

        tally = {}
        for choice in meeting["votes"].values():
            if choice.lower() != "skip":
                tally[choice] = tally.get(choice, 0) + 1

        if not tally:
            self.manager._broadcast("🗳️ *No one ejected.* (all skipped / no votes)")
            return

        top     = max(tally.values())
        leaders = [jid for jid, c in tally.items() if c == top]
        if len(leaders) > 1:
            self.manager._broadcast("🗳️ *Tie — no one ejected.*")
            return

        ejected = self.players.get(leaders[0])
        if ejected:
            ejected.alive = False
            role_text = "an Impostor" if ejected.role == "impostor" else "not an Impostor"
            self.manager._broadcast(
                f"🗳️ *{ejected.jid} was ejected.* They were {role_text}.\n\n"
                f"{self._roster_text()}"
            )
        self._resolve_win_check()

    # ── Sabotage — Meltdown ────────────────────────────────
    def _cmd_sabotage(self, p):
        if p.role != "impostor":
            return None
        if self._meltdown:
            return "⚠️ _Meltdown already active._"
        self._meltdown = {
            "confirmed": set(),
            "deadline":  time.time() + M.MELTDOWN_DOOM_SECONDS,
        }
        rooms = " and ".join(r.replace("_", " ").title() for r in M.MELTDOWN_ROOMS)
        self.manager._broadcast(
            f"🚨🚨 *MELTDOWN!* Fix it at *{rooms}* within "
            f"{M.MELTDOWN_DOOM_SECONDS}s or the crew loses!"
        )
        threading.Timer(M.MELTDOWN_DOOM_SECONDS, self._check_meltdown_expired).start()
        return None

    def _cmd_cooldown(self, p):
        if not self._meltdown:
            return "⚠️ _Nothing active here._"
        if p.room not in M.MELTDOWN_ROOMS:
            return "⚠️ _Wrong room._"
        if p.room in self._meltdown["confirmed"]:
            return "_Already confirmed here._"

        def _confirm():
            if not self._meltdown:
                return
            self._meltdown["confirmed"].add(p.room)
            self.manager._push_dm(
                p.jid,
                f"✅ Confirmed at {p.room.replace('_',' ').title()}."
            )
            if set(M.MELTDOWN_ROOMS) <= self._meltdown["confirmed"]:
                self._meltdown = None
                self.manager._broadcast("✅ *Meltdown averted.*")

        threading.Timer(M.COOLDOWN_ACTION_SECONDS, _confirm).start()
        return f"⏳ Confirming... ({M.COOLDOWN_ACTION_SECONDS}s)"

    def _check_meltdown_expired(self):
        # Guard: if game already ended (e.g. last impostor ejected mid-meltdown), do nothing
        if self.over:
            self._meltdown = None
            return
        if not self._meltdown:
            return
        if set(M.MELTDOWN_ROOMS) <= self._meltdown["confirmed"]:
            return
        self._meltdown = None
        self.over = True
        self.manager._broadcast("💥 *Meltdown!* Crewmates lose.")

    # ── Win check ──────────────────────────────────────────
    def _resolve_win_check(self):
        if self.over:
            return
        alive        = [p for p in self.players.values() if p.alive]
        alive_imp    = [p for p in alive if p.role == "impostor"]
        alive_crew   = [p for p in alive if p.role == "crewmate"]
        tasks_done   = alive_crew and all(p.real_progress_pct() >= 100 for p in alive_crew)

        if not alive_imp:
            self.over = True
            self.manager._broadcast("🎉 *Crewmates win!* All impostors ejected.")
        elif len(alive_imp) >= len(alive_crew):
            self.over = True
            self.manager._broadcast("🔪 *Impostors win!* They equal or outnumber the crew.")
        elif tasks_done:
            self.over = True
            self.manager._broadcast("🎉 *Crewmates win!* All tasks complete.")
