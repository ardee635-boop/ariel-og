// ============================================================
// ARIEL — commands.js
// Bot-level commands — independent of game state
// Group management · Ranks · Welcome/Leave · Warnings
// ============================================================
//
// TABLES (auto-created on first run):
//   bot_ranks      — global royalty, lords, barons
//   group_settings — per-group welcome/leave/rules
//   warnings       — per-group user warning counts
//
// HIERARCHY (highest → lowest):
//   Royalty  → King (1), Queen (many), Prince/Princess/Duke/Duchess
//   Lords    → appointed by King/Queen
//   Admin    → WhatsApp group admins
//   Baron    → earned in-game (same level as Admin)
//   Player   → registered, game access only
//   Guest    → in group, hasn't typed .start
//
// RANK LEVELS (numeric for comparison):
//   King=100  Queen=90  Prince/Princess/Duke/Duchess=80
//   Lord=70   Admin/Baron=50  Player=10  Guest=0
// ============================================================

// ── Rank level map ────────────────────────────────────────────
const RANK_LEVEL = {
    'king':     100,
    'queen':    90,
    'prince':   80,
    'princess': 80,
    'duke':     80,
    'duchess':  80,
    'lord':     70,
    'jester':   70,
    'baron':    50,
    'player':   10,
    'guest':    0,
};

// Titles that are Royalty tier
const ROYALTY_TITLES = new Set(['king', 'queen', 'prince', 'princess', 'duke', 'duchess']);

// Valid .crown titles (king cannot be crowned, only set at deploy)
const CROWNBLE_TITLES = ['lord', 'jester', 'queen', 'prince', 'princess', 'duke', 'duchess'];

// The one true King
const KING_NUMBER = process.env.KING_NUMBER || '2348101845905';
const KING_JID    = `${KING_NUMBER}@s.whatsapp.net`;

// ── Default messages ──────────────────────────────────────────
const DEFAULT_WELCOME = `👋 Welcome to {group}, {name}! Type *.start* to begin your journey in Niflheim.`;
const DEFAULT_LEAVE   = `🚪 *{name}* has left {group}. Safe travels.`;
const DEFAULT_RULES   = `📜 *Group Rules*\n\n1. Be respectful\n2. No spam\n3. Have fun\n\n_Type *.start* to join the game._`;

const MAX_WARNINGS = 5;


// ============================================================
// DATABASE SETUP
// ============================================================

export async function setupCommandsTables(db) {
    await db.query(`
        CREATE TABLE IF NOT EXISTS bot_ranks (
            jid         TEXT PRIMARY KEY,
            phone       TEXT,
            lid         TEXT,
            rank        TEXT NOT NULL,
            granted_by  TEXT,
            granted_at  TIMESTAMPTZ DEFAULT NOW()
        )
    `);
    // Add columns if table already exists (safe migration)
    await db.query('ALTER TABLE bot_ranks ADD COLUMN IF NOT EXISTS phone TEXT');
    await db.query('ALTER TABLE bot_ranks ADD COLUMN IF NOT EXISTS lid TEXT');

    await db.query(`
        CREATE TABLE IF NOT EXISTS group_settings (
            group_jid   TEXT PRIMARY KEY,
            welcome_msg TEXT,
            leave_msg   TEXT,
            rules       TEXT,
            updated_at  TIMESTAMPTZ DEFAULT NOW()
        )
    `);
    // NULL prefix means "use the default '.'"
    await db.query('ALTER TABLE group_settings ADD COLUMN IF NOT EXISTS prefix TEXT');

    await db.query(`
        CREATE TABLE IF NOT EXISTS warnings (
            group_jid   TEXT,
            user_jid    TEXT,
            count       INTEGER DEFAULT 0,
            warned_by   TEXT,
            updated_at  TIMESTAMPTZ DEFAULT NOW(),
            PRIMARY KEY (group_jid, user_jid)
        )
    `);

    // Seed the King if not present
    await db.query(`
        INSERT INTO bot_ranks (jid, phone, rank, granted_by)
        VALUES ($1, $1, 'king', 'system')
        ON CONFLICT (jid) DO NOTHING
    `, [KING_JID]);
}


// ============================================================
// RANK HELPERS
// ============================================================

// Get rank for a JID. Checks DB first, then WA admin list.
export async function getRank(db, jid, groupParticipants = [], isRegistered = false) {
    // Always return king for the king
    if (jid === KING_JID || jid.startsWith(KING_NUMBER + '@')) return 'king';

    try {
        // Check by jid, phone, or lid — whichever matches
        const res = await db.query(
            'SELECT rank FROM bot_ranks WHERE jid = $1 OR phone = $1 OR lid = $1', [jid]
        );
        if (res.rows.length) return res.rows[0].rank.toLowerCase();
    } catch {}

    // Check if WA group admin (covers pre-existing admins, not just bot-promoted ones)
    const participant = groupParticipants.find(p => p.id === jid);
    if (participant?.admin === 'admin' || participant?.admin === 'superadmin') {
        return 'baron'; // WA admins are baron-tier
    }

    // Registered players outrank guests
    if (isRegistered) return 'player';

    return 'guest';
}

export function getRankLevel(rank) {
    return RANK_LEVEL[rank?.toLowerCase()] ?? 0;
}

// Can actor perform an action on target?
// Returns { allowed: bool, reason: string }
export function canActOn(actorRank, targetRank) {
    const actorLevel  = getRankLevel(actorRank);
    const targetLevel = getRankLevel(targetRank);

    if (targetRank === 'king') {
        return { allowed: false, reason: `👑 _The King is untouchable._` };
    }
    if (targetRank === 'queen' && actorRank !== 'king') {
        return { allowed: false, reason: `👑 _Only the King may act upon a Queen._` };
    }
    if (actorLevel <= targetLevel) {
        return {
            allowed: false,
            reason: targetLevel >= RANK_LEVEL['prince']
                ? `🛡️ _You dare raise a hand against Royalty of Niflheim?_`
                : `⚔️ _You cannot act on someone of equal or higher rank._`
        };
    }
    return { allowed: true, reason: null };
}

// Format rank for display
export function rankBadge(rank) {
    const badges = {
        king:     '👑 King',
        queen:    '👑 Queen',
        prince:   '🤴 Prince',
        princess: '👸 Princess',
        duke:     '🎖️ Duke',
        duchess:  '🎖️ Duchess',
        lord:     '⚔️ Lord',
        jester:   '🃏 Jester',
        baron:    '🏅 Baron',
        player:   '🧭 Player',
        guest:    '👤 Guest',
    };
    return badges[rank?.toLowerCase()] || '👤 Guest';
}


// ============================================================
// COMMAND HANDLER
// Entry point — call this from index.js handleMessage()
// Returns response string or null (not a bot command)
// ============================================================

export async function handleBotCommand(ctx) {
    const { sock, db, msg, chatJid, senderJid, text, mentionedJid, groupParticipants, isRegistered } = ctx;

    const lower = text.trim().toLowerCase();
    const parts = text.trim().split(/\s+/);
    const cmd   = parts[0].toLowerCase();
    const args  = parts.slice(1);

    // Resolve ranks
    const senderRank = await getRank(db, senderJid, groupParticipants, isRegistered);
    const senderLevel = getRankLevel(senderRank);

    // ── .crown [title] @user ─────────────────────────────────
    if (cmd === '.crown') {
        return _cmdCrown(ctx, senderRank, senderLevel, args, mentionedJid);
    }

    // ── .dethrone @user ──────────────────────────────────────
    if (cmd === '.dethrone') {
        return _cmdDethrone(ctx, senderRank, senderLevel, mentionedJid);
    }

    // ── .promote @user ───────────────────────────────────────
    if (cmd === '.promote') {
        return _cmdPromote(ctx, senderRank, senderLevel, mentionedJid);
    }

    // ── .demote @user ────────────────────────────────────────
    if (cmd === '.demote') {
        return _cmdDemote(ctx, senderRank, senderLevel, mentionedJid);
    }

    // ── .warn @user ──────────────────────────────────────────
    if (cmd === '.warn') {
        return _cmdWarn(ctx, senderRank, senderLevel, mentionedJid);
    }

    // ── .warnings @user ──────────────────────────────────────
    if (cmd === '.warnings') {
        return _cmdWarnings(ctx, senderLevel, mentionedJid);
    }

    // ── .clearwarns @user ────────────────────────────────────
    if (cmd === '.clearwarns') {
        return _cmdClearWarns(ctx, senderRank, senderLevel, mentionedJid);
    }

    // ── .kick @user ──────────────────────────────────────────
    if (cmd === '.kick') {
        return _cmdKick(ctx, senderRank, senderLevel, mentionedJid);
    }

    // ── .mute @user ──────────────────────────────────────────
    if (cmd === '.mute') {
        return _cmdMute(ctx, senderRank, senderLevel, mentionedJid, args);
    }

    // ── .unmute @user ────────────────────────────────────────
    if (cmd === '.unmute') {
        return _cmdUnmute(ctx, senderRank, senderLevel, mentionedJid);
    }

    // ── .tagall [message] ────────────────────────────────────
    if (cmd === '.tagall') {
        return _cmdTagAll(ctx, senderLevel, args);
    }

    // ── .setwelcome [message] / .setwelcome (reset) ──────────
    if (cmd === '.setwelcome') {
        return _cmdSetWelcome(ctx, senderLevel, args);
    }

    // ── .setleave [message] / .setleave (reset) ──────────────
    if (cmd === '.setleave') {
        return _cmdSetLeave(ctx, senderLevel, args);
    }

    // ── .setrules [message] (Lord+ only) ─────────────────────
    if (cmd === '.setrules') {
        return _cmdSetRules(ctx, senderRank, senderLevel, args);
    }

    // ── .setprefix <symbol> / .setprefix . (reset) / .setprefix (show current)
    if (cmd === '.setprefix') {
        return _cmdSetPrefix(ctx, senderLevel, args);
    }

    // ── .rules ───────────────────────────────────────────────
    if (cmd === '.rules') {
        return _cmdRules(ctx);
    }

    // ── .pin [message] ───────────────────────────────────────
    if (cmd === '.pin') {
        return _cmdPin(ctx, senderLevel, args);
    }

    // ── .invite ──────────────────────────────────────────────
    if (cmd === '.invite') {
        return _cmdInvite(ctx);
    }

    // ── .menu ────────────────────────────────────────────────
    if (cmd === '.menu') {
        return _cmdMenu();
    }

    // ── .pmenu ───────────────────────────────────────────────
    if (cmd === '.pmenu') {
        return _cmdPmenu(ctx);
    }

    // ── .ranks ───────────────────────────────────────────────
    if (cmd === '.ranks') {
        return _cmdRanks(ctx);
    }

    // ── .whois @user ─────────────────────────────────────────
    if (cmd === '.whois') {
        return _cmdWhois(ctx, mentionedJid);
    }

    // ── .spawn [name] [zone] ──────────────────────────────────
    if (cmd === '.spawn') {
        return _cmdSpawn(ctx, senderRank, senderLevel, args);
    }

    // ── .spawnp [name] ───────────────────────────────────────
    if (cmd === '.spawnp') {
        return _cmdSpawnP(ctx, senderRank, senderLevel, args);
    }

    return null; // not a bot command — fall through to game layer
}


// ============================================================
// WELCOME / LEAVE EVENTS
// Call these from sock.ev.on('group-participants.update')
// ============================================================

export async function onMemberJoin(ctx, joinedJid) {
    // Normalize — Baileys may pass an object
    if (typeof joinedJid === 'object') joinedJid = joinedJid.id || joinedJid.jid || String(joinedJid);
    const { sock, db, chatJid, groupParticipants } = ctx;
    const settings = await _getGroupSettings(db, chatJid);
    const template = settings?.welcome_msg || DEFAULT_WELCOME;

    let groupName = 'the group';
    try {
        const meta = await sock.groupMetadata(chatJid);
        groupName  = meta.subject || groupName;
    } catch {}

    const num     = joinedJid.split('@')[0];
    const message = template
        .replace(/{name}/g,  `@${num}`)
        .replace(/{group}/g, groupName)
        .replace(/{number}/g, num);

    try {
        await sock.sendMessage(chatJid, {
            text:     message,
            mentions: [joinedJid],
        });
    } catch {}
}

export async function onMemberLeave(ctx, leftJid) {
    // Normalize — Baileys may pass an object
    if (typeof leftJid === 'object') leftJid = leftJid.id || leftJid.jid || String(leftJid);
    const { sock, db, chatJid } = ctx;
    const settings = await _getGroupSettings(db, chatJid);
    const template = settings?.leave_msg || DEFAULT_LEAVE;

    let groupName = 'the group';
    try {
        const meta = await sock.groupMetadata(chatJid);
        groupName  = meta.subject || groupName;
    } catch {}

    const num     = leftJid.split('@')[0];
    const message = template
        .replace(/{name}/g,  `@${num}`)
        .replace(/{group}/g, groupName)
        .replace(/{number}/g, num);

    try {
        await sock.sendMessage(chatJid, { text: message });
    } catch {}
}


// ============================================================
// COMMAND IMPLEMENTATIONS
// ============================================================

async function _cmdCrown(ctx, senderRank, senderLevel, args, mentionedJid) {
    const { db } = ctx;

    // Only King and Queen can crown
    if (senderLevel < RANK_LEVEL['queen']) {
        return `👑 _Only Royalty may crown others._`;
    }

    const title = args[0]?.toLowerCase();
    if (!title || !CROWNBLE_TITLES.includes(title)) {
        return (
            `👑 *.crown [title] @user*\n\n` +
            `Valid titles:\n` +
            CROWNBLE_TITLES.map(t => `• ${t}`).join('\n')
        );
    }

    if (!mentionedJid) return `⚠️ _Tag someone to crown. Example: *.crown queen @user*_`;

    // Queens cannot crown other Queens (only King can)
    if (title === 'queen' && senderRank !== 'king') {
        return `👑 _Only the King may crown a Queen._`;
    }

    const targetRank = await getRank(db, mentionedJid);
    if (targetRank === 'king') return `👑 _The King is untouchable._`;

    const num = mentionedJid.split('@')[0];

    await db.query(`
        INSERT INTO bot_ranks (jid, rank, granted_by, granted_at)
        VALUES ($1, $2, $3, NOW())
        ON CONFLICT (jid) DO UPDATE
        SET rank = $2, granted_by = $3, granted_at = NOW()
    `, [mentionedJid, title, ctx.senderJid]);

    const badge = rankBadge(title);
    return `${badge} *@${num}* has been crowned *${title.charAt(0).toUpperCase() + title.slice(1)}* of Niflheim. 👑`;
}

async function _cmdDethrone(ctx, senderRank, senderLevel, mentionedJid) {
    const { db } = ctx;

    if (senderLevel < RANK_LEVEL['queen']) {
        return `👑 _Only Royalty may dethrone others._`;
    }
    if (!mentionedJid) return `⚠️ _Tag someone to dethrone._`;

    const targetRank = await getRank(db, mentionedJid);
    const check      = canActOn(senderRank, targetRank);
    if (!check.allowed) return check.reason;

    await db.query('DELETE FROM bot_ranks WHERE jid = $1', [mentionedJid]);

    const num = mentionedJid.split('@')[0];
    return `⚔️ *@${num}* has been dethroned.`;
}

async function _cmdPromote(ctx, senderRank, senderLevel, mentionedJid) {
    const { sock, db, chatJid, msg } = ctx;

    // Lords+ can promote
    if (senderLevel < RANK_LEVEL['lord']) {
        return `⚠️ _You don't have permission to promote._`;
    }
    if (!mentionedJid) return `⚠️ _Tag someone to promote._`;

    const targetRank = await getRank(db, mentionedJid, ctx.groupParticipants);
    const check      = canActOn(senderRank, targetRank);
    if (!check.allowed) return check.reason;

    try {
        await sock.groupParticipantsUpdate(chatJid, [mentionedJid], 'promote');
        const num = mentionedJid.split('@')[0];
        return `🛡️ *@${num}* has been promoted to group admin.`;
    } catch (e) {
        return `⚠️ _Could not promote — make sure Ariel is a group admin._`;
    }
}

async function _cmdDemote(ctx, senderRank, senderLevel, mentionedJid) {
    const { sock, db, chatJid } = ctx;

    if (senderLevel < RANK_LEVEL['admin']) {
        return `⚠️ _You don't have permission to demote._`;
    }
    if (!mentionedJid) return `⚠️ _Tag someone to demote._`;

    const targetRank = await getRank(db, mentionedJid, ctx.groupParticipants);
    const check      = canActOn(senderRank, targetRank);
    if (!check.allowed) return check.reason;

    try {
        await sock.groupParticipantsUpdate(chatJid, [mentionedJid], 'demote');
        const num = mentionedJid.split('@')[0];
        return `📉 *@${num}* has been demoted.`;
    } catch (e) {
        return `⚠️ _Could not demote — make sure Ariel is a group admin._`;
    }
}

async function _cmdWarn(ctx, senderRank, senderLevel, mentionedJid) {
    const { sock, db, chatJid, msg } = ctx;

    // Baron+ can warn
    if (senderLevel < RANK_LEVEL['baron']) {
        return `⚠️ _You don't have permission to warn._`;
    }
    if (!mentionedJid) return `⚠️ _Tag someone to warn._`;

    const targetRank = await getRank(db, mentionedJid, ctx.groupParticipants);
    const check      = canActOn(senderRank, targetRank);
    if (!check.allowed) return check.reason;

    // Upsert warning
    const res = await db.query(`
        INSERT INTO warnings (group_jid, user_jid, count, warned_by, updated_at)
        VALUES ($1, $2, 1, $3, NOW())
        ON CONFLICT (group_jid, user_jid) DO UPDATE
        SET count     = warnings.count + 1,
            warned_by = $3,
            updated_at = NOW()
        RETURNING count
    `, [chatJid, mentionedJid, ctx.senderJid]);

    const count = res.rows[0].count;
    const num   = mentionedJid.split('@')[0];

    if (count >= MAX_WARNINGS) {
        // Auto-kick
        try {
            await sock.groupParticipantsUpdate(chatJid, [mentionedJid], 'remove');
        } catch {}
        // Reset warnings after kick
        await db.query(
            'DELETE FROM warnings WHERE group_jid = $1 AND user_jid = $2',
            [chatJid, mentionedJid]
        );
        return (
            `⚠️ *@${num}* — Warning ${count}/${MAX_WARNINGS}\n\n` +
            `🚨 *Maximum warnings reached. @${num} has been removed from the group.*`
        );
    }

    const bars    = '🔴'.repeat(count) + '⚫'.repeat(MAX_WARNINGS - count);
    return (
        `⚠️ *@${num}* has been warned.\n\n` +
        `${bars}\n` +
        `*${count}/${MAX_WARNINGS}* warnings\n\n` +
        `_${MAX_WARNINGS - count} more warning(s) will result in removal._`
    );
}

async function _cmdWarnings(ctx, senderLevel, mentionedJid) {
    const { db, chatJid } = ctx;

    // Anyone can check warnings
    const targetJid = mentionedJid || ctx.senderJid;
    const num       = targetJid.split('@')[0];

    const res = await db.query(
        'SELECT count FROM warnings WHERE group_jid = $1 AND user_jid = $2',
        [chatJid, targetJid]
    );

    const count = res.rows[0]?.count || 0;
    const bars  = '🔴'.repeat(count) + '⚫'.repeat(MAX_WARNINGS - count);

    return (
        `📋 *Warnings — @${num}*\n\n` +
        `${bars}\n` +
        `*${count}/${MAX_WARNINGS}*`
    );
}

async function _cmdClearWarns(ctx, senderRank, senderLevel, mentionedJid) {
    const { db, chatJid } = ctx;

    if (senderLevel < RANK_LEVEL['baron']) {
        return `⚠️ _You don't have permission to clear warnings._`;
    }
    if (!mentionedJid) return `⚠️ _Tag someone to clear warnings for._`;

    const targetRank = await getRank(db, mentionedJid, ctx.groupParticipants);
    const check      = canActOn(senderRank, targetRank);
    if (!check.allowed) return check.reason;

    await db.query(
        'DELETE FROM warnings WHERE group_jid = $1 AND user_jid = $2',
        [chatJid, mentionedJid]
    );

    const num = mentionedJid.split('@')[0];
    return `✅ _Warnings cleared for @${num}._`;
}

async function _cmdKick(ctx, senderRank, senderLevel, mentionedJid) {
    const { sock, db, chatJid } = ctx;

    if (senderLevel < RANK_LEVEL['baron']) {
        return `⚠️ _You don't have permission to kick._`;
    }
    if (!mentionedJid) return `⚠️ _Tag someone to kick._`;

    const targetRank = await getRank(db, mentionedJid, ctx.groupParticipants);
    const check      = canActOn(senderRank, targetRank);
    if (!check.allowed) return check.reason;

    try {
        await sock.groupParticipantsUpdate(chatJid, [mentionedJid], 'remove');
        const num = mentionedJid.split('@')[0];
        return `🚪 *@${num}* has been removed from the group.`;
    } catch (e) {
        return `⚠️ _Could not kick — make sure Ariel is a group admin._`;
    }
}

async function _cmdMute(ctx, senderRank, senderLevel, mentionedJid, args) {
    const { db, chatJid } = ctx;

    if (senderLevel < RANK_LEVEL['baron']) {
        return `⚠️ _You don't have permission to mute._`;
    }
    if (!mentionedJid) return `⚠️ _Tag someone to mute._`;

    const targetRank = await getRank(db, mentionedJid, ctx.groupParticipants);
    const check      = canActOn(senderRank, targetRank);
    if (!check.allowed) return check.reason;

    // Store mute in group_settings as a simple set
    // Full mute enforcement (ignoring messages) handled in index.js
    await db.query(`
        INSERT INTO warnings (group_jid, user_jid, count, warned_by, updated_at)
        VALUES ($1, $2, -1, $3, NOW())
        ON CONFLICT (group_jid, user_jid) DO UPDATE
        SET warned_by  = $3,
            updated_at = NOW()
    `, [chatJid, mentionedJid, ctx.senderJid]);

    // Store muted flag separately
    await db.query(`
        INSERT INTO group_settings (group_jid, welcome_msg, leave_msg, rules, updated_at)
        VALUES ($1, NULL, NULL, NULL, NOW())
        ON CONFLICT (group_jid) DO NOTHING
    `, [chatJid]);

    const num = mentionedJid.split('@')[0];
    return `🔇 *@${num}* has been muted. Their messages will be ignored.`;
}

async function _cmdUnmute(ctx, senderRank, senderLevel, mentionedJid) {
    const { db, chatJid } = ctx;

    if (senderLevel < RANK_LEVEL['baron']) {
        return `⚠️ _You don't have permission to unmute._`;
    }
    if (!mentionedJid) return `⚠️ _Tag someone to unmute._`;

    const targetRank = await getRank(db, mentionedJid, ctx.groupParticipants);
    const check      = canActOn(senderRank, targetRank);
    if (!check.allowed) return check.reason;

    const num = mentionedJid.split('@')[0];
    return `🔊 *@${num}* has been unmuted.`;
}

async function _cmdTagAll(ctx, senderLevel, args) {
    const { sock, chatJid, msg } = ctx;

    if (senderLevel < RANK_LEVEL['lord']) {
        return `⚠️ _Only Lords and above can use .tagall._`;
    }

    const message = args.join(' ').trim() || '📢 Attention!';

    try {
        const meta    = await sock.groupMetadata(chatJid);
        const members = meta.participants.map(p => p.id);
        const tags    = members.map(id => `@${id.split('@')[0]}`).join(' ');
        await sock.sendMessage(chatJid, {
            text:     `📢 *${message}*\n\n${tags}`,
            mentions: members,
        });
        return null; // already sent
    } catch (e) {
        return `⚠️ _Could not tag all — ${e.message}_`;
    }
}

async function _cmdSetPrefix(ctx, senderLevel, args) {
    const { db, chatJid, groupPrefixCache } = ctx;

    if (senderLevel < RANK_LEVEL['king']) {
        return `👑 _Only the King can change the command prefix._`;
    }

    const newPrefix = args[0];

    if (!newPrefix) {
        const res = await db.query('SELECT prefix FROM group_settings WHERE group_jid = $1', [chatJid]);
        const current = res.rows[0]?.prefix || '.';
        return `_Current prefix: \`${current}\`_\n_Usage: .setprefix <symbol>_ — e.g. \`!\`, \`-\`, \`?\`\n_Use_ \`${current}setprefix .\` _to reset to default._`;
    }

    if (/\s/.test(newPrefix) || newPrefix.length > 3) {
        return `⚠️ _Prefix must be 1-3 characters, no spaces._`;
    }

    // Storing NULL means "use the default '.'" — keeps group_settings clean
    // and matches the convention the other .set* resets already use.
    const stored = newPrefix === '.' ? null : newPrefix;

    await db.query(`
        INSERT INTO group_settings (group_jid, prefix, updated_at)
        VALUES ($1, $2, NOW())
        ON CONFLICT (group_jid) DO UPDATE
        SET prefix = $2, updated_at = NOW()
    `, [chatJid, stored]);

    delete groupPrefixCache?.[chatJid];

    if (!stored) {
        return `✅ _Prefix reset to default:_ \`-\``;
    }
    return (
        `✅ *Prefix changed to:* \`${newPrefix}\`\n` +
        `_Commands now start with_ \`${newPrefix}\` _instead of_ \`-\`. ` +
        `_Example:_ \`${newPrefix}menu\``
    );
}

async function _cmdSetWelcome(ctx, senderLevel, args) {
    const { db, chatJid } = ctx;

    if (senderLevel < RANK_LEVEL['lord']) {
        return `⚠️ _Only Lords and above can set welcome messages._`;
    }

    const message = args.join(' ').trim();

    if (!message) {
        // Reset to default
        await db.query(`
            INSERT INTO group_settings (group_jid, welcome_msg, updated_at)
            VALUES ($1, NULL, NOW())
            ON CONFLICT (group_jid) DO UPDATE
            SET welcome_msg = NULL, updated_at = NOW()
        `, [chatJid]);
        return `✅ _Welcome message reset to default._\n\n_Default:_ ${DEFAULT_WELCOME}`;
    }

    await db.query(`
        INSERT INTO group_settings (group_jid, welcome_msg, updated_at)
        VALUES ($1, $2, NOW())
        ON CONFLICT (group_jid) DO UPDATE
        SET welcome_msg = $2, updated_at = NOW()
    `, [chatJid, message]);

    return (
        `✅ *Welcome message set!*\n\n` +
        `_Preview:_\n${_previewTemplate(message)}\n\n` +
        `_Variables: {name} {group} {number}_`
    );
}

async function _cmdSetLeave(ctx, senderLevel, args) {
    const { db, chatJid } = ctx;

    if (senderLevel < RANK_LEVEL['lord']) {
        return `⚠️ _Only Lords and above can set leave messages._`;
    }

    const message = args.join(' ').trim();

    if (!message) {
        await db.query(`
            INSERT INTO group_settings (group_jid, leave_msg, updated_at)
            VALUES ($1, NULL, NOW())
            ON CONFLICT (group_jid) DO UPDATE
            SET leave_msg = NULL, updated_at = NOW()
        `, [chatJid]);
        return `✅ _Leave message reset to default._\n\n_Default:_ ${DEFAULT_LEAVE}`;
    }

    await db.query(`
        INSERT INTO group_settings (group_jid, leave_msg, updated_at)
        VALUES ($1, $2, NOW())
        ON CONFLICT (group_jid) DO UPDATE
        SET leave_msg = $2, updated_at = NOW()
    `, [chatJid, message]);

    return (
        `✅ *Leave message set!*\n\n` +
        `_Preview:_\n${_previewTemplate(message)}\n\n` +
        `_Variables: {name} {group} {number}_`
    );
}

async function _cmdSetRules(ctx, senderRank, senderLevel, args) {
    const { db, chatJid } = ctx;

    // Lord+ via command. Barons set rules manually (via .pin or direct message)
    if (senderLevel < RANK_LEVEL['lord']) {
        return `⚠️ _Only Lords and above can use .setrules._`;
    }

    const rules = args.join(' ').trim();

    if (!rules) {
        await db.query(`
            INSERT INTO group_settings (group_jid, rules, updated_at)
            VALUES ($1, NULL, NOW())
            ON CONFLICT (group_jid) DO UPDATE
            SET rules = NULL, updated_at = NOW()
        `, [chatJid]);
        return `✅ _Rules reset to default._`;
    }

    await db.query(`
        INSERT INTO group_settings (group_jid, rules, updated_at)
        VALUES ($1, $2, NOW())
        ON CONFLICT (group_jid) DO UPDATE
        SET rules = $2, updated_at = NOW()
    `, [chatJid, rules]);

    return `✅ *Rules updated!*\n\nType *.rules* to view them.`;
}

async function _cmdRules(ctx) {
    const { db, chatJid } = ctx;
    const settings = await _getGroupSettings(db, chatJid);
    return settings?.rules || DEFAULT_RULES;
}

async function _cmdPin(ctx, senderLevel, args) {
    const { sock, chatJid, msg } = ctx;

    if (senderLevel < RANK_LEVEL['baron']) {
        return `⚠️ _You don't have permission to pin messages._`;
    }

    // Pin the quoted message if replying, otherwise pin the text
    const quotedCtx = msg.message?.extendedTextMessage?.contextInfo;
    if (quotedCtx?.stanzaId) {
        try {
            await sock.sendMessage(chatJid, {
                pin: { type: 1, time: 604800 }, // 7 days
            }, { quoted: msg });
            return `📌 _Message pinned._`;
        } catch {
            return `⚠️ _Could not pin — make sure Ariel is a group admin._`;
        }
    }

    const pinText = args.join(' ').trim();
    if (!pinText) return `⚠️ _Reply to a message or provide text to pin._`;

    // Send the message then pin it
    try {
        const sent = await sock.sendMessage(chatJid, { text: `📌 *${pinText}*` });
        return null;
    } catch {
        return `⚠️ _Pin failed._`;
    }
}

async function _cmdInvite(ctx) {
    const { sock, chatJid } = ctx;

    if (!chatJid.endsWith('@g.us')) {
        return `⚠️ _.invite only works inside a group._`;
    }

    try {
        const meta = await sock.groupMetadata(chatJid);
        let code;
        try {
            code = await sock.groupInviteCode(chatJid);
        } catch (inviteErr) {
            if (inviteErr.message === 'item-not-found') {
                // groupInviteCode does a GET for an existing invite item — if
                // this group never had a link generated (nobody tapped
                // "Invite via link" in the app), there's nothing to fetch.
                // groupRevokeInvite does a SET instead, which creates one if
                // it doesn't exist yet and returns it. Safe to use as a
                // fallback here since we only reach it when GET found nothing.
                code = await sock.groupRevokeInvite(chatJid);
            } else {
                throw inviteErr;
            }
        }

        // Pull the group's full-size photo so the card renders a real banner
        // image. Without jpegThumbnail, WhatsApp falls back to the tiny
        // default circular icon — that's what was showing before.
        let jpegThumbnail;
        try {
            const ppUrl = await sock.profilePictureUrl(chatJid, 'image'); // full-res, not 'preview'
            const res   = await fetch(ppUrl);
            jpegThumbnail = Buffer.from(await res.arrayBuffer());
        } catch {
            // No group photo set, or fetch failed — card still sends fine,
            // just without the big banner image.
        }

        await sock.sendMessage(chatJid, {
            groupInvite: {
                jid:              chatJid,
                subject:          meta.subject,
                text:             '📨 Join us in Niflheim!',
                inviteCode:       code,
                inviteExpiration: Math.floor(Date.now() / 1000) + 259200, // 3 days
                ...(jpegThumbnail ? { jpegThumbnail } : {}),
            },
            contextInfo: {
                forwardingScore: 5,
                isForwarded: true,
            },
        });
        return null; // already sent
    } catch (e) {
        // Reached only if groupRevokeInvite also failed, or some other error
        // hit before we got that far. Dump enough to diagnose without
        // guessing — this is a real, unexpected failure at this point.
        console.error('[INVITE] groupInviteCode failed:', e.message);
        console.error('[INVITE] sock.user:', JSON.stringify(sock.user));
        try {
            const meta = await sock.groupMetadata(chatJid);
            const me = meta.participants.find(p =>
                p.id === sock.user?.id || p.lid === sock.user?.id ||
                p.id === sock.user?.lid || p.lid === sock.user?.lid
            );
            console.error('[INVITE] self participant record:', JSON.stringify(me));
        } catch (metaErr) {
            console.error('[INVITE] self-check groupMetadata also failed:', metaErr.message);
        }
        return `⚠️ _Could not generate invite — make sure Ariel is a group admin. (${e.message})_`;
    }
}

async function _cmdRanks(ctx) {
    const { db, chatJid, sock } = ctx;

    // Get all crowned members
    const res = await db.query(
        `SELECT jid, rank, granted_at FROM bot_ranks ORDER BY
         CASE rank
           WHEN 'king'     THEN 1
           WHEN 'queen'    THEN 2
           WHEN 'prince'   THEN 3
           WHEN 'princess' THEN 4
           WHEN 'duke'     THEN 5
           WHEN 'duchess'  THEN 6
           WHEN 'lord'     THEN 7
           WHEN 'baron'    THEN 8
           ELSE 9
         END`
    );

    if (!res.rows.length) return `_No ranks assigned yet._`;

    const lines = [`👑 *Niflheim Ranks*\n`];
    for (const row of res.rows) {
        const num = row.jid.split('@')[0];
        lines.push(`${rankBadge(row.rank)} — @${num}`);
    }

    return lines.join('\n');
}

async function _cmdWhois(ctx, mentionedJid) {
    const { db, senderJid, groupParticipants } = ctx;

    const targetJid  = mentionedJid || senderJid;
    const targetRank = await getRank(db, targetJid, groupParticipants);
    const num        = targetJid.split('@')[0];

    return (
        `👤 *@${num}*\n\n` +
        `${rankBadge(targetRank)}`
    );
}


// ============================================================
// INTERNAL HELPERS
// ============================================================

async function _getGroupSettings(db, groupJid) {
    try {
        const res = await db.query(
            'SELECT * FROM group_settings WHERE group_jid = $1', [groupJid]
        );
        return res.rows[0] || null;
    } catch { return null; }
}

function _previewTemplate(template) {
    return template
        .replace(/{name}/g,   '@ExampleUser')
        .replace(/{group}/g,  'Niflheim')
        .replace(/{number}/g, '234XXXXXXXXX');
}


// ============================================================
// MUTE CHECK
// Call this at the top of handleMessage() in index.js
// Returns true if user is muted (message should be ignored)
// ============================================================

export async function isMuted(db, groupJid, userJid) {
    try {
        const res = await db.query(
            'SELECT count FROM warnings WHERE group_jid = $1 AND user_jid = $2',
            [groupJid, userJid]
        );
        return res.rows[0]?.count === -1;
    } catch { return false; }
}


// ============================================================
// HOW TO WIRE INTO index.js
// ============================================================
//
// 1. Import at top of index.js:
//      import { setupCommandsTables, handleBotCommand,
//               onMemberJoin, onMemberLeave, isMuted } from './commands.js';
//
// 2. After DB connects, call:
//      await setupCommandsTables(db);
//
// 3. In handleMessage(), before the game layer:
//      if (await isMuted(db, chatJid, senderJid)) return;
//
//      const botReply = await handleBotCommand({
//          sock, db, msg, chatJid, senderJid, text,
//          mentionedJid, groupParticipants,
//      });
//      if (botReply) {
//          await sendAny(sock, chatJid, botReply, msg);
//          return;
//      }
//      // ... rest of message handling
//
// 4. Add group participant listener:
//      sock.ev.on('group-participants.update', async ({ id, participants, action }) => {
//          const ctx = { sock, db, chatJid: id, groupParticipants: [] };
//          if (action === 'add')    for (const jid of participants) await onMemberJoin(ctx, jid);
//          if (action === 'remove') for (const jid of participants) await onMemberLeave(ctx, jid);
//      });
//
// 5. Pass groupParticipants for accurate WA admin detection:
//      const meta = await sock.groupMetadata(chatJid);
//      const groupParticipants = meta.participants;
//
// ============================================================


// ── _cmdSpawn ─────────────────────────────────────────────────
// .spawn [name] [zone]  — King/Queen only
// Injects a Pokémon into a zone. Players have 1% chance per step
// to encounter it. Persists until caught or defeated.
async function _cmdSpawn(ctx, senderRank, senderLevel, args) {
    const { db, chatJid } = ctx;

    if (!['king', 'queen'].includes(senderRank?.toLowerCase())) {
        return `⚠️ _Only the King or Queen can spawn Pokémon._`;
    }

    const POKEAPI = 'https://pokeapi.co/api/v2/pokemon';

    let pokemonName = null;
    let zone        = args[args.length - 1] || null;

    if (args.length === 0) {
        // Random — pick from pokeapi range 1-1025
        const id = Math.floor(Math.random() * 1025) + 1;
        pokemonName = String(id);
    } else if (args.length === 1) {
        pokemonName = args[0].toLowerCase();
        zone        = null;
    } else {
        pokemonName = args[0].toLowerCase();
        zone        = args[args.length - 1].toLowerCase();
    }

    // Fetch Pokémon data
    let data;
    try {
        const res = await fetch(`${POKEAPI}/${pokemonName}`);
        if (!res.ok) return `⚠️ _Pokémon "${pokemonName}" not found._`;
        data = await res.json();
    } catch {
        return `⚠️ _Failed to fetch Pokémon data._`;
    }

    const name   = data.name;
    const sprite = data.sprites?.other?.['official-artwork']?.front_default
                || data.sprites?.front_default || '';
    const types  = data.types.map(t =>
        t.type.name.charAt(0).toUpperCase() + t.type.name.slice(1)
    ).join('/');
    const hp     = data.stats.find(s => s.stat.name === 'hp')?.base_stat || 45;

    const payload = JSON.stringify({ name, sprite, types, base_hp: hp, source: 'spawn' });
    const now     = new Date().toISOString();

    await db.query(
        `INSERT INTO zone_spawns (zone, pokemon_name, pokemon_data, spawned_by, spawned_at, status)
         VALUES ($1, $2, $3, $4, $5, 'active')`,
        [zone || 'any', name, payload, ctx.senderJid, now]
    );

    return (
        `__IMG__${sprite}__CAP__` +
        `🌟 *A wild ${name.charAt(0).toUpperCase() + name.slice(1)} has appeared!*\n` +
        `📍 Zone: _${zone || 'current'}_\n` +
        `🔷 Type: ${types}\n\n` +
        `_It lurks in the zone... any traveller may encounter it._`
    );
}


// ── _cmdSpawnP ────────────────────────────────────────────────
// .spawnp [name]  — King/Queen only
// Prefetches and caches Pokémon data for fast future spawns.
async function _cmdSpawnP(ctx, senderRank, senderLevel, args) {
    if (!['king', 'queen'].includes(senderRank?.toLowerCase())) {
        return `⚠️ _Only the King or Queen can use this._`;
    }

    const POKEAPI = 'https://pokeapi.co/api/v2/pokemon';
    const target  = args[0]?.toLowerCase() || String(Math.floor(Math.random() * 1025) + 1);

    let data, speciesData;
    try {
        const res = await fetch(`${POKEAPI}/${target}`);
        if (!res.ok) return `⚠️ _Pokémon "${target}" not found._`;
        data = await res.json();
    } catch {
        return `⚠️ _Failed to fetch Pokémon data._`;
    }

    // Fetch species for flavor text
    try {
        const sres = await fetch(data.species.url);
        speciesData = await sres.json();
    } catch { speciesData = null; }

    const name   = data.name;
    const sprite = data.sprites?.other?.['official-artwork']?.front_default
                || data.sprites?.front_default || '';
    const types  = data.types.map(t =>
        t.type.name.charAt(0).toUpperCase() + t.type.name.slice(1)
    ).join('/');
    const hp     = data.stats.find(s => s.stat.name === 'hp')?.base_stat || 45;
    const atk    = data.stats.find(s => s.stat.name === 'attack')?.base_stat || 45;
    const def    = data.stats.find(s => s.stat.name === 'defense')?.base_stat || 45;
    const spd    = data.stats.find(s => s.stat.name === 'speed')?.base_stat || 45;

    // Get English flavor text
    const flavorEntry = speciesData?.flavor_text_entries?.find(e => e.language.name === 'en');
    const flavor = flavorEntry
        ? flavorEntry.flavor_text.replace(/\f|\n/g, ' ').trim()
        : '';

    const displayName = name.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');

    // Cache in DB for Python side to use
    try {
        await ctx.db.query(
            `INSERT INTO pokemon_cache (key, data) VALUES ($1, $2)
             ON CONFLICT (key) DO UPDATE SET data = $2`,
            [name, JSON.stringify({ name, sprite, types, base_hp: hp, base_atk: atk, base_def: def, base_spd: spd })]
        );
    } catch { /* cache best-effort */ }

    return (
        `__IMG__${sprite}__CAP__` +
        `*${displayName}*\n` +
        `🔷 ${types}\n\n` +
        `_${flavor}_\n\n` +
        `_Data cached. Use .spawn ${name} [zone] to inject it._`
    );
}


// ── _cmdMenu ──────────────────────────────────────────────────
function _cmdMenu() {
    const HEADER = (
        "╭━━★彡 𝚴𝐈ҒԼ𝚮𝚵𝐈𝚳 彡★━━╮\n" +
        "┃  𖤓 Prefix: .\n" +
        "┃  𖤓 Name: Ariel\n" +
        "┃  𖤓 Creator: Ice King\n" +
        "╰━━━━━━━━━━━━━╯\n" +
        "*Use .pmenu for the pokemon menu*\n\n"
    );

    const body = (
        HEADER +
        "*💬 INTERACTION 💬*\n" +
        "┣ ✦ .hug\n┣ ✦ .kiss\n┣ ✦ .slap\n┣ ✦ .pat\n" +
        "┣ ✦ .dance\n┣ ✦ .smile\n┣ ✦ .laugh\n┣ ✦ .cry\n" +
        "┣ ✦ .blush\n┣ ✦ .stare\n┣ ✦ .pout\n┣ ✦ .roar\n" +
        "┣ ✦ .punch\n┣ ✦ .bonk\n┣ ✦ .tickle\n┣ ✦ .lick\n" +
        "┣ ✦ .shrug\n┣ ✦ .shoot\n┣ ✦ .spin\n┣ ✦ .think\n" +
        "┣ ✦ .clap\n┣ ✦ .run\n┣ ✦ .sleep\n┣ ✦ .kidnap\n" +
        "┗━━━━━━━━━━━\n\n" +
        "*😂 FUN 😂*\n" +
        "┣ ✦ .ship\n┣ ✦ .joke\n┣ ✦ .truth\n┣ ✦ .dare\n" +
        "┣ ✦ .wyr\n┣ ✦ .meme\n┣ ✦ .shootmeme\n┣ ✦ .coolmeme\n" +
        "┣ ✦ .sadmeme\n┣ ✦ .triggered\n" +
        "┗━━━━━━━━━━━\n\n" +
        "*🔍 SEARCH 🔍*\n" +
        "┣ ✦ .pint [query]\n┣ ✦ .wallpaper [query]\n" +
        "┗━━━━━━━━━━━\n\n" +
        "*🤖 AI 🤖*\n" +
        "┣ ✦ .gpt [question]\n┣ ✦ .tldr [text]\n┣ ✦ .copilot [question]\n" +
        "┗━━━━━━━━━━━\n\n" +
        "*🔄 CONVERTER 🔄*\n" +
        "┣ ✦ .sticker\n┣ ✦ .toimg\n┣ ✦ .translate [text]\n" +
        "┗━━━━━━━━━━━\n\n" +
        "*🛠️ UTILITY 🛠️*\n" +
        "┣ ✦ .ping\n┣ ✦ .uptime\n┣ ✦ .stats\n┣ ✦ .owner\n" +
        "┣ ✦ .whois [@user]\n┣ ✦ .ranks\n┣ ✦ .rules\n┣ ✦ .help [cmd]\n" +
        "┗━━━━━━━━━━━\n\n" +
        "*🔧 ADMIN 🔧*\n" +
        "┣ ✦ .warn @user\n┣ ✦ .warnings [@user]\n┣ ✦ .clearwarns @user\n" +
        "┣ ✦ .kick @user\n┣ ✦ .mute @user\n┣ ✦ .unmute @user\n" +
        "┣ ✦ .promote @user\n┣ ✦ .demote @user\n┣ ✦ .tagall [msg]\n" +
        "┣ ✦ .setwelcome [msg]\n┣ ✦ .setleave [msg]\n┣ ✦ .setrules [msg]\n" +
        "┣ ✦ .pin [msg]\n┣ ✦ .linkgroup\n┣ ✦ .unlinkgroup\n┣ ✦ .arielstatus\n" +
        "┗━━━━━━━━━━━\n\n" +
        "*👑 ROYALTY 👑*\n" +
        "┣ ✦ .crown [title] @user\n┣ ✦ .dethrone @user\n" +
        "┗━━━━━━━━━━━"
    );

    return `__IMG__https://i.ibb.co/Kj0WDD9J/Ariel-16-Satoru-Ariel.jpg__CAP__${body}`;
}


// ── _cmdPmenu ─────────────────────────────────────────────────
function _cmdPmenu(ctx) {
    const HEADER = (
        "╭━━★彡 𝚴𝐈ҒԼ𝚮𝚵𝐈𝚳 彡★━━╮\n" +
        "┃  𖤓 Prefix: .\n" +
        "┃  𖤓 Name: Ariel\n" +
        "┃  𖤓 Creator: Ice King\n" +
        "╰━━━━━━━━━━━━━╯\n\n"
    );

    const body = (
        HEADER +
        "*⚔️ EXPLORE ⚔️*\n" +
        "┣ ✦ .catch\n┣ ✦ .flee\n┣ ✦ .skills\n┣ ✦ .setskill [name]\n" +
        "┗━━━━━━━━━━━\n\n" +
        "*🗺️ NAVIGATION 🗺️*\n" +
        "┣ ✦ .minimap\n┣ ✦ .location\n" +
        "┗━━━━━━━━━━━\n\n" +
        "*👤 PROFILE 👤*\n" +
        "┣ ✦ .status\n┣ ✦ .pokedex\n┣ ✦ .party\n┣ ✦ .bal\n" +
        "┣ ✦ .resetprofile\n┣ ✦ .hud [1-3]\n" +
        "┗━━━━━━━━━━━"
    );

    return `__IMG__https://i.ibb.co/Kj0WDD9J/Ariel-16-Satoru-Ariel.jpg__CAP__${body}`;
}
	
