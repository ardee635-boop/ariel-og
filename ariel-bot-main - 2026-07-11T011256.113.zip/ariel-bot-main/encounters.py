# ============================================================
# NIFLHEIM — encounters.py
# Wild encounter system — trigger, battle, catch, rewards
# ============================================================

import random
import time
import threading

# ── Star reward multipliers ───────────────────────────────────
STAR_MULTIPLIER = {
    1: 1.0, 2: 1.2, 3: 1.5, 4: 1.8,  5: 2.2,
    6: 2.6, 7: 3.1, 8: 3.6, 9: 4.3, 10: 5.0,
}

# ── Status catch bonuses ──────────────────────────────────────
STATUS_CATCH_BONUS = {
    None:        0.00,
    "burn":      0.05,
    "bleed":     0.04,
    "poison":    0.05,
    "paralysis": 0.08,
    "sleep":     0.15,
    "freeze":    0.15,
}

# ── Ball catch bonuses ────────────────────────────────────────
BALL_CATCH_BONUS = {
    "Poké Ball":   0.10,
    "Great Ball":  0.25,
    "Ultra Ball":  0.40,
    "Master Ball": 1.00,
    # Special type balls
    "Pyro Ball":   0.15,
    "Cryo Ball":   0.15,
    "Atmo Ball":   0.15,
    "Floro Ball":  0.15,
    "Volt Ball":   0.15,
}

# Special ball type affinity — bonus only applies to matching type
BALL_TYPE_AFFINITY = {
    "Pyro Ball":  ["fire"],
    "Cryo Ball":  ["ice", "water"],
    "Atmo Ball":  ["flying"],
    "Floro Ball": ["grass"],
    "Volt Ball":  ["electric"],
}

# ── Encounter tables ──────────────────────────────────────────

# Zone spawn positions — (col, row) — middle of a walkable RR area
# Used by .quicktravel and registration to place players
ZONE_SPAWNS = {
    "oak_town":      (12, 11),
    "greenwood_town":(10, 10),
    "fauna":         (1,  5),
    "route_1":       (25, 5),
    "route_3":       (6, 12),
    "thunderplains": (9, 17),
    "oceana":        (16, 9),   # port area
}

ENCOUNTER_TABLES = {
    "fauna": {
        "grass": [
            # Very Common
            ("caterpie",      40),
            ("weedle",        38),
            ("oddish",        35),
            ("bellsprout",    32),
            ("spinarak",      30),
            ("wurmple",       28),
            ("exeggcute",     25),
            # Common
            ("paras",         20),
            ("venonat",       18),
            ("ekans",         16),
            ("nidoran-f",     15),
            ("nidoran-m",     15),
            ("hoppip",        14),
            ("sunkern",       13),
            ("ledyba",        12),
            # Uncommon
            ("metapod",       10),
            ("kakuna",        10),
            ("gloom",          9),
            ("weepinbell",     9),
            ("bayleef",        8),
            ("chikorita",      8),
            ("natu",           7),
            ("aipom",          7),
            ("butterfree",     7),
            ("beedrill",       7),
            ("roselia",        6),
            ("sunflora",       6),
            # Rare
            ("parasect",       5),
            ("venomoth",       5),
            ("tangela",        4),
            ("victreebel",     3),
            ("ariados",        3),
            ("bulbasaur",      3),
            ("yanma",          3),
            ("tropius",        2),
            ("scyther",        2),
            # Very Rare
            ("pinsir",         2),
            ("heracross",      2),
            ("celebi",         1),
        ],
        "level_range": [8, 20],
    },
    "thunderplains": {
        "grass": [
            # Common
            ("helioptile",    30),
            ("joltik",        28),
            ("pawmo",         25),
            ("raichu",        20),
            # Uncommon
            ("emolga",        12),
            ("togedemaru",    11),
            ("stunfisk",      10),
            ("toxtricity",     9),
            ("pawmot",         9),
            ("magneton",       8),
            # Rare
            ("galvantula",     4),
            ("heliolisk",      4),
            ("kilowattrel",    3),
            ("morpeko",        3),
            ("electabuzz",     3),
            # Very Rare
            ("sandy-shocks",   1),
            ("iron-thorns",    1),
            ("vikavolt",       1),
            ("jolteon",        1),
        ],
    },
        "route_3": {
        "grass": [
            # Common
            ("rattata",       35),
            ("sentret",       30),
            ("caterpie",      28),
            ("weedle",        28),
            ("ledyba",        25),
            ("diglett",       22),
            ("sandshrew",     20),
            # Uncommon
            ("spinarak",      12),
            ("venonat",       12),
            ("geodude",       10),
            ("cubone",         9),
            ("jigglypuff",     8),
            # Rare
            ("scyther",        4),
            ("pinsir",         4),
            ("rhyhorn",        3),
            ("lickitung",      3),
            # Very Rare
            ("marowak",        2),
            ("larvitar",       1),
            ("chansey",        1),
        ],
    },
        "route_1": {
        "grass": [
            # Common
            ("weedle",      40),
            ("rattata",     35),
            ("caterpie",    20),
            ("pidgey",      20),
            ("meowth",      18),
            ("sentret",     18),
            ("venonat",     16),
            ("diglett",     15),
            ("sandshrew",   15),
            ("exeggcute",   14),
            # Uncommon
            ("spearow",     12),
            ("oddish",      10),
            ("paras",       10),
            ("bellsprout",   8),
            ("ekans",        8),
            ("tangela",      8),
            ("hoppip",       8),
            ("ledyba",       8),
            ("spinarak",     8),
            ("geodude",      7),
            # Rare
            ("mankey",       6),
            ("jigglypuff",   5),
            ("nidoran-f",    4),
            ("nidoran-m",    4),
            ("lickitung",    4),
            ("rhyhorn",      3),
            ("pinsir",       3),
            ("eevee",        2),
            ("chansey",      2),
            # Very rare
            ("scyther",      2),
        ],
        "water": [
            ("magikarp",   60),
            ("poliwag",    30),
            ("tentacool",  10),
        ],
        "level_range": [1, 8],
    },
}

# ── Encounter chance system ───────────────────────────────────
BASE_ENCOUNTER_CHANCE = 0.15   # 15% base per grass step
STEP_INCREMENT        = 0.04   # +4% per consecutive grass step
RESPITE_STEPS         = 1      # free steps after an encounter


def roll_encounter(grass_steps: int) -> bool:
    """Roll encounter chance based on consecutive grass steps."""
    chance = BASE_ENCOUNTER_CHANCE + (grass_steps * STEP_INCREMENT)
    chance = min(chance, 0.90)  # cap at 90%
    return random.random() < chance


def roll_wild_pokemon(zone: str, tile: str = "grass", player_level: int = None) -> tuple[str, int] | None:
    """
    Roll a wild Pokémon species and level for the given zone and tile type.

    Level distribution (when player_level is provided):
      93% — scaled to player ace level ±2-3, clamped to zone range
       5% — zone minimum level (low-level surprise)
       2% — zone maximum level (high-level threat)
    """
    table = ENCOUNTER_TABLES.get(zone)
    if not table:
        return None
    pool = table.get(tile, table.get("grass", []))
    if not pool:
        return None
    names   = [n for n, _ in pool]
    weights = [w for _, w in pool]
    name    = random.choices(names, weights=weights, k=1)[0]
    lo, hi  = table.get("level_range", [1, 5])

    if player_level is not None:
        roll = random.random()
        if roll < 0.02:
            # 2% — high-level threat
            level = hi
        elif roll < 0.07:
            # 5% — low-level surprise
            level = lo
        else:
            # 93% — scaled to player
            base  = player_level + random.randint(-3, 3)
            level = max(lo, min(hi, base))
    else:
        level = random.randint(lo, hi)

    return name, level


def build_wild_monster(api_data: dict, level: int) -> dict:
    """Build a wild monster dict from PokéAPI data."""
    from data_pokemon import roll_stars, apply_star_stats
    stars      = roll_stars()
    base       = apply_star_stats(api_data["base_stats"], stars)
    max_hp     = int(((2 * base["hp"] * level) / 100) + (level * 15) + 10)

    # Build moves as dicts with pp — battle.py expects {name, pp, max_pp}
    raw_moves = api_data.get("default_moves", [])[:4]
    moves = []
    for m in raw_moves:
        if isinstance(m, dict):
            moves.append(m)
        else:
            moves.append({"name": m, "pp": 20, "max_pp": 20})

    return {
        "name":            api_data["name"],
        "level":           level,
        "stars":           stars,
        "types":           api_data.get("types", []),
        "sprite":          api_data.get("sprite", ""),
        # All 6 stats stored for calc_damage / calc_def_stat in battle.py
        "base_stats":      base,
        # Pre-computed hp for convenience
        "hp":              max_hp,
        "max_hp":          max_hp,
        # Raw catch_rate (0–255) — battle.py applies its own formula
        "catch_rate":      api_data.get("catch_rate", 45),
        "base_experience": api_data.get("base_experience", 50),
        "status":          None,
        "catch_fail_penalty": 0,
        "moves":           moves,
    }


# ── Encounter HUD ─────────────────────────────────────────────

def _hp_bar(hp, max_hp, width=10):
    filled = int((hp / max_hp) * width) if max_hp > 0 else 0
    return f"{'█' * filled}{'░' * (width - filled)}"

def _pct(hp, max_hp):
    return int((hp / max_hp) * 100) if max_hp > 0 else 0

def encounter_screen(monster: dict) -> str:
    """Initial encounter screen — shown before player chooses fight/flee."""
    name    = monster["name"].capitalize()
    level   = monster["level"]
    types   = "/".join(t.capitalize() for t in monster["types"])
    hp      = monster["hp"]
    max_hp  = monster["max_hp"]
    bar     = _hp_bar(hp, max_hp)
    sprite  = monster.get("sprite", "")
    stars   = monster.get("stars", 1)
    star_s  = "⭐" * min(stars, 5) + ("🌟" * max(0, stars - 5))

    img_line = f"__IMG__{sprite}__CAP__Wild {name}!\n" if sprite else ""
    return (
        f"{img_line}"
        f"A wild *{name}* appeared!\n"
        f"☰ Type: {types}  |  Lv.{level}  {star_s}\n"
        f"₊✙⁺ HP: {hp}/{max_hp} {bar}\n\n"
        f".fight to engage\n"
        f".flee to escape"
    )


def battle_screen(player_pokemon, monster: dict) -> str:
    """Options screen shown between turns."""
    m_hp    = monster["hp"]
    m_max   = monster["max_hp"]
    m_name  = monster["name"].capitalize()
    p_hp    = player_pokemon.hp
    p_max   = player_pokemon.max_hp
    p_name  = player_pokemon.nickname
    m_bar   = _hp_bar(m_hp, m_max)
    p_bar   = _hp_bar(p_hp, p_max)
    # Invisible readmore spacer
    RM = "\u200b" * 700

    return (
        f"*{m_name}'s HP:* {m_hp}/{m_max} ({_pct(m_hp, m_max)}%) {m_bar}\n"
        f"*{p_name}'s HP:* {p_hp}/{p_max} ({_pct(p_hp, p_max)}%) {p_bar}\n"
        f"{RM}\n"
        f"Your options:\n"
        f".skills\n"
        f".catch\n"
        f".heal\n"
        f".use\n"
        f"_State a skill name to attack_"
    )


def skills_screen(pokemon) -> str:
    """Shows the player's Pokémon skill list with PP."""
    lines = [f"⚔️ *{pokemon.nickname}'s Skills*"]
    for m in pokemon.moves:
        name = m["name"].replace("-", " ").title()
        pp   = m["pp"]
        mpp  = m["max_pp"]
        lines.append(f"{name:<20} {pp}/{mpp}")
    return "\n".join(lines)


def victory_screen(monster: dict, player_pokemon, xp_gained: int,
                   coins_gained: int, level_msgs: list, learned: list) -> str:
    """Victory screen after defeating a wild Pokémon."""
    name  = monster["name"].capitalize()
    lines = [
        f"*{player_pokemon.nickname}* gained *{xp_gained} XP*!",
        f"+{coins_gained}₡",
    ]
    lines.extend(level_msgs)
    for move in learned:
        lines.append(f"*{player_pokemon.nickname}* has learned *{move}*!")
    lines.append(f"_Use .party to see {player_pokemon.nickname}'s details_")
    return "\n".join(lines)


# ── Reward calculation ────────────────────────────────────────

def calculate_rewards(monster: dict, player_pokemon) -> tuple[int, int]:
    """Returns (xp, coins)."""
    stars      = monster.get("stars", 1)
    level      = monster["level"]
    base_xp    = monster.get("base_xp", 50)
    multiplier = STAR_MULTIPLIER.get(stars, 1.0)
    xp         = int(base_xp * level * multiplier)
    coins      = int(level * 5 * multiplier)
    return xp, coins


# ── Catch system ─────────────────────────────────────────────

def calculate_catch_rate(monster: dict, ball: str) -> float:
    """
    Total catch rate = base + ball + HP bonus + status bonus - fail penalty
    HP bonus: up to +20% at 1 HP
    Status: capped at +15%
    Fail penalty: -5% per failed throw this encounter
    """
    base        = monster.get("catch_rate", 0.45)  # already normalised 0-1
    ball_bonus  = BALL_CATCH_BONUS.get(ball, 0.10)

    # Type affinity check for special balls
    affinity    = BALL_TYPE_AFFINITY.get(ball, [])
    if affinity and not any(t in affinity for t in monster.get("types", [])):
        ball_bonus = 0.10   # falls back to Poké Ball rate if wrong type

    # HP bonus — scales 0% (full HP) → 20% (1 HP)
    hp_pct      = monster["hp"] / monster["max_hp"] if monster["max_hp"] > 0 else 1
    hp_bonus    = (1 - hp_pct) * 0.20

    # Status bonus — capped at 15%
    status      = monster.get("status")
    status_bonus = min(STATUS_CATCH_BONUS.get(status, 0), 0.15)

    # Fail penalty
    fail_pen    = monster.get("catch_fail_penalty", 0)

    total = base + ball_bonus + hp_bonus + status_bonus - fail_pen
    return max(0.0, min(1.0, total))


def attempt_catch(monster: dict, ball: str) -> bool:
    """Returns True if catch succeeds."""
    rate = calculate_catch_rate(monster, ball)
    return random.random() < rate


# ── Turn resolution ───────────────────────────────────────────

def resolve_player_turn(player_pokemon, monster: dict,
                        move_name: str) -> tuple[int, str | None, str]:
    """
    Resolves player's move against the wild monster.
    Returns (damage_dealt, status_inflicted, message).
    """
    move   = next((m for m in player_pokemon.moves
                   if m["name"].lower() == move_name.lower()), None)
    if not move:
        return 0, None, f"_{player_pokemon.nickname} doesn't know that move!_"
    if move["pp"] <= 0:
        return 0, None, f"_{move['name']} has no PP left!_"

    move["pp"] -= 1
    p_name       = player_pokemon.nickname
    m_name       = monster["name"].capitalize()
    move_display = move["name"].replace("-", " ").title()

    # ── Stat moves (power = 0) ────────────────────────────────
    # TODO: pull actual move data from PokéAPI
    # For now detect known stat moves by name
    STAT_MOVES = {
        "leer":          (m_name,       "Defense",  "fell"),
        "growl":         (m_name,       "Attack",   "fell"),
        "tail-whip":     (m_name,       "Defense",  "fell"),
        "string-shot":   (m_name,       "Speed",    "fell"),
        "smokescreen":   (m_name,       "Accuracy", "fell"),
        "sand-attack":   (m_name,       "Accuracy", "fell"),
        "scary-face":    (m_name,       "Speed",    "sharply fell"),
        "charm":         (m_name,       "Attack",   "sharply fell"),
        "screech":       (m_name,       "Defense",  "sharply fell"),
        "swords-dance":  (p_name,       "Attack",   "sharply rose"),
        "agility":       (p_name,       "Speed",    "sharply rose"),
        "harden":        (p_name,       "Defense",  "rose"),
        "growth":        (p_name,       "Attack",   "rose"),
        "amnesia":       (p_name,       "Sp. Def",  "sharply rose"),
        "defense-curl":  (p_name,       "Defense",  "rose"),
        "withdraw":      (p_name,       "Defense",  "rose"),
        "minimize":      (p_name,       "Evasion",  "sharply rose"),
    }
    move_key = move["name"].lower()
    if move_key in STAT_MOVES:
        target, stat, change = STAT_MOVES[move_key]
        # Apply stat modifier to monster or player (simple -/+ 10% for now)
        if target == m_name:
            cur = monster.get("attack" if stat == "Attack" else "speed", 20)
            monster["attack" if stat == "Attack" else "speed"] = max(1, int(cur * 0.9))
        msg = (
            f"*{p_name}* used *{move_display}*!\n"
            f"*{target}'s {stat}* {change}!"
        )
        return 0, None, msg

    # ── Damage moves ──────────────────────────────────────────
    atk    = player_pokemon.stat("attack")
    power  = 40   # TODO: pull from PokéAPI move data
    damage = max(1, int((atk * power) / 50))
    damage = int(damage * random.uniform(0.85, 1.0))

    monster["hp"] = max(0, monster["hp"] - damage)

    msg = (
        f"*{p_name}* used *{move_display}*!\n"
        f"*{p_name}* dealt *-{damage} DMG*\n"
        f"*{m_name}'s HP:* {monster['hp']}/{monster['max_hp']}"
    )
    return damage, None, msg


def resolve_monster_turn(monster: dict, player_pokemon) -> tuple[int, str]:
    """
    Resolves monster's move against the player's Pokémon.
    Returns (damage_dealt, message).
    """
    moves   = monster.get("moves", [])
    move    = random.choice(moves) if moves else "Tackle"
    move_n  = move.replace("-", " ").title() if isinstance(move, str) else "Tackle"

    atk     = monster.get("attack", 20)
    damage  = max(1, int((atk * 40) / 50))
    damage  = int(damage * random.uniform(0.85, 1.0))

    actual  = player_pokemon.take_damage(damage)
    p_name  = player_pokemon.nickname
    m_name  = monster["name"].capitalize()

    msg = (
        f"*{m_name}* used *{move_n}*\n"
        f"{m_name} dealt -{actual} DMG\n"
        f"*{p_name}'s HP:* {player_pokemon.hp}/{player_pokemon.max_hp}"
    )
    return actual, msg
