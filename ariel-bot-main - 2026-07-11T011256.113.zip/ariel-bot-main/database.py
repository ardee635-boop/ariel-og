# ============================================================
# NIFLHEIM – DATABASE.PY
# Supabase (PostgreSQL) for production
# Falls back to local SQLite if SUPABASE_URL not set
# ============================================================

import json, os, sys
from models import Player


def _get_conn():
    url = os.environ.get("SUPABASE_DB_URL", "")
    if url:
        try:
            import psycopg2
            conn = psycopg2.connect(url + "?sslmode=require")
            conn.autocommit = False
            print("[DB] Connected to Supabase PostgreSQL.", flush=True, file=sys.stderr)
            return conn, "pg"
        except Exception as e:
            print(f"[DB] Supabase failed: {e} — falling back to SQLite.", flush=True, file=sys.stderr)

    import sqlite3
    path = os.path.join(
        os.environ.get("RAILWAY_VOLUME_MOUNT_PATH", os.path.dirname(__file__)),
        "niflheim.db"
    )
    print(f"[DB] Using local SQLite at {path}", flush=True, file=sys.stderr)
    return sqlite3.connect(path, check_same_thread=False), "sqlite"


class Database:

    def __init__(self):
        self.conn, self._mode = _get_conn()
        self._init_tables()

    # ── Query helpers ─────────────────────────────────────────

    def _ex(self, sql, params=()):
        """Execute — normalises ? placeholders for PostgreSQL."""
        if self._mode == "pg":
            sql = sql.replace("?", "%s")
            sql = sql.replace("INTEGER PRIMARY KEY AUTOINCREMENT", "SERIAL PRIMARY KEY")
            sql = sql.replace("(datetime('now'))", "(NOW())")
            cur = self.conn.cursor()
            cur.execute(sql, params)
            return cur
        return self.conn.execute(sql, params)

    def _commit(self):
        self.conn.commit()

    def _fetchone(self, cur):
        return cur.fetchone()

    def _fetchall(self, cur):
        return cur.fetchall()

    # ── Table init ────────────────────────────────────────────

    def _init_tables(self):
        # Players
        self._ex("""
            CREATE TABLE IF NOT EXISTS players (
                sender TEXT PRIMARY KEY,
                data   TEXT NOT NULL
            )
        """)

        # Pending registrations (name step before player is created)
        self._ex("""
            CREATE TABLE IF NOT EXISTS registrations (
                sender TEXT PRIMARY KEY,
                data   TEXT NOT NULL
            )
        """)

        # PokéAPI response cache
        self._ex("""
            CREATE TABLE IF NOT EXISTS pokemon_cache (
                key  TEXT PRIMARY KEY,
                data TEXT NOT NULL
            )
        """)

        # Per-player key-value meta (objective, flags, temp state)
        self._ex("""
            CREATE TABLE IF NOT EXISTS player_meta (
                sender TEXT NOT NULL,
                key    TEXT NOT NULL,
                value  TEXT NOT NULL,
                PRIMARY KEY (sender, key)
            )
        """)

        # NPC familiarity per player
        self._ex("""
            CREATE TABLE IF NOT EXISTS npc_familiarity (
                sender           TEXT NOT NULL,
                npc_id           TEXT NOT NULL,
                score            INTEGER NOT NULL DEFAULT 0,
                last_talk        TEXT DEFAULT NULL,
                talk_count_today INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY (sender, npc_id)
            )
        """)

        self._ex("""
            CREATE TABLE IF NOT EXISTS zone_spawns (
                id               SERIAL PRIMARY KEY,
                zone             TEXT NOT NULL,
                pokemon_name     TEXT NOT NULL,
                pokemon_data     TEXT NOT NULL,
                spawned_by       TEXT NOT NULL,
                spawned_at       TEXT NOT NULL,
                status           TEXT NOT NULL DEFAULT 'active',
                caught_by        TEXT DEFAULT NULL,
                resolved_at      TEXT DEFAULT NULL
            )
        """)

        # Ariel affection per player (same flat-cap pattern as npc_familiarity)
        self._ex("""
            CREATE TABLE IF NOT EXISTS ariel_affection (
                sender           TEXT PRIMARY KEY,
                score            INTEGER NOT NULL DEFAULT 0,
                last_talk        TEXT DEFAULT NULL,
                talk_count_today INTEGER NOT NULL DEFAULT 0
            )
        """)

        # Ariel standing directives ("if Kingston does X, say Y in the gc")
        self._ex("""
            CREATE TABLE IF NOT EXISTS ariel_directives (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                owner        TEXT NOT NULL,
                target_jid   TEXT DEFAULT NULL,
                target_name  TEXT DEFAULT NULL,
                condition    TEXT NOT NULL,
                action       TEXT NOT NULL,
                trigger_type TEXT NOT NULL DEFAULT 'reactive',
                group_jid    TEXT DEFAULT NULL,
                active       INTEGER NOT NULL DEFAULT 1,
                created_at   TEXT DEFAULT NULL,
                last_fired   TEXT DEFAULT NULL
            )
        """)

        self._commit()

    # ── Players ───────────────────────────────────────────────

    def save(self, sender, player):
        payload = json.dumps(player.to_dict())
        if self._mode == "pg":
            self._ex("""
                INSERT INTO players (sender, data) VALUES (?, ?)
                ON CONFLICT(sender) DO UPDATE SET data = EXCLUDED.data
            """, (sender, payload))
        else:
            self._ex("""
                INSERT INTO players (sender, data) VALUES (?, ?)
                ON CONFLICT(sender) DO UPDATE SET data = excluded.data
            """, (sender, payload))
        self._commit()

    def load(self, sender):
        row = self._fetchone(self._ex(
            "SELECT data FROM players WHERE sender = ?", (sender,)
        ))
        if not row:
            return None
        return Player.from_dict(json.loads(row[0]))

    def exists(self, sender):
        row = self._fetchone(self._ex(
            "SELECT 1 FROM players WHERE sender = ?", (sender,)
        ))
        return row is not None

    def delete(self, sender):
        self._ex("DELETE FROM players WHERE sender = ?", (sender,))
        self._commit()

    def all_senders(self):
        rows = self._fetchall(self._ex("SELECT sender FROM players"))
        return [r[0] for r in rows]

    # ── Registrations ─────────────────────────────────────────

    def save_reg(self, sender, reg_data):
        payload = json.dumps(reg_data)
        if self._mode == "pg":
            self._ex("""
                INSERT INTO registrations (sender, data) VALUES (?, ?)
                ON CONFLICT(sender) DO UPDATE SET data = EXCLUDED.data
            """, (sender, payload))
        else:
            self._ex("""
                INSERT INTO registrations (sender, data) VALUES (?, ?)
                ON CONFLICT(sender) DO UPDATE SET data = excluded.data
            """, (sender, payload))
        self._commit()

    def load_reg(self, sender):
        row = self._fetchone(self._ex(
            "SELECT data FROM registrations WHERE sender = ?", (sender,)
        ))
        return json.loads(row[0]) if row else None

    def delete_reg(self, sender):
        self._ex("DELETE FROM registrations WHERE sender = ?", (sender,))
        self._commit()

    # ── PokéAPI cache ─────────────────────────────────────────

    def cache_get(self, key: str):
        row = self._fetchone(self._ex(
            "SELECT data FROM pokemon_cache WHERE key = ?", (key,)
        ))
        return json.loads(row[0]) if row else None

    def cache_set(self, key: str, value: dict):
        payload = json.dumps(value)
        if self._mode == "pg":
            self._ex("""
                INSERT INTO pokemon_cache (key, data) VALUES (?, ?)
                ON CONFLICT(key) DO UPDATE SET data = EXCLUDED.data
            """, (key, payload))
        else:
            self._ex("""
                INSERT INTO pokemon_cache (key, data) VALUES (?, ?)
                ON CONFLICT(key) DO UPDATE SET data = excluded.data
            """, (key, payload))
        self._commit()

    # ── Player meta ───────────────────────────────────────────

    def set_meta(self, sender, key, value):
        if self._mode == "pg":
            self._ex("""
                INSERT INTO player_meta (sender, key, value) VALUES (?, ?, ?)
                ON CONFLICT(sender, key) DO UPDATE SET value = EXCLUDED.value
            """, (sender, key, str(value)))
        else:
            self._ex("""
                INSERT INTO player_meta (sender, key, value) VALUES (?, ?, ?)
                ON CONFLICT(sender, key) DO UPDATE SET value = excluded.value
            """, (sender, key, str(value)))
        self._commit()

    def get_meta(self, sender, key):
        row = self._fetchone(self._ex(
            "SELECT value FROM player_meta WHERE sender = ? AND key = ?",
            (sender, key)
        ))
        return row[0] if row else None

    def delete_meta(self, sender, key):
        self._ex(
            "DELETE FROM player_meta WHERE sender = ? AND key = ?",
            (sender, key)
        )
        self._commit()

    # ── NPC familiarity ───────────────────────────────────────

    def familiarity_get(self, sender, npc_id):
        row = self._fetchone(self._ex(
            "SELECT score, last_talk, talk_count_today FROM npc_familiarity "
            "WHERE sender = ? AND npc_id = ?",
            (sender, npc_id)
        ))
        if not row:
            return {"score": 0, "last_talk": None, "talk_count_today": 0}
        return {"score": row[0], "last_talk": row[1], "talk_count_today": row[2]}

    def familiarity_add(self, sender, npc_id, points, daily_cap=5):
        import datetime
        today = datetime.date.today().isoformat()
        row = self._fetchone(self._ex(
            "SELECT score, last_talk, talk_count_today FROM npc_familiarity "
            "WHERE sender = ? AND npc_id = ?",
            (sender, npc_id)
        ))
        if not row:
            if self._mode == "pg":
                self._ex("""
                    INSERT INTO npc_familiarity (sender, npc_id, score, last_talk, talk_count_today)
                    VALUES (?, ?, ?, ?, 1)
                    ON CONFLICT(sender, npc_id) DO NOTHING
                """, (sender, npc_id, min(points, daily_cap), today))
            else:
                self._ex("""
                    INSERT OR IGNORE INTO npc_familiarity
                    (sender, npc_id, score, last_talk, talk_count_today)
                    VALUES (?, ?, ?, ?, 1)
                """, (sender, npc_id, min(points, daily_cap), today))
            self._commit()
            return
        score, last_talk, talk_today = row
        if last_talk != today:
            talk_today = 0
        if points == 1:
            if talk_today >= daily_cap:
                return
            talk_today += 1
        new_score = min(100, score + points)
        self._ex("""
            UPDATE npc_familiarity SET score = ?, last_talk = ?, talk_count_today = ?
            WHERE sender = ? AND npc_id = ?
        """, (new_score, today, talk_today, sender, npc_id))
        self._commit()

    def familiarity_tier(self, sender, npc_id):
        f = self.familiarity_get(sender, npc_id)
        s = f["score"]
        if s >= 81:   tier = "Bonded"
        elif s >= 61: tier = "Ally"
        elif s >= 41: tier = "Trusted"
        elif s >= 21: tier = "Acquainted"
        else:         tier = "Stranger"
        return tier, s

    def familiarity_all(self, sender):
        rows = self._fetchall(self._ex(
            "SELECT npc_id, score FROM npc_familiarity WHERE sender = ?", (sender,)
        ))
        return {r[0]: r[1] for r in rows}

    # ── Ariel affection ────────────────────────────────────────

    def affection_get(self, sender):
        row = self._fetchone(self._ex(
            "SELECT score, last_talk, talk_count_today FROM ariel_affection WHERE sender = ?",
            (sender,)
        ))
        if not row:
            return {"score": 0, "last_talk": None, "talk_count_today": 0}
        return {"score": row[0], "last_talk": row[1], "talk_count_today": row[2]}

    def affection_add(self, sender, points=1, daily_cap=5):
        import datetime
        today = datetime.date.today().isoformat()
        row = self._fetchone(self._ex(
            "SELECT score, last_talk, talk_count_today FROM ariel_affection WHERE sender = ?",
            (sender,)
        ))
        if not row:
            if self._mode == "pg":
                self._ex("""
                    INSERT INTO ariel_affection (sender, score, last_talk, talk_count_today)
                    VALUES (?, ?, ?, 1)
                    ON CONFLICT(sender) DO NOTHING
                """, (sender, min(points, daily_cap), today))
            else:
                self._ex("""
                    INSERT OR IGNORE INTO ariel_affection (sender, score, last_talk, talk_count_today)
                    VALUES (?, ?, ?, 1)
                """, (sender, min(points, daily_cap), today))
            self._commit()
            return
        score, last_talk, talk_today = row
        if last_talk != today:
            talk_today = 0
        if points == 1:
            if talk_today >= daily_cap:
                return
            talk_today += 1
        new_score = min(100, score + points)
        self._ex("""
            UPDATE ariel_affection SET score = ?, last_talk = ?, talk_count_today = ?
            WHERE sender = ?
        """, (new_score, today, talk_today, sender))
        self._commit()

    def affection_tier(self, sender):
        f = self.affection_get(sender)
        s = f["score"]
        if s >= 80:   tier = "Devoted"
        elif s >= 60: tier = "Close"
        elif s >= 40: tier = "Warm"
        elif s >= 20: tier = "Friendly"
        else:         tier = "Reserved"
        return tier, s

    # ── Ariel directives ───────────────────────────────────────

    def directive_count_active(self, owner):
        row = self._fetchone(self._ex(
            "SELECT COUNT(*) FROM ariel_directives WHERE owner = ? AND active = 1",
            (owner,)
        ))
        return row[0] if row else 0

    def directive_create(self, owner, condition, action, target_jid=None,
                          target_name=None, group_jid=None, trigger_type="reactive",
                          cap=5):
        """Returns the new directive's id, or None if the owner is at cap."""
        import datetime
        if self.directive_count_active(owner) >= cap:
            return None
        now = datetime.datetime.utcnow().isoformat()
        cur = self._ex("""
            INSERT INTO ariel_directives
                (owner, target_jid, target_name, condition, action, trigger_type, group_jid, active, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?)
        """, (owner, target_jid, target_name, condition, action, trigger_type, group_jid, now))
        self._commit()
        if self._mode == "pg":
            row = self._fetchone(self._ex(
                "SELECT id FROM ariel_directives WHERE owner = ? ORDER BY id DESC LIMIT 1",
                (owner,)
            ))
            return row[0] if row else None
        return cur.lastrowid

    def directives_targeting(self, sender_jid, group_jid=None):
        """Active reactive directives where sender_jid is the watched target."""
        rows = self._fetchall(self._ex("""
            SELECT id, owner, target_jid, target_name, condition, action, group_jid, last_fired
            FROM ariel_directives
            WHERE active = 1 AND trigger_type = 'reactive' AND target_jid = ?
        """, (sender_jid,)))
        out = []
        for r in rows:
            if group_jid and r[6] and r[6] != group_jid:
                continue
            out.append({
                "id": r[0], "owner": r[1], "target_jid": r[2], "target_name": r[3],
                "condition": r[4], "action": r[5], "group_jid": r[6], "last_fired": r[7],
            })
        return out

    def directives_list_owner(self, owner):
        rows = self._fetchall(self._ex("""
            SELECT id, target_name, condition, action, trigger_type, active
            FROM ariel_directives WHERE owner = ? ORDER BY id DESC
        """, (owner,)))
        return [{
            "id": r[0], "target_name": r[1], "condition": r[2],
            "action": r[3], "trigger_type": r[4], "active": bool(r[5]),
        } for r in rows]

    def directive_touch_fired(self, directive_id):
        import datetime
        self._ex("UPDATE ariel_directives SET last_fired = ? WHERE id = ?",
                  (datetime.datetime.utcnow().isoformat(), directive_id))
        self._commit()

    def directive_deactivate(self, directive_id, owner=None):
        if owner:
            self._ex("UPDATE ariel_directives SET active = 0 WHERE id = ? AND owner = ?",
                      (directive_id, owner))
        else:
            self._ex("UPDATE ariel_directives SET active = 0 WHERE id = ?", (directive_id,))
        self._commit()

    # ── Raw execute (router escape hatch) ─────────────────────

    def execute(self, sql, params=()):
        return self._ex(sql, params)
