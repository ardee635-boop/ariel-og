# ============================================================
# NIFLHEIM — gym.py
# Gym leader gauntlet — defeat the elders, then the leader, earn a badge.
# Structurally mirrors arena.py's round system (same underlying
# session machinery — arm_trainer_battle/commit_trainer_battle/
# arena_next_trainer_mon/clear_arena are generic, not arena-specific),
# but is its own gauntlet: no entry fee/NPC gate, no cooldowns,
# and the final round is always a fixed, named leader rather than
# a random trainer.
#
# PLACEHOLDER DATA: elder names, species pools, and team sizes below
# are reasonable defaults so .gym works end to end. Edit GYMS freely —
# nothing else in the codebase depends on the specific values.
# ============================================================

import random

# ── Config ────────────────────────────────────────────────────
GYMS = {
    "greenwood_town": {
        "town_name":   "Greenwood",
        "leader":      "Levin",
        "leader_type": "Nature",
        "badge":       "Leaf Badge",
        "elder_count": 2,
        "elder_names": ["Elder Mira", "Elder Wyn", "Elder Thera", "Elder Cassin"],
        "pool": [
            "oddish", "gloom", "bellsprout", "weepinbell", "hoppip", "skiploom",
            "sunkern", "sunflora", "tangela", "chikorita", "bayleef",
            "bulbasaur", "ivysaur", "budew", "roselia", "cherubi",
        ],
        "leader_pool": [
            "exeggutor", "tangrowth", "sunflora", "bayleef", "vileplume", "victreebel",
        ],
        "leader_team_size": 3,
    },
    "hydro_town": {
        "town_name":   "Hydro",
        "leader":      "Eren",
        "leader_type": "Water",
        "badge":       "Wave Badge",
        "elder_count": 2,
        "elder_names": ["Elder Dolan", "Elder Kess", "Elder Petra", "Elder Brant"],
        "pool": [
            "squirtle", "wartortle", "totodile", "croconaw", "mudkip", "marshtomp",
            "poliwag", "poliwhirl", "tentacool", "horsea", "seadra", "shellder",
            "krabby", "kingler", "staryu", "psyduck",
        ],
        "leader_pool": [
            "blastoise", "feraligatr", "gyarados", "vaporeon", "kingdra", "starmie",
        ],
        "leader_team_size": 3,
    },
}


# ============================================================
# STATE HELPERS
# ============================================================

def clear_gym_state(db, sender: str):
    for key in ("gym_round", "gym_zone", "gym_used_names"):
        db.delete_meta(sender, key)


# ============================================================
# ENTRY (.gym)
# ============================================================

def gym_enter(db, sender: str, player, session) -> str:
    """Called directly from .gym — no NPC gate, no entry fee."""
    from combat_session import STATE_GYM

    zone_id = getattr(player, "zone", "") or ""
    gym = GYMS.get(zone_id)
    if not gym:
        return "_There's no gym here._"

    clear_gym_state(db, sender)
    db.set_meta(sender, "gym_round", "1")
    db.set_meta(sender, "gym_zone", zone_id)
    session.transition(STATE_GYM)

    town   = gym["town_name"]
    leader = gym["leader"]
    return (
        f"🏛️ _You are entering {town} Gym, prepare yourself!_\n"
        f"_You must defeat the other elders before you can face Gym Leader {leader}!_\n\n"
        f"_Use_ `.next` _to begin._"
    )


# ============================================================
# NEXT ROUND (.next, shared with arena but routed separately)
# ============================================================

def gym_next(db, sender: str, player, session, direct_send=None, group_jid=None) -> str:
    round_str = db.get_meta(sender, "gym_round")
    if not round_str:
        return None
    current_round = int(round_str)

    zone_id = db.get_meta(sender, "gym_zone") or getattr(player, "zone", "")
    gym = GYMS.get(zone_id)
    if not gym:
        return None

    elder_count = gym.get("elder_count", 2)
    ace_level   = max((p.level for p in player.party if not p.is_fainted()), default=1)
    is_final    = current_round > elder_count

    if not is_final:
        used_raw = db.get_meta(sender, "gym_used_names") or ""
        used     = [n for n in used_raw.split(",") if n]
        name_pool = gym.get("elder_names", [])
        pool_names = [n for n in name_pool if n not in used] or name_pool
        trainer = random.choice(pool_names)
        used.append(trainer)
        db.set_meta(sender, "gym_used_names", ",".join(used))

        team_size = random.choice([2, 3])
        team = _build_team(db, ace_level, team_size, gym["pool"])
    else:
        trainer   = gym["leader"]
        team_size = gym.get("leader_team_size", 3)
        team = _build_team(db, ace_level + 2, team_size, gym.get("leader_pool") or gym["pool"])

    # Arm session (STATE_GYM_PENDING) — battle not started yet, blocks .atk etc.
    session.arm_trainer_battle(trainer, team, current_round)
    from combat_session import STATE_GYM_PENDING
    session.transition(STATE_GYM_PENDING)
    session.battle_context = "gym"

    PLAYER_SLOTS = 6
    p_alive  = sum(1 for p in player.party if not p.is_fainted())
    p_dots   = "⚈" * p_alive + "⚆" * (PLAYER_SLOTS - p_alive)
    t_dots   = "⚈" * len(team) + "⚆" * (team_size - len(team))

    first    = team[0]
    mon_name = first["name"].capitalize()
    header   = (f"⚔️ *Gym Leader {trainer}*" if is_final
                else f"⚔️ *Round {current_round} of {elder_count}*")

    msg1 = (
        f"{header}\n"
        f"━━━━━━━━━━━━━━━━\n"
        f"{'Gym Leader' if is_final else 'Elder'} *{trainer}* has challenged you!\n\n"
        f"You: {p_dots}  |  {trainer}: {t_dots}\n\n"
        f"_Battle starts in 5 seconds..._"
    )

    if direct_send:
        import threading, time
        from battle import battle_hud
        active = player.party[player.active_slot]
        t_name = trainer
        _group_jid = group_jid

        def _send_begin():
            time.sleep(5)
            try:
                session.commit_trainer_battle()
                hud = battle_hud(active, first)
                begin_msg = (
                    f"*You* sent out *{active.nickname}*!\n"
                    f"*{t_name}* sent out *{mon_name}*!\n\n"
                    f"{hud}"
                )
                direct_send(begin_msg, group_jid=_group_jid)
            except Exception as e:
                import sys, traceback
                print(f"[GYM] _send_begin thread error: {e}", file=sys.stderr, flush=True)
                traceback.print_exc(file=sys.stderr)

        threading.Thread(target=_send_begin, daemon=True).start()

    return msg1


# ============================================================
# ROUND WON
# ============================================================

def gym_round_won(db, sender: str, player, session) -> str:
    round_str = db.get_meta(sender, "gym_round")
    if not round_str:
        return ""
    current_round = int(round_str)

    zone_id = db.get_meta(sender, "gym_zone") or getattr(player, "zone", "")
    gym = GYMS.get(zone_id, {})
    elder_count = gym.get("elder_count", 2)
    leader      = gym.get("leader", "the Gym Leader")
    badge       = gym.get("badge", f"{leader} Badge")

    if current_round > elder_count:
        # Leader defeated — gym cleared!
        clear_gym_state(db, sender)
        from combat_session import STATE_EXPLORING
        session.transition(STATE_EXPLORING)
        session.clear_arena()

        if not hasattr(player, "badges") or player.badges is None:
            player.badges = []
        already_had = badge in player.badges
        if not already_had:
            player.badges.append(badge)
            reward_line = f"🎖️ You earned the *{badge}*!"
        else:
            reward_line = "_(You already hold this badge — no duplicate awarded.)_"

        return (
            f"🏆 *Gym Cleared!*\n"
            f"━━━━━━━━━━━━━━━━\n"
            f"You defeated Gym Leader *{leader}*!\n\n"
            f"{reward_line}"
        )

    # Elder defeated — advance to next round
    next_round = current_round + 1
    db.set_meta(sender, "gym_round", str(next_round))
    trainer = getattr(session, "arena_trainer_name", "the elder") or "the elder"
    if next_round > elder_count:
        hint = f"_Use_ `.next` _to face Gym Leader {leader}!_"
    else:
        hint = "_Use_ `.next` _for your next challenger._"
    return (
        f"⚔️ *{trainer} defeated!*\n"
        f"━━━━━━━━━━━━━━━━\n"
        f"{hint}"
    )


# ============================================================
# LOSS
# ============================================================

def gym_loss(db, sender: str, player, session) -> str:
    clear_gym_state(db, sender)
    return (
        f"💀 *You were defeated.*\n"
        f"_The gym ejects you — heal up and challenge it again whenever you're ready._"
    )


# ============================================================
# INTERNAL HELPERS
# ============================================================

def _build_team(db, player_level: int, team_size: int, pool: list) -> list[dict]:
    from pokeapi import get_full
    from encounters import build_wild_monster

    level_min = max(1, player_level - 2)
    level_max = player_level + 2
    species_pool = random.sample(pool, min(team_size * 2, len(pool))) if len(pool) >= team_size else list(pool)
    team = []
    for species in species_pool:
        if len(team) >= team_size:
            break
        level    = random.randint(level_min, level_max)
        api_data = get_full(db, species)
        if not api_data:
            continue
        mon = build_wild_monster(api_data, level)
        mon["trainer_owned"] = True
        team.append(mon)

    # Fallback
    while len(team) < team_size:
        team.append({
            "name": "rattata", "level": player_level,
            "types": ["normal"], "hp": 20, "max_hp": 20,
            "base_stats": {"hp":30,"atk":56,"def":35,"sp_atk":25,"sp_def":35,"spd":72},
            "moves": [{"name": "tackle", "pp": 35, "max_pp": 35}],
            "status": None, "catch_rate": 255, "base_experience": 51,
            "sprite": "", "stars": 1, "catch_fail_penalty": 0,
            "trainer_owned": True,
        })
    return team
