import PartyAndPC from "./components/PartyAndPC";

// Placeholder data — replace with the real fetch from GET /api/player/me
// (party / pc fields) once this is wired to the backend.
const placeholderParty = [];
const placeholderPc = [];

export default function App() {
  return (
    <div className="min-h-screen bg-[#0b1420] p-4">
      <PartyAndPC initialParty={placeholderParty} initialPc={placeholderPc} />
    </div>
  );
}
